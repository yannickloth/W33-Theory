v01: orbit non-conjugacy certificate + decomposition note.
