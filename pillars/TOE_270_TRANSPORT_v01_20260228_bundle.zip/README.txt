270 transport bundle: each directed K edge labelled by Heisenberg
affine data and a provisional block guess computed from the 9x6
sheet coordinates.  This is the first explicit quotient transport
object linking K27 coordinates to tomotope/axis block fibres.
