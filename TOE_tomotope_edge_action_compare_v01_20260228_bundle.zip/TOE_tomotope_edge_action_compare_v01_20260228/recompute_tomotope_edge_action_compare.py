#!/usr/bin/env python3
"""
Recompute: tomotope edge action compare vs axis-192 induced edge actions.

Inputs expected (either in CWD or via --axis-dir/--flag-dir):
  - axis_line_stabilizer_192.json (from TOE_w33_axis192_torsor bundle)
  - tomotope_flag_model_192.json, flag_adjacency_r0_r3_permutations.json, left_action_perms_for_r0_r3.json
    (from TOE_tomotope_flag_model_conjugacy bundle; only the ordering + r0..r3 are needed)

Outputs:
  - tomotope_p_generators.json
  - tomotope_edge_group_P_elements.json
  - reye_line_orbits_from_P.json
  - reye_incidence_12x16.csv
  - reye_lines_1based.txt
  - axis192_index2_edge_action_stats.json
  - REPORT.md
"""
import argparse, json, itertools, csv, math, collections, os, datetime

def perm_from_cycles(n, cycles):
    perm=list(range(1,n+1))
    for cyc in cycles:
        for i,a in enumerate(cyc):
            b=cyc[(i+1)%len(cyc)]
            perm[a-1]=b
    return tuple(perm)

def compose_perm(a,b):
    return tuple(a[b[i]-1] for i in range(len(a)))

def inv_perm(p):
    inv=[0]*len(p)
    for i,pi in enumerate(p, start=1):
        inv[pi-1]=i
    return tuple(inv)

def group_generated(gens):
    gens=list(gens)+[inv_perm(g) for g in gens]
    ID=tuple(range(1,len(gens[0])+1))
    S={ID}
    frontier=[ID]
    while frontier:
        x=frontier.pop()
        for g in gens:
            y=compose_perm(g,x)
            if y not in S:
                S.add(y); frontier.append(y)
    return S

def apply_perm_to_pair(perm, pair):
    a,b=pair
    x=perm[a]; y=perm[b]
    return (x,y) if x<y else (y,x)

def orbit_decomp_2subsets(perms, n=12):
    pairs=[(i,j) for i in range(n) for j in range(i+1,n)]
    seen=set()
    sizes=[]
    for pr in pairs:
        if pr in seen: continue
        orb=set([pr]); stack=[pr]; seen.add(pr)
        while stack:
            cur=stack.pop()
            for perm in perms:
                nxt=apply_perm_to_pair(perm,cur)
                if nxt not in seen:
                    seen.add(nxt); stack.append(nxt); orb.add(nxt)
        sizes.append(len(orb))
    return sorted(sizes, reverse=True)

def orbit_decomp_k_subsets(perms, n, k):
    subs=list(itertools.combinations(range(n),k))
    seen=set(); orbits=[]
    for s in subs:
        if s in seen: continue
        orb=set([s]); stack=[s]; seen.add(s)
        while stack:
            cur=stack.pop()
            for perm in perms:
                img=tuple(sorted(perm[i] for i in cur))
                if img not in seen:
                    seen.add(img); stack.append(img); orb.add(img)
        orbits.append(sorted(orb))
    orbits.sort(key=len, reverse=True)
    return orbits

# Signed perms on 7
def compose_signed(a, b):
    # return a ∘ b (apply b then a)
    pa, sa = a
    pb, sb = b
    pc=[]; sc=[]
    for i in range(7):
        j = pb[i]-1
        pc.append(pa[j])
        sc.append(sb[i]*sa[j])
    return (tuple(pc), tuple(sc))

def inv_signed(a):
    p,s=a
    invp=[None]*7
    for i,pi in enumerate(p, start=1):
        invp[pi-1]=i
    invs=[None]*7
    for k in range(1,8):
        j=invp[k-1]
        invs[k-1]=s[j-1]
    return (tuple(invp), tuple(invs))

def commutator(a,b):
    return compose_signed(inv_signed(a), compose_signed(inv_signed(b), compose_signed(a,b)))

def group_closure(gens, ID):
    gens=list(gens)+[inv_signed(g) for g in gens]
    S={ID}; frontier=[ID]
    while frontier:
        x=frontier.pop()
        for g in gens:
            y=compose_signed(g,x)
            if y not in S:
                S.add(y); frontier.append(y)
    return S

def orbits_of_subgroup(generators, n=192):
    seen=[False]*n; orbits=[]
    for i in range(n):
        if seen[i]: continue
        stack=[i]; seen[i]=True; orb=[]
        while stack:
            x=stack.pop(); orb.append(x)
            for gen in generators:
                y=gen[x]
                if not seen[y]:
                    seen[y]=True; stack.append(y)
        orbits.append(sorted(orb))
    return orbits

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--axis", default="axis_line_stabilizer_192.json")
    ap.add_argument("--flag_model", default="tomotope_flag_model_192.json")
    ap.add_argument("--flag_adj", default="flag_adjacency_r0_r3_permutations.json")
    args=ap.parse_args()

    axis=json.load(open(args.axis,"r"))
    H_elems=axis["elements"]
    stab_to_elem={e["stab_index"]:(tuple(e["perm"]),tuple(e["signs"])) for e in H_elems}
    ID=stab_to_elem[7]

    model=json.load(open(args.flag_model,"r"))
    stab_indices=model["flags_ordering"]["stab_indices"]
    ordered_reps=[stab_to_elem[s] for s in stab_indices]
    rep_to_index={rep:i for i,rep in enumerate(ordered_reps)}

    # generators r0..r3 (signed reps)
    gen_signed={d["name"]:(tuple(d["perm"]),tuple(d["signs"])) for d in model["generators_r0_r3"]}

    # right adjacency perms (on 192 flags)
    adj=json.load(open(args.flag_adj,"r"))
    adj_perms={k:adj[k] for k in ["r0","r1","r2","r3"]}

    # edge orbits (exclude r2)
    edge_orbits=orbits_of_subgroup([adj_perms[g] for g in ["r0","r1","r3"]], n=192)
    flag_to_edge={}
    for eid,orb in enumerate(edge_orbits):
        for f in orb:
            flag_to_edge[f]=eid

    def perm_left_by(h_rep):
        return [rep_to_index[compose_signed(h_rep, rep)] for rep in ordered_reps]

    def induced_perm_on_edges(h_rep):
        pflags=perm_left_by(h_rep)
        img=[None]*len(edge_orbits)
        for eid,orb in enumerate(edge_orbits):
            f=orb[0]
            eid2=flag_to_edge[pflags[f]]
            for f2 in orb[1:]:
                assert flag_to_edge[pflags[f2]]==eid2
            img[eid]=eid2
        return tuple(img)

    # tomotope group P
    p0=perm_from_cycles(12, [[5,10],[6,9],[7,12],[8,11]])
    p1=perm_from_cycles(12, [[1,6],[2,5],[3,8],[4,7]])
    p2=perm_from_cycles(12, [[5,9],[6,10],[7,11],[8,12]])
    p3=perm_from_cycles(12, [[5,8],[6,7],[9,12],[10,11]])
    P=group_generated([p0,p1,p2,p3])
    P_perms=[tuple(x-1 for x in p) for p in P]

    # Reye orbits on 3-subsets
    orbits3=orbit_decomp_k_subsets(P_perms, 12, 3)
    size16=[o for o in orbits3 if len(o)==16]

    # commutator subgroup and quotient
    comm_gens=[]
    names=list(gen_signed.keys())
    for i in range(len(names)):
        for j in range(i+1,len(names)):
            comm_gens.append(commutator(gen_signed[names[i]], gen_signed[names[j]]))
    C=group_closure(comm_gens, ID)

    # cosets with ID first
    H=set(ordered_reps)
    Cset=set(C)
    coset_of={}
    coset_reps=[ID]
    for x in set(compose_signed(ID,c) for c in Cset):
        coset_of[x]=0
    unassigned=set(H)-set(coset_of.keys())
    while unassigned:
        rep=next(iter(unassigned))
        coset=set(compose_signed(rep,c) for c in Cset)
        cid=len(coset_reps)
        coset_reps.append(rep)
        for x in coset:
            coset_of[x]=cid
        unassigned-=coset

    # three index-2 subgroups
    idx2={}
    for k in [1,2,3]:
        idx2[k]=set([x for x in H if coset_of[x] in (0,k)])

    # output stats
    stats={
        "tomotope_P_orbits_on_2subsets_sizes": orbit_decomp_2subsets(P_perms, 12),
        "axis192_model_edge_orbits_count": len(edge_orbits),
        "axis192_model_edge_orbit_size": len(edge_orbits[0]),
        "index2_subgroups":[]
    }

    rep_to_stab={stab_to_elem[s]:s for s in stab_to_elem}
    for k,subset in idx2.items():
        induced=set(induced_perm_on_edges(h) for h in subset)
        # order distribution on induced
        def perm_order(perm):
            visited=[False]*12
            lcm=1
            for i in range(12):
                if visited[i]: continue
                j=i; cyc=0
                while not visited[j]:
                    visited[j]=True
                    j=perm[j]
                    cyc+=1
                lcm=lcm*cyc//math.gcd(lcm,cyc)
            return lcm
        od=collections.Counter(perm_order(p) for p in induced)
        stats["index2_subgroups"].append({
            "id": f"H_idx2_{k}",
            "size": len(subset),
            "stab_indices_sorted": sorted(rep_to_stab[r] for r in subset),
            "induced_edge_action_group_order": len(induced),
            "orbits_on_2subsets_sizes": orbit_decomp_2subsets(list(induced), 12),
            "induced_edge_action_order_distribution": {str(k2):v for k2,v in sorted(od.items())}
        })

    with open("axis192_index2_edge_action_stats.json","w") as f:
        json.dump(stats,f,indent=2)

    with open("tomotope_p_generators.json","w") as f:
        json.dump({
            "p0": {"cycles":[[5,10],[6,9],[7,12],[8,11]], "perm_1based": list(p0)},
            "p1": {"cycles":[[1,6],[2,5],[3,8],[4,7]], "perm_1based": list(p1)},
            "p2": {"cycles":[[5,9],[6,10],[7,11],[8,12]], "perm_1based": list(p2)},
            "p3": {"cycles":[[5,8],[6,7],[9,12],[10,11]], "perm_1based": list(p3)},
            "group_order": len(P),
        }, f, indent=2)

    with open("tomotope_edge_group_P_elements.json","w") as f:
        json.dump({"order":len(P),"elements":[list(p) for p in sorted(P)]},f)

    # Reye outputs (orbit #1)
    orbit1=size16[0]
    with open("reye_line_orbits_from_P.json","w") as f:
        json.dump({
            "orbits_on_3subsets_sizes":[len(o) for o in orbits3],
            "size16_orbits":[{"orbit_id":i+1,"lines_1based":[[a+1,b+1,c+1] for (a,b,c) in orb]} for i,orb in enumerate(size16)]
        },f,indent=2)

    inc=[[0]*16 for _ in range(12)]
    for j,L in enumerate(orbit1):
        for p in L:
            inc[p][j]=1
    with open("reye_incidence_12x16.csv","w",newline="") as f:
        w=csv.writer(f)
        w.writerow(["point\\line"]+[f"L{j+1}" for j in range(16)])
        for i in range(12):
            w.writerow([i+1]+inc[i])

    with open("reye_lines_1based.txt","w") as f:
        for L in orbit1:
            f.write(" ".join(str(x+1) for x in L)+"\n")

    # report
    P_sig=orbit_decomp_2subsets(P_perms, 12)
    axis_sig=stats["index2_subgroups"][0]["orbits_on_2subsets_sizes"]
    with open("REPORT.md","w") as f:
        f.write(f\"\"\"# Tomotope edge action compare

Tomotope P on 2-subsets orbit sizes: **{P_sig}**  
Axis-192 candidates on 2-subsets orbit sizes: **{axis_sig}**  

This mismatch is a hard conjugacy obstruction: no relabeling can match the induced edge action.
\"\"\")

    print("Wrote outputs into current directory.")

if __name__ == "__main__":
    main()
