# Tomotope edge-action vs axis-192 induced edge-actions (hard conjugacy obstruction)

**Bundle:** TOE_tomotope_edge_action_compare_v01_20260228_bundle.zip  
**Date:** 2026-02-28T10:34:28.886940Z

---

## A) Tomotope edge symmetry group `P` from published `p0..p3`

Generators (acting on 12 labels):
- p0 = (5 10)(6 9)(7 12)(8 11)
- p1 = (1 6)(2 5)(3 8)(4 7)
- p2 = (5 9)(6 10)(7 11)(8 12)
- p3 = (5 8)(6 7)(9 12)(10 11)

Computed:
- **|P| = 96**

### Conjugacy invariant used
Orbit decomposition of `P` acting on 2-subsets \(\binom{[12]}{2}\).

Result:
- **P has 4 orbits** on 2-subsets, sizes:
  - **[48, 6, 6, 6]**

This signature is invariant under relabeling (conjugation in \(S_{12}\)).

---

## B) Reconstructing the Reye (12₄,16₃) incidence from `P`

Orbit decomposition of `P` acting on 3-subsets \(\binom{[12]}{3}\):

Sizes:
- [48, 48, 48, 16, 16, 16, 16, 12]

Key fact:
- There are **four distinct orbits of size 16**, and **each one** is a valid (12₄,16₃) configuration:
  - each line is a triple,
  - each point occurs in exactly 4 triples,
  - any two lines intersect in 0 or 1 point.

Saved in:
- `reye_line_orbits_from_P.json`
- `reye_incidence_12x16.csv` (for orbit #1)
- `reye_lines_1based.txt` (for orbit #1)

---

## C) Axis-192 model: three index-2 subgroups (order 96) and their induced actions on the model’s “12 edges”

We use the **axis-192 192-flag model** already present in the repo work:
- flags = 192
- right-adjacency generators `r0,r1,r2,r3` define the 4-colored flag graph

The model has **12 edge-like objects** as the orbit partition obtained by **excluding `r2`**:
- 12 orbits, each of size 16.

Now take the **three index-2 subgroups of H (order 192)** arising from:
- commutator subgroup order 48,
- abelianization order 4 (so exactly **3** index-2 kernels).

For each index-2 subgroup (size 96), compute its induced permutation group on the 12 edge-orbits, then compute the same conjugacy invariant.

Result:
- **Every axis-192 candidate 96-group has 3 orbits** on 2-subsets, sizes:
  - **[48, 12, 6]**

Saved in:
- `axis192_index2_edge_action_stats.json`

---

## D) Final obstruction (hard “no”)

Tomotope `P` has 2-subset orbit signature:
- **[48, 6, 6, 6]**

Axis-192 candidate 96-groups have signature:
- **[48, 12, 6]**

These are different, so **no relabeling exists** that can conjugate any of the axis-192 induced edge actions to the tomotope’s published edge action.

So:

✅ **The “192 ↔ tomotope” numerology is real** (triality/W(D4) layer).  
❌ **Our current axis-192 flag/edge monodromy model is not the tomotope maniplex.**

---

## Files

- `tomotope_p_generators.json`
- `tomotope_edge_group_P_elements.json`
- `reye_line_orbits_from_P.json`
- `reye_incidence_12x16.csv`
- `reye_lines_1based.txt`
- `axis192_index2_edge_action_stats.json`

(Plus `recompute_tomotope_edge_action_compare.py` in this bundle.)
