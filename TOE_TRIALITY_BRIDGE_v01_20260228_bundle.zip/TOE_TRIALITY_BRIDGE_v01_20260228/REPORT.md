# Triality Bridge v01 (2026-02-28)

This bundle locks down a *structural* (not just numerological) bridge between three layers we already had in the repo/bundles:

- **Tomotope monodromy** \(\Gamma\) (order 18432) with exact factorization \(\Gamma = N \bowtie P_0\),
- **Axis line stabilizer** \(H\) (order 192) acting regularly on the axis-192 torsor,
- **K pocket weld** subgroup \(K\) (order 162) with Z3 cocycle on 270 Schreier edges.

## A. Tomotope: the order-3 “triality” inside the 12-step rotation

Let \(t=r_1 r_2\) in *axis coordinates* (so it matches the exact-factorization bundle). Then:

- \(\mathrm{ord}(t)=12\)
- \(t^4\) has **order 3** and factorizes as a *pure stabilizer* element:
  - \(t^4 = (n=1)\cdot(p\in P_0)\)

The action of \(t^4\) on the **48** \(\langle r_0,r_3\rangle\)-blocks (each a 4-flag fiber) is extremely rigid:

- every 4-flag block maps onto **exactly 3** blocks
- the resulting “image triples” form a symmetric 48\_3 configuration (48 triples, each block appears in exactly 3 triples)
- the induced 2-section graph on blocks is **6-regular** with its 144 edges decomposed into **48 edge-disjoint triangles** (one per triple)

See:
- `tomotope_t4_axis_block_image_triples.csv`
- `tomotope_t4_axis_block_graph_edges.csv`
- `tomotope_t4_axis_triality_summary.json`

## B. 64-state sectors: both N and H have exactly 3 Sylow-2 subgroups of order 64

### B1. Tomotope internal 192-layer N
Inside the tomotope exact factorization \(\Gamma=N\bowtie P_0\), the regular subgroup \(|N|=192\) has:

- Sylow-2 subgroups of order 64
- **exactly 3** distinct such Sylow-2 subgroups under conjugation in N
- an explicit order-3 element of N (index 14 in the N enumeration) whose conjugation cycles them as a 3-cycle.

See: `tomotope_N_sylow2_triality.json`

### B2. Axis 192-layer H
The axis-line stabilizer \(|H|=192\) has the same “3×64” Sylow-2 sector structure:

- **exactly 3** Sylow-2 subgroups of order 64 under conjugation
- the order-3 element corresponding to the K-weld stabilizer sigma=(1,3,5,0,2,4,6) is **H index 71** and cycles those three Sylow-2 subgroups by conjugation
- right multiplication by that element on the 192 torsor is **64 disjoint 3-cycles** (regular triality)

See: `axis_H_sylow2_triality.json`

## C. K-weld: the Z3 cocycle is literally “which triality element in H”

The pocket Schreier-edge cocycle values exp∈Z3 correspond to:

- exp=0 → identity in H (index 7)
- exp=1 → H index 71 (order 3)
- exp=2 → H index 46 (order 3, inverse)

See: `K_Z3_voltage_to_H_triality_elements.json`

## D. Heisenberg/S3 picture
The order-3 element in the K stabilizer has a GL(2,3) matrix action on \(\mathbb{F}_3^2\) that **fixes one** projective line in \(\mathbb{P}^1(\mathbb{F}_3)\) and cycles the other three — the same “1+3 triality” pattern as the Sylow-2 sector cycling.

See: `K_triality_action_on_P1F3.json`
