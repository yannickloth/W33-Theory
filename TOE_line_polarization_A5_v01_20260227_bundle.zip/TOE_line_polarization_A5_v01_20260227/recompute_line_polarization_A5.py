#!/usr/bin/env python3
"""
Recompute the holonomy-induced line digraph and the hidden A5 structure.

Default inputs match the repository/bundle layout used in these TOE bundles.
You can override with command line flags.

Outputs are written into the current working directory.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
from collections import defaultdict, Counter, deque
import numpy as np
import networkx as nx
import pandas as pd
import itertools

def canon_cycle(seq):
    s=list(seq)
    rots=[tuple(s[i:]+s[:i]) for i in range(len(s))]
    return min(rots)

def load_json(p: Path):
    return json.loads(p.read_text())

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir_srg", type=str, default="/mnt/data/TOE_E6pair_SRG_triangle_decomp_v01_20260227/TOE_E6pair_SRG_triangle_decomp_v01_20260227")
    ap.add_argument("--dir_map", type=str, default="/mnt/data/TOE_edge_to_oriented_rootpairs_v01_20260227/TOE_edge_to_oriented_rootpairs_v01_20260227")
    ap.add_argument("--sp43_w33_action_json", type=str, default="/mnt/data/TOE_pocket_transport_glue_orbit480_v01_20260227_bundle/TOE_WELD_480S_v01_20260227/sp43_generators_w33_action.json")
    ap.add_argument("--w33_line_map_json", type=str, default="/mnt/data/TOE_E6pair_SRG_triangle_decomp_v01_20260227/TOE_E6pair_SRG_triangle_decomp_v01_20260227/w33_line_to_e6pair_triangles.json")
    args = ap.parse_args()

    DIR_SRG = Path(args.dir_srg)
    DIR_MAP = Path(args.dir_map)

    A = np.load(DIR_SRG/"e6pair_srg_adj_36x36.npy")
    blocks = load_json(DIR_SRG/"triangle_decomposition_120_blocks.json")["blocks"]
    pairs36 = load_json(DIR_SRG/"e6_antipode_pairs_36.json")["pairs"]
    rootpair_to_id={frozenset(p):i for i,p in enumerate(pairs36)}

    edge_to_oriented_rootpairs = load_json(DIR_MAP/"edge_to_oriented_rootpair_triple.json")

    # face->two oriented lifts (cyclic order on the 3 vertices)
    tri_set_to_oriented=defaultdict(list)
    for ekey,pairs in edge_to_oriented_rootpairs.items():
        ids=[]
        for a,b in pairs:
            ids.append(rootpair_to_id[frozenset((a,b))])
        tri_set=tuple(sorted(ids))
        tri_set_to_oriented[tri_set].append((ekey, tuple(ids)))
    assert len(tri_set_to_oriented)==120
    assert all(len(v)==2 for v in tri_set_to_oriented.values())

    # canonical orientation per face
    tri_orient={}
    for tri_set,lst in tri_set_to_oriented.items():
        opts=[]
        for ekey, ids in lst:
            opts.append((canon_cycle(ids), ekey, ids))
        opts.sort(key=lambda x:x[0])
        tri_orient[tri_set]=opts[0][0]

    # edge->third vertex in chosen face
    edge_to_third={}
    for tri in blocks:
        a,b,c=tri
        for u,v,w in [(a,b,c),(a,c,b),(b,c,a)]:
            e=tuple(sorted((u,v)))
            edge_to_third[e]=w

    # edge tail orientation from chosen faces
    edge_tail={}
    for tri in blocks:
        tri_set=tuple(sorted(tri))
        x,y,z=tri_orient[tri_set]
        for (a,b) in [(x,y),(y,z),(z,x)]:
            e=tuple(sorted((a,b)))
            edge_tail[e]=a
    assert len(edge_tail)==360

    c_e={e:(0 if edge_tail[e]==e[0] else 1) for e in edge_tail}

    # build SRG graph
    G=nx.Graph()
    G.add_nodes_from(range(36))
    for i in range(36):
        for j in range(i+1,36):
            if A[i,j]:
                G.add_edge(i,j)

    chosen=set(tuple(sorted(tri)) for tri in blocks)

    # enumerate all SRG triangles and odd nonface ones
    all_tri=set()
    for u in range(36):
        nbr=list(G.neighbors(u))
        for i in range(len(nbr)):
            for j in range(i+1,len(nbr)):
                a,b=nbr[i],nbr[j]
                if G.has_edge(a,b):
                    all_tri.add(tuple(sorted((u,a,b))))
    assert len(all_tri)==1200

    odd_nonface=set()
    for tri in all_tri:
        a,b,c=tri
        edges=[tuple(sorted((a,b))),tuple(sorted((b,c))),tuple(sorted((c,a)))]
        back=sum(c_e[e] for e in edges)
        hol=back%2
        if tri not in chosen and hol==1:
            odd_nonface.add(tri)
    assert len(odd_nonface)==240

    def edge_face(u,v):
        w=edge_to_third[tuple(sorted((u,v)))]
        return tuple(sorted((u,v,w)))

    def img_face(tri):
        a,b,c=tri
        A_=edge_to_third[tuple(sorted((a,b)))]
        B_=edge_to_third[tuple(sorted((a,c)))]
        C_=edge_to_third[tuple(sorted((b,c)))]
        return tuple(sorted((A_,B_,C_)))

    # special faces: those hit by 6 odd nonface triangles under img_face
    pre=Counter(img_face(t) for t in odd_nonface)
    special_faces=set([f for f,k in pre.items() if k==6])
    assert len(special_faces)==40

    # map special face -> line_id via provided line map
    line_map = load_json(Path(args.w33_line_map_json))
    face_to_line={}
    for lm in line_map:
        lid=lm["line_id"]
        for tb in lm["triangle_blocks"]:
            f=tuple(sorted(tb))
            if f in special_faces:
                face_to_line[f]=lid
    assert len(face_to_line)==40

    # build the directed line digraph from odd nonface triangles
    dir_edges=[]
    rows=[]
    for tri in odd_nonface:
        F_img=img_face(tri)
        tail=face_to_line[F_img]
        a,b,c=tri
        ef=[edge_face(a,b),edge_face(a,c),edge_face(b,c)]
        sp=[f for f in ef if f in special_faces]
        assert len(sp)==1
        head=face_to_line[sp[0]]
        dir_edges.append((tail,head))
        rows.append({
            "tail_line": tail,
            "head_line": head,
            "tri_a": tri[0], "tri_b": tri[1], "tri_c": tri[2],
            "image_face": ",".join(map(str,F_img)),
            "edge_special_face": ",".join(map(str,sp[0])),
            "holonomy": 1
        })

    DG=nx.DiGraph()
    DG.add_nodes_from(range(40))
    DG.add_edges_from(dir_edges)
    assert DG.number_of_edges()==240
    assert set(dict(DG.out_degree()).values())=={6}
    assert set(dict(DG.in_degree()).values())=={6}

    UG=DG.to_undirected()
    comps=[sorted(list(c)) for c in nx.connected_components(UG)]
    comp_sizes=[len(c) for c in comps]

    # identify 10-component as L(K5)
    comp10=[c for c in comps if len(c)==10][0]
    sub10=UG.subgraph(comp10).copy()
    K5=nx.complete_graph(5)
    LK5=nx.line_graph(K5)
    gm=nx.isomorphism.GraphMatcher(sub10, LK5)
    assert gm.is_isomorphic()
    iso=next(gm.isomorphisms_iter())
    iso_map={int(k): tuple(sorted(map(int,v))) for k,v in iso.items()}

    # compute stabilizer subgroup (inside PSp action induced from Sp(4,3) matrices) that preserves DG
    sp_w33 = load_json(Path(args.sp43_w33_action_json))
    gens_perm40=[g["perm40"] for g in sp_w33["generators"]]

    # line_id -> set of points
    lineid_to_points={lm["line_id"]: tuple(sorted(lm["w33_points"])) for lm in line_map}
    line_sets=[set(lineid_to_points[lid]) for lid in range(40)]
    set_to_lineid={tuple(sorted(s)): lid for lid,s in enumerate(line_sets)}

    def induce_line_perm(perm40):
        out=[None]*40
        for lid,pts in enumerate(line_sets):
            img=tuple(sorted(perm40[p] for p in pts))
            out[lid]=set_to_lineid[img]
        return tuple(out)

    gens_line=[induce_line_perm(p) for p in gens_perm40]
    # generate PSp subgroup (size 25920) on lines
    idperm=tuple(range(40))
    seen={idperm}
    dq=deque([idperm])
    while dq:
        cur=dq.popleft()
        for g in gens_line:
            nxt=tuple(g[i] for i in cur)
            if nxt not in seen:
                seen.add(nxt); dq.append(nxt)
    # should be 25920
    # check stabilizer of DG
    DG_edge_set=set(dir_edges)
    DG_edge_list=list(DG_edge_set)
    def preserves(perm):
        for u,v in DG_edge_list:
            if (perm[u],perm[v]) not in DG_edge_set:
                return False
        return True
    stab=[perm for perm in seen if preserves(perm)]

    # export
    pd.DataFrame(rows).sort_values(["tail_line","head_line","tri_a","tri_b","tri_c"]).to_csv("line_digraph_edges_240.csv", index=False)
    ud=set(tuple(sorted((u,v))) for u,v in dir_edges)
    pd.DataFrame([{"u":u,"v":v} for u,v in sorted(ud)]).to_csv("line_undirected_edges_120.csv", index=False)
    Path("line_components.json").write_text(json.dumps({
        "components": comps,
        "sizes": comp_sizes,
        "comp10": comp10,
        "note": "Components of the undirected version of the holonomy-induced line graph."
    }, indent=2))
    Path("comp10_isomorphism_to_LK5.json").write_text(json.dumps(iso_map, indent=2))
    # find small generating set for stab
    def compose(p,q):
        return tuple(p[i] for i in q)
    gens_stab=[]
    cur=set([idperm])
    # greedy
    for _ in range(10):
        improved=False
        for g in stab:
            # closure size if added
            ss={idperm}
            dd=deque([idperm])
            for gg in gens_stab+[g]:
                pass
            dd=deque([idperm])
            ss={idperm}
            while dd:
                x=dd.popleft()
                for gg in gens_stab+[g]:
                    y=compose(gg,x)
                    if y not in ss:
                        ss.add(y); dd.append(y)
            if len(ss)>len(cur):
                gens_stab.append(g)
                cur=ss
                improved=True
                break
        if not improved:
            break
        if len(cur)==len(stab):
            break
    Path("stabilizer_A5_generators.json").write_text(json.dumps({
        "size": len(stab),
        "generators": [list(g) for g in gens_stab],
        "note": "Stabilizer subgroup inside PSp(4,3) on W33 lines preserving the line digraph. Size 60 (A5)."
    }, indent=2))

    print("OK")
    print("odd_nonface:", len(odd_nonface))
    print("special_faces:", len(special_faces))
    print("DG edges:", DG.number_of_edges())
    print("components:", comp_sizes)
    print("stab size:", len(stab))

if __name__ == "__main__":
    main()
