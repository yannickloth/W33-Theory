# Clifford / HW model on 40 rays vs rank‑6 idempotents

- Built projective 2‑qubit Clifford size: 30001
- Stabilizer size preserving the 40 rays: 342
- Induced permutation group size on 40 rays: 78
- Generator count (greedy): 15

## Max commutator Frobenius norm over generators
- E0: 0.806226
- E1: 3.04822
- E2: 3.76497
- E3: 3.88015
- E4: 3.8873
- E5: 3.02306

Interpretation: norms ~0 => idempotent commutes with the induced Clifford symmetry.
