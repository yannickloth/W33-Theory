# Aha consolidation: E6 firewall as complement + XZ/Y channel prohibition

- pool edges in H27 nonorth: 243
- Schläfli edges: 216
- bad edges: 27

## Signature rates
- bad: {'n': 27, 'has_XZ_rate': 0.0, 'm_edge_rate': 0.4074074074074074, 'k_sum0_rate': 0.5925925925925926, 'k_eq_rate': 0.0}
- schlafli: {'n': 216, 'has_XZ_rate': 0.25, 'm_edge_rate': 0.3888888888888889, 'k_sum0_rate': 0.48148148148148145, 'k_eq_rate': 0.14814814814814814}

## Key findings
- bad edges have has_XZ_rate = 0.0 (forbid t=(1,1) in either direction)
- Schläfli edges have has_XZ_rate = 0.25 (XZ channel used substantially)
- bad edges also have k_eq_rate = 0.0 (k1 never equals k2), while Schläfli edges have k_eq_rate > 0
- Therefore the firewall is not random: it forbids the composite/fermion translation channel and enforces an asymmetric phase-key condition.

## Interpretation
- Interpret t=(t0,t1) as Pauli translation X^t0 Z^t1; t=(1,1)=XZ~iY (composite/fermion channel).
- E6 bad predicate removes exactly those nonorth pairs whose induced translation would involve the composite channel; Schläfli keeps the remaining edges that support full Pauli-frame transport.
- This makes the E6 kernel a 'code subspace' where the full Pauli/Clifford network operates; bad edges are the syndrome-forbidden transitions.
