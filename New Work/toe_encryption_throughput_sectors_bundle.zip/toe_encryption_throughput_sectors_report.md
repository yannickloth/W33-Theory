# Encryption framing: sector throughput and firewall rates

attempted = nonorth (nonzero overlap)
authenticated = N180 (unique handshake)
blocked = E6 bad predicate (firewall)

## Sector counts
{'4': 18, '3': 22}

## Throughput by sector (per-state averages)
- E0: n=0, attempt=0.000, auth=0.000, blocked=0.000, auth_rate=0.000, block/attempt=0.000, entropy=0.000
- E1: n=0, attempt=0.000, auth=0.000, blocked=0.000, auth_rate=0.000, block/attempt=0.000, entropy=0.000
- E2: n=0, attempt=0.000, auth=0.000, blocked=0.000, auth_rate=0.000, block/attempt=0.000, entropy=0.000
- E3: n=22, attempt=27.000, auth=9.000, blocked=1.636, auth_rate=0.333, block/attempt=0.061, entropy=0.693
- E4: n=18, attempt=27.000, auth=9.000, blocked=1.000, auth_rate=0.333, block/attempt=0.037, entropy=0.671
- E5: n=0, attempt=0.000, auth=0.000, blocked=0.000, auth_rate=0.000, block/attempt=0.000, entropy=0.000

## Notes
- Hard sector assignment is argmax diag(Ei) per state (proxy for sector membership).
- Attempted edges: all nonorth pairs. Authenticated: N180 pairs. Blocked: E6 bad predicate pairs.
- Rates are per-state averages; entropy measures how broadly a sector connects to other sectors via authenticated edges.
