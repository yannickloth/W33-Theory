# W33 Bose–Mesner algebra: intersection numbers, minimal polynomials, orthogonality

Relations: ['I', 'E20', 'E40', 'E180', 'N']

## Orthogonality checks
- P^T diag(m) P = n diag(k): **FAIL**
- Q^T diag(k) Q = n diag(m): **FAIL**

- n = 40
- multiplicities m = [10, 5, 10, 5, 10]
- valencies k = [1, 1, 2, 9, 27]

## Minimal polynomials
- I: `x - 1`
- E20: `x**2 - 1`
- E40: `x**3 - 4*x`
- E180: `x**3 - 9*x`
- N: `x**3 - 9*x`

## Selected structure constants (examples)
- E20*E20: {'I': 1, 'E20': 0, 'E40': 0, 'E180': 0, 'N': 0}
- E20*E40: {'I': 0, 'E20': 0, 'E40': 1, 'E180': 0, 'N': 0}
- E40*E40: {'I': 2, 'E20': 2, 'E40': 0, 'E180': 0, 'N': 0}
- E180*E180: {'I': 9, 'E20': 0, 'E40': 0, 'E180': 2, 'N': 2}
- N*N: {'I': 27, 'E20': 18, 'E40': 18, 'E180': 18, 'N': 18}

(Full table is in `w33_intersection_numbers.json`.)
