# Quotient-by-blocks analysis for the 10×K4 parabolic

We use the canonical parabolic block system: 10 blocks of size 4, each block induces K4 = E20∪E40.

## Block neighbor counts matrix C
Each entry C[i,j] is the number of W33-neighbors a vertex in block i has in block j.

Row sums (should be 12): [12, 12, 12, 12, 12, 12, 12, 12, 12, 12]

Distinct C rows (pattern -> count):
- (3, 1, 1, 1, 1, 1, 1, 1, 1, 1): 1
- (1, 3, 1, 1, 1, 1, 1, 1, 1, 1): 1
- (1, 1, 3, 1, 1, 1, 1, 1, 1, 1): 1
- (1, 1, 1, 3, 1, 1, 1, 1, 1, 1): 1
- (1, 1, 1, 1, 3, 1, 1, 1, 1, 1): 1
- (1, 1, 1, 1, 1, 3, 1, 1, 1, 1): 1
- (1, 1, 1, 1, 1, 1, 3, 1, 1, 1): 1
- (1, 1, 1, 1, 1, 1, 1, 3, 1, 1): 1
- (1, 1, 1, 1, 1, 1, 1, 1, 3, 1): 1
- (1, 1, 1, 1, 1, 1, 1, 1, 1, 3): 1

## Quotient graph on 10 blocks
Degree distribution: Counter({9: 10})
SRG check (lambda values set, mu values set): (10, 9, [8], [])

## Interpretation
- This quotient object is the 'quotient scheme on Ω/E' in Higman/ KMZ parametrization, with v=4 blocks.
