# Canonical Schläfli(27) embedding inside the Witting/W33 40-state geometry

We use the intrinsic W33 Schläfli construction on H27(v): for a chosen vertex v, take its 27 non-neighbors (H27) and connect u~w iff:
- u and w have 4 common neighbors in the full graph, and
- u and w do NOT have 4 common neighbors inside H12(v).

This yields SRG(27,16,10,8) (Schläfli graph) for every choice of v.

## Chosen v = 0
- H27 size: 27
## Counts
- K6 cliques (sixes): 72
- double-sixes: 36

## Example double-six (global ray indices)
- A_global: [1, 4, 5, 10, 18, 38]
- B_global: [3, 8, 9, 15, 23, 36]
