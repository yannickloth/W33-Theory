# Globalizing Schläfli and double-six inside W33

- |Aut(W33)| = **51840**

- For each v0, Schläfli SRG(27,16,10,8) verified; double-sixes per v0: **36**

- Sample transport test: DS0 under random g lands in ds(g(v0)) for 10/10 samples.


## Stabilizers in full Aut(W33)

- Stab(DS0) in Aut(W33): **72**, orbit size: **720**

- Stab((v0,DS0)) in Aut(W33): **36**, orbit size: **1440**


## Canonical DS0 (unordered)

A = [4, 8, 12, 32, 35, 38]

B = [6, 7, 11, 31, 34, 37]


## Notes

- The per-v0 canonical choice is not expected to be equivariant (lex-min breaks symmetry),

  but membership transport (DS0 -> ds(g(v0))) should hold and does in sampled tests.

- The key global object is the *orbit* of (v0, DS) under Aut(W33), which is intrinsic.
