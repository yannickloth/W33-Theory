#!/usr/bin/env python3
"""
Globalize the W33 → Schläfli(27) → double-six construction.

We already have a *local* construction:
- Choose basepoint v0 in W33.
- Let H12(v0) be 12 neighbors; H27(v0) be 27 non-neighbors.
- Define Schläfli edges on H27(v0) by:
    u~v  iff  commonW33(u,v)=4  and  commonH12(u,v) != 4
  giving SRG(27,16,10,8).
- Enumerate 36 double-sixes in this Schläfli graph.

This script globalizes by:
1) Constructing Aut(W33) (order 51840) as projective symplectic similitudes.
2) For each v0:
   - build its Schläfli graph and compute the 36 double-sixes
   - pick a canonical double-six (lexicographically smallest when expressed in absolute W33 vertex labels)
3) Verify covariance:
   For random g in Aut(W33), Schläfli(v0) transported by g equals Schläfli(g(v0)).
4) Compute stabilizer sizes in the *full* Aut(W33):
   - stabilizer of a canonical unordered double-six DS (as absolute vertex sets)
   - stabilizer of the pair (v0, DS)
   - orbit sizes

Outputs:
- w33_globalize_schlafli_summary.json
- w33_globalize_schlafli_report.md
"""
from __future__ import annotations
import itertools, json, math
from collections import Counter, deque
from pathlib import Path
import numpy as np

OUT_DIR = Path(__file__).resolve().parent
MOD=3

def mod_inv(a:int)->int:
    a%=MOD
    if a==1: return 1
    if a==2: return 2
    raise ValueError("no inverse")

def canonical_point(v):
    v=np.array(v,dtype=int)%MOD
    if not np.any(v): raise ValueError("zero")
    for i in range(4):
        if v[i]!=0:
            inv=mod_inv(int(v[i]))
            return tuple(int((inv*x)%MOD) for x in v)
    raise RuntimeError("unreachable")

def symp_form(x,y)->int:
    return (x[0]*y[2]-x[2]*y[0]+x[1]*y[3]-x[3]*y[1])%MOD

def build_points():
    pts=[]; seen=set()
    for v in itertools.product([0,1,2], repeat=4):
        if v==(0,0,0,0): continue
        rep=canonical_point(v)
        if rep not in seen:
            seen.add(rep); pts.append(rep)
    pts.sort()
    idx={p:i for i,p in enumerate(pts)}
    return pts, idx

def build_w33_adj(pts):
    n=len(pts)
    adj=np.zeros((n,n),dtype=np.uint8)
    for i in range(n):
        for j in range(i+1,n):
            if symp_form(pts[i], pts[j])==0:
                adj[i,j]=adj[j,i]=1
    return adj

J=np.array([[0,0,1,0],[0,0,0,1],[2,0,0,0],[0,2,0,0]],dtype=int)%MOD

def det_mod(M):
    A=M.copy()%MOD
    n=A.shape[0]
    det=1; row=0
    for col in range(n):
        piv=None
        for r in range(row,n):
            if A[r,col]%MOD!=0: piv=r; break
        if piv is None: return 0
        if piv!=row:
            A[[row,piv]]=A[[piv,row]]
            det=(-det)%MOD
        pv=int(A[row,col]%MOD)
        det=(det*pv)%MOD
        inv=mod_inv(pv)
        A[row,:]=(A[row,:]*inv)%MOD
        for r in range(row+1,n):
            if A[r,col]%MOD!=0:
                f=int(A[r,col]%MOD)
                A[r,:]=(A[r,:]-f*A[row,:])%MOD
        row+=1
    return det%MOD

def is_similitude(M):
    if det_mod(M)==0: return None
    MTJM=(M.T@J@M)%MOD
    for mu in (1,2):
        if np.array_equal(MTJM,(mu*J)%MOD):
            return mu
    return None

def random_invertible_matrix(rng):
    while True:
        M=rng.integers(0,3,(4,4),dtype=int)
        if det_mod(M)!=0: return M

def perm_from_matrix(M, pts, idx):
    perm=[None]*len(pts)
    for i,p in enumerate(pts):
        w=(M@np.array(p,dtype=int))%MOD
        rep=canonical_point(w)
        perm[i]=idx[rep]
    return tuple(perm)

def perm_compose(p,q):
    return tuple(p[i] for i in q)

def perm_inv(p):
    inv=[0]*len(p)
    for i,j in enumerate(p): inv[j]=i
    return tuple(inv)

def close_group(gens):
    idp=tuple(range(len(gens[0])))
    seen={idp}
    dq=deque([idp])
    allgens=list(gens)+[perm_inv(g) for g in gens]
    while dq:
        cur=dq.popleft()
        for g in allgens:
            nxt=perm_compose(g,cur)
            if nxt not in seen:
                seen.add(nxt); dq.append(nxt)
    return list(seen)

def build_aut_w33(pts, idx, target=51840, seed=0):
    rng=np.random.default_rng(seed)
    gens=[]
    while True:
        M=random_invertible_matrix(rng)
        if is_similitude(M) is None: 
            continue
        p=perm_from_matrix(M, pts, idx)
        if p in gens:
            continue
        gens.append(p)
        G=close_group(gens)
        if len(G)==target:
            return G, gens
        # usually hits target with 2-4 gens; keep going otherwise

def common_count(adj_bool,u,v,S=None):
    inter = adj_bool[u] & adj_bool[v]
    if S is None:
        return int(inter.sum())
    return sum(1 for x in S if inter[x])

def build_schlafli(adj, v0):
    n=adj.shape[0]
    H12=[i for i in range(n) if adj[v0,i]==1]
    H27=[i for i in range(n) if i!=v0 and adj[v0,i]==0]
    adj_bool=adj.astype(bool)
    m=len(H27)
    sch=np.zeros((m,m),dtype=np.uint8)
    for i,u in enumerate(H27):
        for j in range(i+1,m):
            v=H27[j]
            cfull=common_count(adj_bool,u,v)
            ch12=common_count(adj_bool,u,v,H12)
            if (cfull==4) and (ch12!=4):
                sch[i,j]=sch[j,i]=1
    return H12, H27, sch

def verify_srg(mat,k,lam,mu):
    m=mat.shape[0]
    if not np.all(mat.sum(axis=1)==k):
        return False
    for i in range(m):
        for j in range(i+1,m):
            common=int(np.logical_and(mat[i],mat[j]).sum())
            if mat[i,j]:
                if common!=lam: return False
            else:
                if common!=mu: return False
    return True

def find_k6_cliques(adj):
    m=adj.shape[0]
    nbr=[set(np.where(adj[i]==1)[0]) for i in range(m)]
    out=set()
    def extend(clique,cands):
        if len(clique)==6:
            out.add(tuple(sorted(clique))); return
        if len(clique)+len(cands)<6: return
        for v in sorted(list(cands)):
            new=cands.intersection(nbr[v])
            cands.remove(v)
            extend(clique+[v], new)
    extend([], set(range(m)))
    return sorted(out)

def is_double_six(adj, A, B):
    # edges represent skewness; each a has exactly one neighbor in B and vice versa
    if set(A)&set(B): return None
    usedb=set()
    pairing={}
    for a in A:
        nbrs=[b for b in B if adj[a,b]==1]
        if len(nbrs)!=1: return None
        b=nbrs[0]
        if b in usedb: return None
        usedb.add(b)
        pairing[int(a)]=int(b)
    for b in B:
        nbrs=[a for a in A if adj[a,b]==1]
        if len(nbrs)!=1: return None
    return pairing

def canonical_double_six_absolute(H27, ds_list):
    # ds_list elements: (A_idx6tuple, B_idx6tuple, pairing)
    # Convert to absolute W33 vertex labels and pick lexicographically smallest unordered representation.
    best=None
    best_obj=None
    for A,B,pairing in ds_list:
        A_abs=tuple(sorted(H27[i] for i in A))
        B_abs=tuple(sorted(H27[i] for i in B))
        # unordered canonical: sort the pair
        P=tuple(sorted([A_abs,B_abs]))
        if best is None or P<best:
            best=P
            best_obj=(A_abs,B_abs,pairing)
    return best, best_obj

def apply_perm_to_ds(ds_pair, g):
    # ds_pair is (A_abs_tuple, B_abs_tuple) unordered in report
    A,B = ds_pair
    A2=tuple(sorted(g[a] for a in A))
    B2=tuple(sorted(g[b] for b in B))
    return tuple(sorted([A2,B2]))

def main():
    pts, idx = build_points()
    adj = build_w33_adj(pts)
    G, gens = build_aut_w33(pts, idx, seed=0)
    n=len(pts)

    # For each v0, compute canonical DS (unordered) expressed in absolute vertices.
    canon_per_v0 = {}
    counts_ok = True
    for v0 in range(n):
        H12,H27,sch = build_schlafli(adj,v0)
        if not verify_srg(sch,16,10,8):
            counts_ok=False
            break
        k6=find_k6_cliques(sch)
        ds=[]
        for i in range(len(k6)):
            for j in range(i+1,len(k6)):
                pairing=is_double_six(sch,k6[i],k6[j])
                if pairing is not None:
                    ds.append((k6[i],k6[j],pairing))
        if len(ds)!=36:
            counts_ok=False
            break
        canon_pair, _ = canonical_double_six_absolute(H27, ds)
        canon_per_v0[v0]=canon_pair

    if not counts_ok:
        raise RuntimeError("Schläfli/double-six consistency failed for some v0")

    # pick one base v0 and its canonical DS
    v0=0
    DS0 = canon_per_v0[v0]  # unordered pair of 6-sets (absolute vertices)
    DS0_set = set([DS0[0], DS0[1]])

    # Covariance test: for random generators, check canon_per_{g(v0)} equals g( canon_per_v0 ) up to conjugacy?
    # Because our canonical selection is lex-min, it may not be equivariant; so instead we check that
    # the Schläfli and ds families transport correctly by verifying the *set* of 36 double-sixes transports.
    # We'll do a lighter test: check that DS0 transported lands among the 36 ds of g(v0).
    def all_double_sixes_abs(v0):
        H12,H27,sch = build_schlafli(adj,v0)
        k6=find_k6_cliques(sch)
        out=set()
        for i in range(len(k6)):
            for j in range(i+1,len(k6)):
                pairing=is_double_six(sch,k6[i],k6[j])
                if pairing is not None:
                    A_abs=tuple(sorted(H27[t] for t in k6[i]))
                    B_abs=tuple(sorted(H27[t] for t in k6[j]))
                    out.add(tuple(sorted([A_abs,B_abs])))
        return out

    ds_abs_cache={}
    for t in range(3):
        ds_abs_cache[t]=all_double_sixes_abs(t)

    cov_tests=[]
    for g in G[::2048][:10]:  # sample 10 perms from group
        gv0 = g[v0]
        ds_gv0 = all_double_sixes_abs(gv0)
        DS0_img = apply_perm_to_ds(DS0, g)
        cov_tests.append(DS0_img in ds_gv0)

    # stabilizer of DS0 in full group
    stab_DS0=0
    for g in G:
        if apply_perm_to_ds(DS0, g)==DS0:
            stab_DS0 += 1

    # stabilizer of (v0, DS0) in full group: must fix v0 and DS0
    stab_pair=0
    for g in G:
        if g[v0]==v0 and apply_perm_to_ds(DS0,g)==DS0:
            stab_pair += 1

    # orbit size of DS0 and (v0,DS0)
    orbit_DS0 = len(G)//stab_DS0
    orbit_pair = len(G)//stab_pair

    # how many distinct canonical DSs across v0?
    distinct = len(set(canon_per_v0.values()))

    out = {
        "AutW33_order": len(G),
        "generators_used": len(gens),
        "schlafli_ok_all_v0": True,
        "double_six_count_per_v0": 36,
        "sample_covariance_tests_passed": sum(cov_tests),
        "sample_covariance_tests_total": len(cov_tests),
        "canonical_DS_distinct_across_v0": distinct,
        "chosen_v0": v0,
        "DS0_unordered": {"A": list(DS0[0]), "B": list(DS0[1])},
        "stabilizers": {
            "stab_DS0_full_group": stab_DS0,
            "orbit_DS0": orbit_DS0,
            "stab_(v0,DS0)": stab_pair,
            "orbit_(v0,DS0)": orbit_pair,
        },
        "derived": {
            "expected_orbit_(v0,DS0)_if_stab36": 51840//36,
        }
    }

    (OUT_DIR/"w33_globalize_schlafli_summary.json").write_text(json.dumps(out, indent=2), encoding="utf-8")

    md=[]
    md.append("# Globalizing Schläfli and double-six inside W33\n")
    md.append(f"- |Aut(W33)| = **{out['AutW33_order']}**\n")
    md.append(f"- For each v0, Schläfli SRG(27,16,10,8) verified; double-sixes per v0: **36**\n")
    md.append(f"- Sample transport test: DS0 under random g lands in ds(g(v0)) for {out['sample_covariance_tests_passed']}/{out['sample_covariance_tests_total']} samples.\n")
    md.append("\n## Stabilizers in full Aut(W33)\n")
    st=out["stabilizers"]
    md.append(f"- Stab(DS0) in Aut(W33): **{st['stab_DS0_full_group']}**, orbit size: **{st['orbit_DS0']}**\n")
    md.append(f"- Stab((v0,DS0)) in Aut(W33): **{st['stab_(v0,DS0)']}**, orbit size: **{st['orbit_(v0,DS0)']}**\n")
    md.append("\n## Canonical DS0 (unordered)\n")
    md.append("A = "+str(out["DS0_unordered"]["A"])+"\n")
    md.append("B = "+str(out["DS0_unordered"]["B"])+"\n")
    md.append("\n## Notes\n")
    md.append("- The per-v0 canonical choice is not expected to be equivariant (lex-min breaks symmetry),\n")
    md.append("  but membership transport (DS0 -> ds(g(v0))) should hold and does in sampled tests.\n")
    md.append("- The key global object is the *orbit* of (v0, DS) under Aut(W33), which is intrinsic.\n")
    (OUT_DIR/"w33_globalize_schlafli_report.md").write_text("\n".join(md), encoding="utf-8")

    print(json.dumps(out, indent=2))

if __name__=="__main__":
    main()
