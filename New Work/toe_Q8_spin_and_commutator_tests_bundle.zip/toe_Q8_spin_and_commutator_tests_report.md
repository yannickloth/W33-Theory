# Q8 lift tests: spin invariance on triangles + commutator phase on 4-cycles

## Triangle spin invariance
- p-set-size counts over unordered triples: {'1': 43, '2': 77}
- odd class p-set sizes: {'1': 19, '2': 41}
- even class p-set sizes: {'1': 24, '2': 36}

## 4-cycle commutator phase
- p counts: {'0': 3040, '2': 2000}
- (h,p) counts: {'(0, 0)': 1296, '(0, 2)': 864, '(1, 0)': 1744, '(1, 2)': 1136}

## Key takeaways
- The Q8 lift introduces a spin/sign phase p in Z4; observed holonomies only use p in {0,2} (±1), consistent with a Z2 spin refinement.
- On unordered triples, matrix class h is invariant; p is generally NOT invariant (p_values size often 2). This matches the idea that spin structure is orientation-sensitive unless a spin structure/gauge is fixed.
- Odd syndrome class triples (h=1) show different p-set-size statistics than even class, indicating the curvature syndrome correlates with spin refinement.
- 4-cycle holonomies yield a robust distribution over p that can be interpreted as a commutator/braiding phase observable.
