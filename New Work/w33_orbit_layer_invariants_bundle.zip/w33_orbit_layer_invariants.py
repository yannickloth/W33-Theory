# See summary/report for the computed edge partition induced by canonical K.
