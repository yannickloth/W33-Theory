# Canonical K orbit layers => canonical edge partition of W33

We found that each global double-six DS has exactly 2 anchors (two vertices v such that DS ⊂ H27(v)).

For the canonical K (order 720) inside G0, the four DS orbit layers [60,120,180,360] correspond to three disjoint edge-sets of the W33 point graph.


## Edge partition (intrinsic)

- E20: **20** edges, degree-1 at every vertex (perfect matching)

- E40: **40** edges, degree-2 at every vertex, decomposes into **10 disjoint 4-cycles**

- E180: **180** edges, degree-9 at every vertex (remaining edges)


## Layer ↔ edge multiplicity

- Layer60: exactly the E20 edges, each appearing in **3** DS (60 = 20×3)

- Layer120: exactly the E40 edges, each appearing in **3** DS (120 = 40×3)

- Layer180: exactly the E180 edges, each appearing in **1** DS

- Layer360: exactly the E180 edges, each appearing in **2** DS (360 = 180×2)


## E40 cycles (10 squares)

- [0, 2, 3, 1]

- [4, 13, 31, 22]

- [5, 16, 36, 26]

- [6, 30, 38, 19]

- [7, 23, 35, 20]

- [8, 27, 37, 14]

- [9, 17, 33, 28]

- [10, 18, 39, 24]

- [11, 25, 32, 21]

- [12, 15, 34, 29]
