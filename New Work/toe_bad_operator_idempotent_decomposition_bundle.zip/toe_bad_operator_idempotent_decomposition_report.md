# Decomposing the E6 'bad' predicate in the rank‑6 idempotent basis

- chosen v: 0
- H27 size: 27
- bad edges: 27

## Sector averages (alpha_i = Tr(Ei bad)/Tr(Ei))
- E0: alpha=1.35
- E1: alpha=-0.15
- E2: alpha=-0.15
- E3: alpha=-0.15
- E4: alpha=0.15
- E5: alpha=0.15

## Scalar-fit residuals ||Ei bad Ei - alpha_i Ei||_F
- E0: resid=1.53185e-15
- E1: resid=1.25499
- E2: resid=0.972111
- E3: resid=1.8775
- E4: resid=2.24165
- E5: resid=0.67082

## Normalized coupling matrix (||Ei bad Ej|| / sqrt(tr(Ei)tr(Ej)))
[[1.35, 0.15, 0.15, 0.15, 0.15, 0.15], [0.15, 0.2598076211, 0.2179449472, 0.0866025404, 0.15, 0.15], [0.15, 0.2179449472, 0.1190238071, 0.2179449472, 0.15, 0.15], [0.15, 0.0866025404, 0.2179449472, 0.1936491673, 0.15, 0.15], [0.15, 0.15, 0.15, 0.15, 0.2291287847, 0.2872281323], [0.15, 0.15, 0.15, 0.15, 0.2872281323, 0.15]]
