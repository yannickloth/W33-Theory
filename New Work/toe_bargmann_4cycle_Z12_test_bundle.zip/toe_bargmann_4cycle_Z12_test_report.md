# Bargmann 4-cycle phase holonomy on the N180 connection

We compute gauge-invariant 4-cycle phases: <A|B><B|C><C|D><D|A>, where states are chosen by N180-parallel transport of x0=(0,0) along a block loop A->B->C->D->A.

## Phase quantization
- Quantization grid: 2π/12 (π/6)
- Observed exponents k: [0, 2, 4, 6, 8, 10]
- Counts by k: {10: 900, 0: 720, 2: 900, 4: 360, 6: 360, 8: 360}

## Closure vs phase
- Closure counts (xA2==x0): {True: 720, False: 2880}
- Shift counts: {(0, 0): 720, (0, 1): 1440, (1, 0): 1440}

## Affine holonomy (4-loop)
- {'matrix': 'I', 't': [0, 0], 'count': 720}
- {'matrix': 'I', 't': [1, 1], 'count': 1440}
- {'matrix': 'S', 't': [0, 1], 'count': 1440}
- {'matrix': 'S', 't': [1, 0], 'count': 1440}

Phase distributions by holonomy value:
- ('I', (0, 0)): {10: 180, 2: 180, 6: 360}
- ('S', (0, 1)): {0: 360, 10: 360, 2: 360, 4: 180, 8: 180}
- ('S', (1, 0)): {10: 360, 0: 360, 2: 360, 4: 180, 8: 180}

## Key insights
- Bargmann 4-cycle phases along N180-parallel transported loops are quantized on the pi/6 grid but land in even exponents (a Z6 subgroup of Z12).
- Closed loops (fiber returns to x0) yield only phases {exp(±iπ/3), -1}; non-closed loops yield additional phases {1, exp(±i2π/3)}.
- Affine 4-loop holonomy takes exactly 4 values; the holonomy class (I vs swap and translation) controls the phase distribution.
- This is an explicit discrete gauge-theory analog: translation part corresponds to fiber shift, matrix part to Z2 topological class, and Bargmann phases provide a cyclic refinement.
