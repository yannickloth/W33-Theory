# Rank-6 scheme refinement of W33 partition

Relations: ['I', 'E20', 'E40', 'E180', 'N180', 'N360']

Valencies: [1, 1, 2, 9, 9, 18]

Commutative: True
All products decomposed in 6-basis exactly: True

## P eigenmatrix
|Ei| I | E20 | E40 | E180 | N180 | N360 |
|---|---|---|---|---|---|---|
|E0| 1 | 1 | 2 | 9 | 9 | 18 |
|E1| 1 | 1 | -2 | 3 | 3 | -6 |
|E2| 1 | 1 | 2 | -1 | -1 | -2 |
|E3| 1 | -1 | 0 | 3 | -3 | 0 |
|E4| 1 | -1 | 0 | -3 | 3 | 0 |
|E5| 1 | 1 | -2 | -3 | -3 | 6 |

## Multiplicities
[1, 5, 9, 10, 10, 5]

## Minimal combo used to split into 6 eigenspaces
{'E20': -3, 'E40': -3, 'E180': -3, 'N180': -2, 'N360': -1}

## Notes
- This shows the previous rank-5 scheme splits the non-edge relation N into N180 (valency 9) and N360 (valency 18).
- The refined rank-6 algebra has 6 primitive idempotents and exact structure constants.
