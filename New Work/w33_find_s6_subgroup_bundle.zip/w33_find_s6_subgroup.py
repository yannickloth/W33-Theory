#!/usr/bin/env python3
"""
Heuristic search for an order-720 subgroup inside Aut(W33), then test whether it
acts regularly on the 720-element double-six orbit.

Rationale:
- Aut(W33) has order 51840.
- The orbit of an unordered double-six DS0 has size 720 (stabilizer size 72).
- If we can find a subgroup K of order 720 whose orbit on DS0 also has size 720,
  then K acts transitively with trivial stabilizer => regular action.
  That gives a concrete S6-sized backbone.

This script:
1) Builds Aut(W33) as permutations on 40 points.
2) Builds DS0 (unordered, absolute) from v0=0 local construction.
3) Computes DS_orbit (size 720) under full group.
4) Randomly searches for a subgroup of order 720 by closing generated subgroups.
5) When found, checks orbit size of DS0 under subgroup.
6) Records element-order distribution of subgroup (as a fingerprint).

Outputs:
- w33_find_s6_subgroup_summary.json
"""
from __future__ import annotations
import itertools, json, random, math
from pathlib import Path
from collections import deque, Counter
import numpy as np

OUT_DIR = Path(__file__).resolve().parent
MOD=3

def mod_inv(a:int)->int:
    a%=MOD
    if a==1: return 1
    if a==2: return 2
    raise ValueError("no inverse")

def canonical_point(v):
    v=np.array(v,dtype=int)%MOD
    if not np.any(v): raise ValueError("zero")
    for i in range(4):
        if v[i]!=0:
            inv=mod_inv(int(v[i]))
            return tuple(int((inv*x)%MOD) for x in v)
    raise RuntimeError("unreachable")

def symp_form(x,y)->int:
    return (x[0]*y[2]-x[2]*y[0]+x[1]*y[3]-x[3]*y[1])%MOD

def build_points():
    pts=[]; seen=set()
    for v in itertools.product([0,1,2], repeat=4):
        if v==(0,0,0,0): continue
        rep=canonical_point(v)
        if rep not in seen:
            seen.add(rep); pts.append(rep)
    pts.sort()
    idx={p:i for i,p in enumerate(pts)}
    return pts, idx

def build_w33_adj(pts):
    n=len(pts)
    adj=np.zeros((n,n),dtype=np.uint8)
    for i in range(n):
        for j in range(i+1,n):
            if symp_form(pts[i],pts[j])==0:
                adj[i,j]=adj[j,i]=1
    return adj

J=np.array([[0,0,1,0],[0,0,0,1],[2,0,0,0],[0,2,0,0]],dtype=int)%MOD

def det_mod(M):
    A=M.copy()%MOD
    n=A.shape[0]
    det=1; row=0
    for col in range(n):
        piv=None
        for r in range(row,n):
            if A[r,col]%MOD!=0: piv=r; break
        if piv is None: return 0
        if piv!=row:
            A[[row,piv]]=A[[piv,row]]
            det=(-det)%MOD
        pv=int(A[row,col]%MOD)
        det=(det*pv)%MOD
        inv=mod_inv(pv)
        A[row,:]=(A[row,:]*inv)%MOD
        for r in range(row+1,n):
            if A[r,col]%MOD!=0:
                f=int(A[r,col]%MOD)
                A[r,:]=(A[r,:]-f*A[row,:])%MOD
        row+=1
    return det%MOD

def is_similitude(M):
    if det_mod(M)==0: return None
    MTJM=(M.T@J@M)%MOD
    for mu in (1,2):
        if np.array_equal(MTJM,(mu*J)%MOD): return mu
    return None

def random_invertible_matrix(rng):
    while True:
        M=rng.integers(0,3,(4,4),dtype=int)
        if det_mod(M)!=0: return M

def perm_from_matrix(M, pts, idx):
    perm=[None]*len(pts)
    for i,p in enumerate(pts):
        w=(M@np.array(p,dtype=int))%MOD
        rep=canonical_point(w)
        perm[i]=idx[rep]
    return tuple(perm)

def perm_compose(p,q):
    return tuple(p[i] for i in q)

def perm_inv(p):
    inv=[0]*len(p)
    for i,j in enumerate(p): inv[j]=i
    return tuple(inv)

def close_group(gens):
    idp=tuple(range(len(gens[0])))
    seen={idp}
    dq=deque([idp])
    allgens=list(gens)+[perm_inv(g) for g in gens]
    while dq:
        cur=dq.popleft()
        for g in allgens:
            nxt=perm_compose(g,cur)
            if nxt not in seen:
                seen.add(nxt); dq.append(nxt)
    return list(seen)

def build_aut_w33(pts, idx, target=51840, seed=0):
    rng=np.random.default_rng(seed)
    gens=[]
    while True:
        M=random_invertible_matrix(rng)
        if is_similitude(M) is None: continue
        p=perm_from_matrix(M, pts, idx)
        if p in gens: continue
        gens.append(p)
        G=close_group(gens)
        if len(G)==target:
            return G, gens

def common_count(adj_bool,u,v,S=None):
    inter=adj_bool[u] & adj_bool[v]
    if S is None:
        return int(inter.sum())
    return sum(1 for x in S if inter[x])

def build_schlafli(adj,v0):
    n=adj.shape[0]
    H12=[i for i in range(n) if adj[v0,i]==1]
    H27=[i for i in range(n) if i!=v0 and adj[v0,i]==0]
    adj_bool=adj.astype(bool)
    m=len(H27)
    sch=np.zeros((m,m),dtype=np.uint8)
    for i,u in enumerate(H27):
        for j in range(i+1,m):
            v=H27[j]
            cfull=common_count(adj_bool,u,v)
            ch12=common_count(adj_bool,u,v,H12)
            if (cfull==4) and (ch12!=4):
                sch[i,j]=sch[j,i]=1
    return H27, sch

def verify_srg(mat,k,lam,mu):
    m=mat.shape[0]
    if not np.all(mat.sum(axis=1)==k):
        return False
    for i in range(m):
        for j in range(i+1,m):
            common=int(np.logical_and(mat[i],mat[j]).sum())
            if mat[i,j]:
                if common!=lam: return False
            else:
                if common!=mu: return False
    return True

def find_k6_cliques(adj):
    m=adj.shape[0]
    nbr=[set(np.where(adj[i]==1)[0]) for i in range(m)]
    out=set()
    def extend(clique,cands):
        if len(clique)==6:
            out.add(tuple(sorted(clique))); return
        if len(clique)+len(cands)<6: return
        for v in sorted(list(cands)):
            new=cands.intersection(nbr[v])
            cands.remove(v)
            extend(clique+[v], new)
    extend([], set(range(m)))
    return sorted(out)

def is_double_six(adj,A,B):
    if set(A)&set(B): return False
    usedb=set()
    for a in A:
        nbrs=[b for b in B if adj[a,b]==1]
        if len(nbrs)!=1: return False
        b=nbrs[0]
        if b in usedb: return False
        usedb.add(b)
    for b in B:
        nbrs=[a for a in A if adj[a,b]==1]
        if len(nbrs)!=1: return False
    return True

def ds_abs_list(adj,v0):
    H27, sch = build_schlafli(adj,v0)
    if not verify_srg(sch,16,10,8):
        raise RuntimeError("Schläfli check failed")
    k6=find_k6_cliques(sch)
    ds=set()
    for i in range(len(k6)):
        for j in range(i+1,len(k6)):
            if is_double_six(sch,k6[i],k6[j]):
                A_abs=tuple(sorted(H27[t] for t in k6[i]))
                B_abs=tuple(sorted(H27[t] for t in k6[j]))
                ds.add(tuple(sorted([A_abs,B_abs])))
    ds=sorted(ds)
    if len(ds)!=36:
        raise RuntimeError(f"Expected 36, got {len(ds)}")
    return ds

def apply_perm_to_ds(ds_pair, g):
    A,B=ds_pair
    A2=tuple(sorted(g[a] for a in A))
    B2=tuple(sorted(g[b] for b in B))
    return tuple(sorted([A2,B2]))

def element_order(p):
    n=len(p); vis=[False]*n; lcm=1
    for i in range(n):
        if not vis[i]:
            j=i; cyc=0
            while not vis[j]:
                vis[j]=True; j=p[j]; cyc+=1
            if cyc>0:
                lcm=lcm*cyc//math.gcd(lcm,cyc)
    return lcm

def main():
    pts,idx=build_points()
    adj=build_w33_adj(pts)
    G, gens = build_aut_w33(pts, idx, seed=0)
    DS0 = ds_abs_list(adj,0)[0]

    # compute full DS orbit
    orbit=set(apply_perm_to_ds(DS0,g) for g in G)
    orbit=list(orbit)
    assert len(orbit)==720
    orbit_set=set(orbit)

    rng=random.Random(0)

    # Precompute inverses for fast closure
    G_list=G
    inv_cache={g: perm_inv(g) for g in G_list}

    def close_subgroup(gen_list):
        idp=tuple(range(40))
        seen={idp}
        dq=deque([idp])
        gens=gen_list + [inv_cache[g] for g in gen_list]
        while dq:
            cur=dq.popleft()
            for g in gens:
                nxt=perm_compose(g,cur)
                if nxt not in seen:
                    seen.add(nxt); dq.append(nxt)
                if len(seen) > 2000:
                    # early exit if too big for our search target
                    return seen
        return seen

    found=None
    found_gens=None
    trials=0
    while trials < 5000 and found is None:
        trials += 1
        # choose 3 random generators from full group
        g1=G_list[rng.randrange(len(G_list))]
        g2=G_list[rng.randrange(len(G_list))]
        g3=G_list[rng.randrange(len(G_list))]
        H=close_subgroup([g1,g2,g3])
        if len(H)==720:
            found=list(H); found_gens=[g1,g2,g3]
            break

    result={
        "trials": trials,
        "found_subgroup": found is not None,
    }

    if found is not None:
        # test orbit of DS0 under subgroup
        orbH=set(apply_perm_to_ds(DS0,g) for g in found)
        result.update({
            "subgroup_order": 720,
            "DS0_orbit_under_subgroup": len(orbH),
            "DS0_stabilizer_in_subgroup": 720//len(orbH),
            "generator_orders": [element_order(g) for g in found_gens],
        })
        # fingerprint: sample element orders
        sample=[found[rng.randrange(len(found))] for _ in range(2000)]
        dist=Counter(element_order(p) for p in sample)
        result["sample_element_order_distribution"] = {str(k): int(v) for k,v in sorted(dist.items())}

    (OUT_DIR/"w33_find_s6_subgroup_summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))

if __name__=="__main__":
    main()
