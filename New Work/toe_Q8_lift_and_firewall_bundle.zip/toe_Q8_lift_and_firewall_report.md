# Q8/Quaternion lift + E6 firewall rule (compressed)

## 1) Q8 lift
Fiber keys x∈Z2^2 are Pauli exponents (a,b)↔X^a Z^b. Adding the Pauli ordering/commutation phase (a projective sign) yields a quaternion/Q8-type lift. Our observed connection uses only {I,H} linear parts and Z2^2 translations, generating a 16-element lifted subgroup with phase p∈{0,2} (± sign), i.e. a Q8-like double cover of the D4 transport.

Observed directed-edge transport types (D4 subgroup):
- {'M': 'I', 'Pauli': 'X^0Z^0', 'count': 20}
- {'M': 'H', 'Pauli': 'X^0Z^0', 'count': 16}
- {'M': 'I', 'Pauli': 'X^1Z^1', 'count': 12}
- {'M': 'I', 'Pauli': 'X^0Z^1', 'count': 10}
- {'M': 'I', 'Pauli': 'X^1Z^0', 'count': 10}
- {'M': 'H', 'Pauli': 'X^1Z^0', 'count': 8}
- {'M': 'H', 'Pauli': 'X^0Z^1', 'count': 8}
- {'M': 'H', 'Pauli': 'X^1Z^1', 'count': 6}

## 2) Lifted triangle holonomy
- distinct lifted holonomies: 8
- marginals: {'p_counts': {'0': 486, '2': 234}, 'h_counts': {'0': 360, '1': 360}, 'hp_counts': {'(0, 0)': 252, '(1, 0)': 234, '(1, 2)': 126, '(0, 2)': 108}}

## 3) Firewall = no composite channel
- XZ prohibition counts: {'bad_crossblock': 27, 'bad_with_XZ': 0, 'schlafli_crossblock': 216, 'schlafli_with_XZ': 54}

## Big picture
- Z2^2 fiber = Pauli exponent keyspace (frame).
- Transport maps = Clifford-like routers + Pauli translations.
- Triangle Z2 class = syndrome/parity-check design on triples.
- E6 firewall = witness-subset syndrome constraint AND ε-channel (XZ/Y) prohibition.
- Q8 lift introduces a spin/sign bit p refining curvature beyond Z2.

## Next execution
- Lift the stabilizer-code bridge to include the Q8 sign bit p and test whether p becomes orientation-invariant on the 2-(10,3,4) odd triples.
- Compute commutator/4-cycle phases in the lifted group and see whether the firewall corresponds to forbidding specific commutator phases (not just XZ translation).
