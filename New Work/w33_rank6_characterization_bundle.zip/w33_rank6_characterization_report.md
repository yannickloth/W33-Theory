# Intrinsic characterization of the rank‑6 refinement

We refine the W33-derived edge partition into a rank‑6 relation system by splitting the nonedge relation N into N180 and N360.

## Base edge partition (W33 edges)
- E20: perfect matching (20 edges, degree 1)
- E40: ten disjoint 4-cycles (40 edges, degree 2)
- E180: remaining edges (180 edges, degree 9)

## Nonedge split (new relation)
- N180: 180 nonedges, valency 9
- N360: 360 nonedges, valency 18

## The key intrinsic rule for N180
Let `mate(u)` be the unique vertex paired with u by the E20 perfect matching.

For a nonedge {u,v} of W33:

**{u,v} ∈ N180  ⇔  u ~ mate(v)  and  v ~ mate(u)** (adjacency in W33)

Equivalently: `A[u,mate(v)] = A[v,mate(u)] = 1`.

This rule matches the computed N180 adjacency matrix exactly, and yields precisely 180 nonedges.

## Why this matters
This provides a purely combinatorial (and fast) definition of the full rank‑6 scheme from the canonical K-induced matching E20 and the original W33 adjacency, without invoking spectral or product-based discovery.
