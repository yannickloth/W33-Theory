# Trinification cubic template solve (structured coefficient fit)

- templates K=6, support monomials p=45
- generators sampled: 80/82
- min eigenvalue: 4
- residual_energy_sampled: 4
- alpha: [0.0, 0.0, 0.0, 1.0, 0.0, 0.0]

- This is a structured least-squares/nullspace solve in a 6D template coefficient space: it finds the SU(3)^3 combination closest to invariant under the tested generators.
- If min_eigenvalue and residual_energy are near 0, we have a genuine structured cubic invariant in this coordinate basis.
- If not near 0, we either need richer SU(3)^3 templates or the coordinate system/generator set still isn’t aligned with the true stabilizer.

## Next
- Increase the generator sample size and repeat (stability check).
- Add more template families (e.g., mixed-slice contractions) to expand K.
- Use the learned coefficients as an initialization for full Sym^3(27) Lanczos restricted to this basis.
