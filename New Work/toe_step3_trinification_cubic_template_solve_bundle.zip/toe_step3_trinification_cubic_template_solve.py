# Template solve for trinification cubic coefficients; see JSON/MD.
