# Identification: Aut(2-(10,3,4)) ≅ S6 via duads/syntheme construction

We computed Aut(design) on 10 points has order 720. We now construct a *canonical* 6-letter set and show the induced action is full S6.

## Step 1: Find a 15-object orbit of 6-subsets
- There is an orbit of size 15 on 6-subsets of the 10 points.
- Intersection sizes among these 15 subsets are only 3 or 4 with counts 60 and 45, matching the duad graph of K6.

## Step 2: Build the duad graph
- Define adjacency if intersection size = 3 (60 edges). This matches “share-a-letter” adjacency.
- The resulting graph has 6 maximal cliques of size 5; these correspond to the 6 letters.

## Step 3: Induced action on 6 letters
- The induced group on the 6 letters has size 720 = 720.
- Therefore the action is the full symmetric group S6.

## Canonical objects
- 15 duads (as 6-subsets of the 10 points): see JSON.
- 6 letters (as 5-cliques of duads): see JSON.
