# W33 canonical edge refinement realizes a 10×K4 parabolic structure

- E40 decomposes into **10 disjoint 4-cycles**, giving a block system of 10 blocks of size 4.
- E20 is exactly the set of **diagonals** of those 4-cycles.
- Therefore inside each block: E20∪E40 is a complete graph K4 (valency 3).

## Checks
- E20_are_block_diagonals: True
- within_block_union_E20_E40_is_K4: True

## Interpretation
- E40 defines an imprimitive block system of 10 blocks of size 4 (a 10×4 parabolic).
- Within each block, E40 are the 4-cycle edges and E20 are the two diagonals; together E20∪E40 is K4 on the block.
- Thus the canonical K-induced refinement splits the parabolic relation 10∘K4 (valency 3) into valency-2 cycle edges + valency-1 diagonal matching.
- This matches the 'parabolic of type 10∘K4' language used in Higmanian scheme literature.
