# K10 symplectic-cycle construction for the 10-block base

## Base graph
- Nodes = 10 blocks
- Edges = all 45 pairs (K10)
- Cycle rank = E − V + 1 = 45 − 10 + 1 = **36**

## E6 hinge
**36** matches the classical count of **double-sixes** in Schläfli/E6 geometry.
Interpretation: the E6 hinge is the loop-space dimension of the 10-block base circuit.

## Explicit loop basis
We choose a spanning tree: star at 0. Each chord (i,j) with i,j in {1..9} yields a fundamental triangle cycle i–0–j–i.
The bundle includes:
- incidence matrix A (45×10)
- cycle incidence matrix C (36×45)
- explicit cycle list (one per chord)

## Phase-space blueprint
Attach to each loop a local clock variable:
- q ∈ Z2×Z2 (translation/charge bits)
- p ∈ Z6 (phase class)
- clock ∈ Z2×Z2×Z6 (24)

Total symbolic phase space: 24^36.
