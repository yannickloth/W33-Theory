# Exact rank‑6 rules in block/S6 form (no heuristics)

We represent the 40 states as 10 blocks of size 4 (3+3 partitions of 6 letters). Each state has an internal Z2×Z2 label (a,b) within its block.

## Rules
- **E20**: same block (3+3 partition) and internal Z2xZ2 label xor = (1,1) (diagonal mate)
- **E40**: same block and internal label xor in {(1,0),(0,1)} (4-cycle edges)
- **E180**: different blocks and orthogonal in Witting orth graph
- **N180**: different blocks and nonorth, and orth(i, mate(j)) AND orth(j, mate(i)) (mate-cross adjacency rule)
- **N360**: different blocks and nonorth, and NOT N180

## Mate operator
- mate is the E20 involution within each block: flips both bits in the internal Z2xZ2 coordinate.

## Notes on S6 meaning
- Each block corresponds to a 3+3 partition of the 6-letter set; the 4 states in a block correspond to orientation bits (Z2xZ2) on the two 3-cycles.
- E20 is the central (1,1) flip within that Z2xZ2; E40 are the two generators (1,0),(0,1) giving the 4-cycle.
- The nonorth split N180/N360 is not a pure relative cycle-type condition; it is a mate-twisted orthogonality condition, i.e. a 2-step predicate using the involution.

All rules were verified exactly against the rank‑6 relation matrices.
