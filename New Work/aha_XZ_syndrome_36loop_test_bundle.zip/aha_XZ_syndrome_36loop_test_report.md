# 36-loop basis test: syndrome vs XZ channel vs firewall overlap

## Summary by (syndrome_class, has_XZ_dir)
- {'class': 0, 'has_XZ_dir': False, 'loops': 18, 'bad_rate': 0.0}
- {'class': 1, 'has_XZ_dir': False, 'loops': 9, 'bad_rate': 0.08333333333333333}
- {'class': 1, 'has_XZ_dir': True, 'loops': 9, 'bad_rate': 0.0}

## Interpretation
- If the firewall is enforcing a syndrome constraint tied to XZ, loops with XZ-directed edges should show elevated bad overlap and/or align with syndrome class 1.
- This test lifts the state-level bad edge set to the 36-loop basis by counting how many of the 12 N180 state edges in each loop are firewalled.

See JSON for per-loop records.
