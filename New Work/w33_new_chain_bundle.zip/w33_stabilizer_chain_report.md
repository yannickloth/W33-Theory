# W33 stabilizer chain from a canonical Schläfli double-six

Computed purely inside Aut(W33) acting on 40 projective points.

- |Aut(W33)| = **51840**

- Fix v0 => |G_v0| = **1296** (index 40)

- Inside H27(v0) we build Schläfli SRG(27,16,10,8) and enumerate double-sixes.

## Stabilizer chain (within G_v0)

- Stab(unordered double-six): **36**, index **36**

- Stab(ordered (A,B)): **18**

- Stab(ordered + fix one a): **3**, index **6**


## Action on A (6 objects)

Order: **18**

Element-order distribution: {'1': 1, '2': 3, '3': 8, '6': 6}

Hint: distribution matches S3 x C3 (order2:3, order3:8, order6:6)


## Canonical double-six (indices in Schläfli 27-set)

A = [0, 4, 8, 19, 22, 25]

B = [2, 3, 7, 18, 21, 24]

Pairing A->B (skew edge) = {
  "0": 7,
  "4": 2,
  "8": 3,
  "19": 21,
  "22": 24,
  "25": 18
}
