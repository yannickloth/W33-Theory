#!/usr/bin/env python3
from __future__ import annotations
"""
Compute a stabilizer chain entirely inside Aut(W33) (order 51840), using a
W33-internal construction of the Schläfli SRG(27,16,10,8) on H27(v0), and then
enumerating double-sixes and stabilizers.

Outputs:
- w33_stabilizer_chain_summary.json
- w33_stabilizer_chain_report.md
"""

import itertools, json, math
from collections import deque, Counter
from pathlib import Path
import numpy as np

OUT_DIR = Path(__file__).resolve().parent
MOD = 3

def to_native(x):
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating,)):
        return float(x)
    if isinstance(x, (set, tuple, list)):
        return [to_native(v) for v in list(x)]
    if isinstance(x, dict):
        return {str(to_native(k)): to_native(v) for k,v in x.items()}
    return x

def mod_inv(a:int)->int:
    a%=MOD
    if a==1: return 1
    if a==2: return 2
    raise ValueError("no inverse")

def canonical_point(v):
    v=np.array(v,dtype=int)%MOD
    if not np.any(v): raise ValueError("zero")
    for i in range(4):
        if v[i]!=0:
            inv=mod_inv(int(v[i]))
            return tuple(int((inv*x)%MOD) for x in v)
    raise RuntimeError("unreachable")

def symp_form(x,y)->int:
    return (x[0]*y[2]-x[2]*y[0]+x[1]*y[3]-x[3]*y[1])%MOD

def build_points():
    pts=[]; seen=set()
    for v in itertools.product([0,1,2], repeat=4):
        if v==(0,0,0,0): continue
        rep=canonical_point(v)
        if rep not in seen:
            seen.add(rep); pts.append(rep)
    pts.sort()
    idx={p:i for i,p in enumerate(pts)}
    return pts, idx

def build_w33_adj(pts):
    n=len(pts)
    adj=np.zeros((n,n),dtype=np.uint8)
    for i in range(n):
        for j in range(i+1,n):
            if symp_form(pts[i], pts[j])==0:
                adj[i,j]=adj[j,i]=1
    return adj

J=np.array([[0,0,1,0],[0,0,0,1],[2,0,0,0],[0,2,0,0]],dtype=int)%MOD

def det_mod(M):
    A=M.copy()%MOD
    n=A.shape[0]
    det=1; row=0
    for col in range(n):
        piv=None
        for r in range(row,n):
            if A[r,col]%MOD!=0: piv=r; break
        if piv is None: return 0
        if piv!=row:
            A[[row,piv]]=A[[piv,row]]
            det=(-det)%MOD
        pv=int(A[row,col]%MOD)
        det=(det*pv)%MOD
        inv=mod_inv(pv)
        A[row,:]=(A[row,:]*inv)%MOD
        for r in range(row+1,n):
            if A[r,col]%MOD!=0:
                f=int(A[r,col]%MOD)
                A[r,:]=(A[r,:]-f*A[row,:])%MOD
        row+=1
    return det%MOD

def is_similitude(M):
    if det_mod(M)==0: return None
    MTJM=(M.T@J@M)%MOD
    for mu in (1,2):
        if np.array_equal(MTJM,(mu*J)%MOD):
            return mu
    return None

def random_invertible_matrix(rng):
    while True:
        M=rng.integers(0,3,(4,4),dtype=int)
        if det_mod(M)!=0: return M

def perm_from_matrix(M, pts, idx):
    perm=[None]*len(pts)
    for i,p in enumerate(pts):
        w=(M@np.array(p,dtype=int))%MOD
        rep=canonical_point(w)
        perm[i]=idx[rep]
    return tuple(perm)

def perm_compose(p,q):
    return tuple(p[i] for i in q)

def perm_inv(p):
    inv=[0]*len(p)
    for i,j in enumerate(p): inv[j]=i
    return tuple(inv)

def close_group(gens):
    idp=tuple(range(len(gens[0])))
    seen={idp}
    dq=deque([idp])
    allgens=list(gens)+[perm_inv(g) for g in gens]
    while dq:
        cur=dq.popleft()
        for g in allgens:
            nxt=perm_compose(g,cur)
            if nxt not in seen:
                seen.add(nxt); dq.append(nxt)
    return list(seen)

def build_aut_w33(pts, idx, target=51840, seed=0, max_gens=10):
    rng=np.random.default_rng(seed)
    gens=[]
    while True:
        M=random_invertible_matrix(rng)
        if is_similitude(M) is None:
            continue
        p=perm_from_matrix(M, pts, idx)
        if p in gens: 
            continue
        gens.append(p)
        G=close_group(gens)
        if len(G)==target:
            return G, gens
        if len(gens)>=max_gens:
            seed=int(rng.integers(0,2**32))
            rng=np.random.default_rng(seed)
            gens=[]

def common_count(adj_bool,u,v,S=None):
    inter = adj_bool[u] & adj_bool[v]
    if S is None:
        return int(inter.sum())
    return sum(1 for x in S if inter[x])

def build_schlafli_from_w33(adj, v0):
    n=adj.shape[0]
    H12=[i for i in range(n) if adj[v0,i]==1]
    H27=[i for i in range(n) if i!=v0 and adj[v0,i]==0]
    adj_bool=adj.astype(bool)
    m=len(H27)
    sch=np.zeros((m,m),dtype=np.uint8)
    for i,u in enumerate(H27):
        for j in range(i+1,m):
            v=H27[j]
            cfull=common_count(adj_bool,u,v)
            ch12=common_count(adj_bool,u,v,H12)
            if (cfull==4) and (ch12!=4):
                sch[i,j]=sch[j,i]=1
    return H12, H27, sch

def verify_srg(mat,k,lam,mu):
    m=mat.shape[0]
    if not np.all(mat.sum(axis=1)==k):
        return False
    for i in range(m):
        for j in range(i+1,m):
            common=int(np.logical_and(mat[i],mat[j]).sum())
            if mat[i,j]:
                if common!=lam: return False
            else:
                if common!=mu: return False
    return True

def find_k6_cliques(adj):
    m=adj.shape[0]
    nbr=[set(np.where(adj[i]==1)[0]) for i in range(m)]
    out=set()
    def extend(clique,cands):
        if len(clique)==6:
            out.add(tuple(sorted(clique))); return
        if len(clique)+len(cands)<6: return
        for v in sorted(list(cands)):
            new=cands.intersection(nbr[v])
            cands.remove(v)
            extend(clique+[v], new)
    extend([], set(range(m)))
    return sorted(out)

def is_double_six(adj, A, B):
    if set(A)&set(B): return None
    pairing={}; usedb=set()
    for a in A:
        nbrs=[b for b in B if adj[a,b]==1]
        if len(nbrs)!=1: return None
        b=nbrs[0]
        if b in usedb: return None
        pairing[int(a)]=int(b)
        usedb.add(b)
    for b in B:
        nbrs=[a for a in A if adj[a,b]==1]
        if len(nbrs)!=1: return None
    return pairing

def element_order(p):
    n=len(p); vis=[False]*n; lcm=1
    for i in range(n):
        if not vis[i]:
            j=i; cyc=0
            while not vis[j]:
                vis[j]=True; j=p[j]; cyc+=1
            if cyc>0:
                lcm=lcm*cyc//math.gcd(lcm,cyc)
    return lcm

def main():
    pts, idx = build_points()
    adj = build_w33_adj(pts)

    G, gens = build_aut_w33(pts, idx, seed=0)
    v0=0
    G_v0=[g for g in G if g[v0]==v0]

    H12, H27, sch = build_schlafli_from_w33(adj, v0)
    if not verify_srg(sch,16,10,8):
        raise RuntimeError("Schläfli SRG check failed")

    k6=find_k6_cliques(sch)
    ds=[]
    for i in range(len(k6)):
        for j in range(i+1,len(k6)):
            pairing=is_double_six(sch, k6[i], k6[j])
            if pairing is not None:
                ds.append((k6[i],k6[j],pairing))
    if len(ds)!=36:
        raise RuntimeError(f"Expected 36 double-sixes, got {len(ds)}")
    ds.sort(key=lambda t:(t[0],t[1]))
    A0=set(ds[0][0]); B0=set(ds[0][1]); pairing0=ds[0][2]

    # induced action of G_v0 on H27 indices
    hmap={u:i for i,u in enumerate(H27)}
    ind=set()
    for g in G_v0:
        perm=[None]*len(H27)
        for i,u in enumerate(H27):
            perm[i]=hmap[g[u]]
        ind.add(tuple(perm))
    ind=list(ind)

    stab_unord=[]
    stab_ord=[]
    for p in ind:
        Ap={p[i] for i in A0}
        Bp={p[i] for i in B0}
        if (Ap==A0 and Bp==B0) or (Ap==B0 and Bp==A0):
            stab_unord.append(p)
        if (Ap==A0 and Bp==B0):
            stab_ord.append(p)

    a_fix=min(A0)
    stab_fix_a=[p for p in stab_ord if p[a_fix]==a_fix]

    A_list=sorted(A0)
    pos={a:i for i,a in enumerate(A_list)}
    permA=set()
    for p in stab_ord:
        perm=[None]*6
        for a in A_list:
            perm[pos[a]] = pos[p[a]]
        permA.add(tuple(perm))
    ord_dist=Counter(element_order(p) for p in permA)

    summary = {
        "AutW33_order": len(G),
        "generators_used": len(gens),
        "v0": v0,
        "G_v0_order": len(G_v0),
        "G_v0_index_in_AutW33": len(G)//len(G_v0),
        "schlafli_SRG": {"n": 27, "k": 16, "lambda": 10, "mu": 8},
        "schlafli_counts": {"n_k6": len(k6), "n_double_sixes": len(ds)},
        "chosen_double_six": {"A": sorted(A0), "B": sorted(B0), "pairing_A_to_B_skew": pairing0},
        "stabilizer_chain": {
            "G_v0_DS_unordered_order": len(stab_unord),
            "G_v0_DS_unordered_index_in_G_v0": len(G_v0)//len(stab_unord),
            "G_v0_DS_ordered_order": len(stab_ord),
            "G_v0_DS_fix_one_a_order": len(stab_fix_a),
            "index_fix_one_a_in_ordered": len(stab_ord)//len(stab_fix_a),
        },
        "ordered_stabilizer_action_on_A": {
            "order": len(permA),
            "element_order_distribution": {str(k): int(v) for k,v in sorted(ord_dist.items())},
            "recognition_hint": "distribution matches S3 x C3 (order2:3, order3:8, order6:6)",
        }
    }

    summary_native = to_native(summary)
    (OUT_DIR/"w33_stabilizer_chain_summary.json").write_text(json.dumps(summary_native, indent=2), encoding="utf-8")

    md=[]
    md.append("# W33 stabilizer chain from a canonical Schläfli double-six\n")
    md.append("Computed purely inside Aut(W33) acting on 40 projective points.\n")
    md.append(f"- |Aut(W33)| = **{summary_native['AutW33_order']}**\n")
    md.append(f"- Fix v0 => |G_v0| = **{summary_native['G_v0_order']}** (index {summary_native['G_v0_index_in_AutW33']})\n")
    md.append(f"- Inside H27(v0) we build Schläfli SRG(27,16,10,8) and enumerate double-sixes.\n")
    ch=summary_native["stabilizer_chain"]
    md.append("## Stabilizer chain (within G_v0)\n")
    md.append(f"- Stab(unordered double-six): **{ch['G_v0_DS_unordered_order']}**, index **{ch['G_v0_DS_unordered_index_in_G_v0']}**\n")
    md.append(f"- Stab(ordered (A,B)): **{ch['G_v0_DS_ordered_order']}**\n")
    md.append(f"- Stab(ordered + fix one a): **{ch['G_v0_DS_fix_one_a_order']}**, index **{ch['index_fix_one_a_in_ordered']}**\n")
    md.append("\n## Action on A (6 objects)\n")
    md.append(f"Order: **{summary_native['ordered_stabilizer_action_on_A']['order']}**\n")
    md.append(f"Element-order distribution: {summary_native['ordered_stabilizer_action_on_A']['element_order_distribution']}\n")
    md.append(f"Hint: {summary_native['ordered_stabilizer_action_on_A']['recognition_hint']}\n")
    md.append("\n## Canonical double-six (indices in Schläfli 27-set)\n")
    md.append("A = " + str(summary_native["chosen_double_six"]["A"]) + "\n")
    md.append("B = " + str(summary_native["chosen_double_six"]["B"]) + "\n")
    md.append("Pairing A->B (skew edge) = " + json.dumps(summary_native["chosen_double_six"]["pairing_A_to_B_skew"], indent=2) + "\n")
    (OUT_DIR/"w33_stabilizer_chain_report.md").write_text("\n".join(md), encoding="utf-8")

    print(json.dumps(summary_native, indent=2))

if __name__=="__main__":
    main()
