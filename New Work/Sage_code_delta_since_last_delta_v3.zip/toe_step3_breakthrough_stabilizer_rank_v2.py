# Stabilizer rank v2; see JSON/MD for details.
