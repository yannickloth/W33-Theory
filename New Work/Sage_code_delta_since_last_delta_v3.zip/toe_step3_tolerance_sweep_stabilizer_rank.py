# Stabilizer rank tolerance sweep; see JSON/MD.
