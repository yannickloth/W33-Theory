# Full Sym^3-expanded invariance audit; see JSON/MD.
