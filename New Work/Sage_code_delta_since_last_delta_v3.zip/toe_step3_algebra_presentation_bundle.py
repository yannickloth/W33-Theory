# Algebra presentation draft; see JSON/MD.
