# Stabilizer tolerance sweep (rank vs tolerance)

- expanded U size: 3654
- min_eigenvalue: 1.670e-13
- residual_sum: 0.000e+00

## Sweep results
- tol=1e-08: stab_count=82, rank_est=146, gap_to_78=68
- tol=1e-10: stab_count=82, rank_est=146, gap_to_78=68
- tol=1e-12: stab_count=82, rank_est=146, gap_to_78=68

## Top offenders
- {'name': 'edge_9_16', 'residual': 0.0}
- {'name': 'edge_15_26', 'residual': 0.0}
- {'name': 'edge_7_13', 'residual': 0.0}
- {'name': 'edge_9_24', 'residual': 0.0}
- {'name': 'edge_9_20', 'residual': 0.0}
- {'name': 'edge_3_23', 'residual': 0.0}
- {'name': 'edge_17_18', 'residual': 0.0}
- {'name': 'edge_11_24', 'residual': 0.0}
- {'name': 'edge_4_21', 'residual': 0.0}
- {'name': 'edge_0_4', 'residual': 0.0}
- {'name': 'edge_16_18', 'residual': 0.0}
- {'name': 'edge_7_22', 'residual': 0.0}
- {'name': 'edge_18_24', 'residual': 0.0}
- {'name': 'edge_13_22', 'residual': 0.0}
- {'name': 'edge_0_23', 'residual': 0.0}

## Interpretation
- If rank_est stabilizes near 78 as tolerance tightens, we have pinned E6 as the cubic stabilizer algebra.
- If rank_est drops below 78 at very tight tolerances, invariance is only approximate (numeric) or we are excluding legitimate stabilizer directions due to basis truncation.
- If rank_est stays well above 78, the extracted generator set contains additional symmetries beyond E6; prune offenders and re-estimate.

## Next
- If a tolerance produces rank close to 78, freeze that stabilizer set as g* and proceed to explicit commutator relation extraction.
- Map stabilizer vs offender generators back to block-level ε/firewall structure to interpret symmetry breaking.
- Attempt to derive SU(3)^3 subgroup decomposition from the stabilizer generators in the 3×3×3 coordinates.
