# Algebra presentation draft (commutator projections)

- chosen_tol: 1e-12
- stabilizer_count: 82
- basis_subset_size: 40

## Sample commutator projections (first 20 pairs)
- (0,1) ('edge', 9, 16) , ('edge', 3, 21) -> top [] | residual 0.000e+00
- (0,2) ('edge', 9, 16) , ('edge', 4, 17) -> top [] | residual 0.000e+00
- (0,3) ('edge', 9, 16) , ('edge', 15, 16) -> top [] | residual 1.414e+00
- (0,4) ('edge', 9, 16) , ('edge', 6, 15) -> top [] | residual 0.000e+00
- (0,5) ('edge', 9, 16) , ('edge', 6, 16) -> top [] | residual 1.414e+00
- (0,6) ('edge', 9, 16) , ('edge', 20, 24) -> top [] | residual 0.000e+00
- (0,7) ('edge', 9, 16) , ('edge', 7, 20) -> top [] | residual 0.000e+00
- (0,8) ('edge', 9, 16) , ('edge', 6, 7) -> top [] | residual 0.000e+00
- (0,9) ('edge', 9, 16) , ('edge', 11, 20) -> top [] | residual 0.000e+00
- (0,10) ('edge', 9, 16) , ('edge', 1, 5) -> top [] | residual 0.000e+00
- (0,11) ('edge', 9, 16) , ('edge', 18, 19) -> top [] | residual 0.000e+00
- (0,12) ('edge', 9, 16) , ('edge', 19, 21) -> top [] | residual 0.000e+00
- (0,13) ('edge', 9, 16) , ('edge', 19, 24) -> top [] | residual 0.000e+00
- (0,14) ('edge', 9, 16) , ('edge', 17, 22) -> top [] | residual 0.000e+00
- (0,15) ('edge', 9, 16) , ('edge', 1, 19) -> top [] | residual 0.000e+00
- (0,16) ('edge', 9, 16) , ('edge', 6, 22) -> top [] | residual 0.000e+00
- (0,17) ('edge', 9, 16) , ('edge', 2, 24) -> top [] | residual 0.000e+00
- (0,18) ('edge', 9, 16) , ('edge', 23, 24) -> top [] | residual 0.000e+00
- (0,19) ('edge', 9, 16) , ('edge', 3, 8) -> top [] | residual 0.000e+00
- (0,20) ('edge', 9, 16) , ('edge', 8, 20) -> top [] | residual 0.000e+00

## Notes
- Structure constants are computed by projecting commutators onto the span of a basis subset; residual_norm indicates how well the commutator closes inside this subset.
- If residuals are small for most pairs, the subset is internally closing; otherwise increase basis size or use full stabilizer span.

## Next
- Increase basis_subset_size to 78 (or full stabilizer) and recompute closure residuals.
- Compute Cartan decomposition and root-space structure in the stabilizer.
- Map basis elements back to Schläfli edges and to trinification sectors (a,b,c) to interpret SU(3)^3 structure explicitly.
