# Breakthrough stabilizer rank v2 (full Sym^3-expanded, tol=1e-10)

- stabilizer count: 82/82
- rank estimate: 150
- gap to 78: 72
- expanded U size: 3654

## Top offenders
- {'i': 0, 'name': 'edge_9_16', 'residual': 0.0}
- {'i': 58, 'name': 'edge_15_26', 'residual': 0.0}
- {'i': 57, 'name': 'edge_7_13', 'residual': 0.0}
- {'i': 56, 'name': 'edge_9_24', 'residual': 0.0}
- {'i': 55, 'name': 'edge_9_20', 'residual': 0.0}
- {'i': 54, 'name': 'edge_3_23', 'residual': 0.0}
- {'i': 53, 'name': 'edge_17_18', 'residual': 0.0}
- {'i': 52, 'name': 'edge_11_24', 'residual': 0.0}
- {'i': 59, 'name': 'edge_4_21', 'residual': 0.0}
- {'i': 51, 'name': 'edge_0_4', 'residual': 0.0}
- {'i': 49, 'name': 'edge_16_18', 'residual': 0.0}
- {'i': 48, 'name': 'edge_7_22', 'residual': 0.0}
- {'i': 47, 'name': 'edge_18_24', 'residual': 0.0}
- {'i': 46, 'name': 'edge_13_22', 'residual': 0.0}
- {'i': 45, 'name': 'edge_0_23', 'residual': 0.0}
- {'i': 44, 'name': 'edge_4_12', 'residual': 0.0}
- {'i': 43, 'name': 'edge_2_20', 'residual': 0.0}
- {'i': 50, 'name': 'edge_4_19', 'residual': 0.0}
- {'i': 60, 'name': 'edge_11_26', 'residual': 0.0}
- {'i': 61, 'name': 'edge_14_19', 'residual': 0.0}

## Next
- Repeat rank estimate for tolerances 1e-12 and 1e-8 to see stability.
- Map stabilizer generators back to block pairs and check correlation with ε/firewall sectors (symmetry breaking).
- Write the stabilized algebra as a presentation: generators + commutator relations with phase labels.
