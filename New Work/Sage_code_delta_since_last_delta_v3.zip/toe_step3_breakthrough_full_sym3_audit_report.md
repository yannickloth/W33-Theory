# Breakthrough audit: full Sym^3-expanded invariance test

- expanded U size p: 3654 (iters=4, cap=3654)
- min_eigenvalue: 1.670e-13
- residual_sum (all gens): 0.000e+00
- threshold stabilizer counts: {'1e-08': 82, '1e-10': 82, '1e-12': 82}
- offender_count_at_1e-10: 0

## Top offenders
- {'i': 0, 'res': 0.0}
- {'i': 58, 'res': 0.0}
- {'i': 57, 'res': 0.0}
- {'i': 56, 'res': 0.0}
- {'i': 55, 'res': 0.0}
- {'i': 54, 'res': 0.0}
- {'i': 53, 'res': 0.0}
- {'i': 52, 'res': 0.0}
- {'i': 59, 'res': 0.0}
- {'i': 51, 'res': 0.0}
- {'i': 49, 'res': 0.0}
- {'i': 48, 'res': 0.0}
- {'i': 47, 'res': 0.0}
- {'i': 46, 'res': 0.0}
- {'i': 45, 'res': 0.0}

## Next
- Compute commutator-span rank for the stabilizer set at tolerance 1e-10 and compare to 78.
- Map top offenders back to edge labels (i,j) to see if they correlate with ε-channel / firewall modes.
- If needed, re-run subalgebra extraction with a hard constraint enforcing cubic invariance.
