# Test: does the E6 firewall preferentially hit triangles that expose the XZ channel?

We compare bad-edge overlap rates on the N180 triangle-edge sets, split by:
- triangle syndrome class (holonomy matrix I vs swap)
- whether the triangle includes any directed edge with translation t=(1,1) (XZ channel)

## Global rates
- bad_edges_count: 27
- triangles_total: 120
- triangles_with_XZ_dir: 66
- triangles_without_XZ_dir: 54
- rate_bad_on_triangles_with_XZ: 0.045454545454545456
- rate_bad_on_triangles_without_XZ: 0.05555555555555555
- rate_bad_on_class1: 0.05
- rate_bad_on_class0: 0.05

## Rates by (class, has_XZ_dir)
- {'class': 0, 'has_XZ_dir': False, 'triangles': 24, 'bad_rate_over_all_edges': 0.0, 'bad_rate_on_XZ_edges': 0.0, 'avg_bad_overlap_total': 0.0, 'avg_bad_overlap_XZ': 0.0}
- {'class': 0, 'has_XZ_dir': True, 'triangles': 36, 'bad_rate_over_all_edges': 0.08333333333333333, 'bad_rate_on_XZ_edges': 0.0, 'avg_bad_overlap_total': 1.0, 'avg_bad_overlap_XZ': 0.0}
- {'class': 1, 'has_XZ_dir': False, 'triangles': 30, 'bad_rate_over_all_edges': 0.1, 'bad_rate_on_XZ_edges': 0.0, 'avg_bad_overlap_total': 1.2, 'avg_bad_overlap_XZ': 0.0}
- {'class': 1, 'has_XZ_dir': True, 'triangles': 30, 'bad_rate_over_all_edges': 0.0, 'bad_rate_on_XZ_edges': 0.0, 'avg_bad_overlap_total': 0.0, 'avg_bad_overlap_XZ': 0.0}

## Interpretation
- We lifted the state-level firewall (bad edges) to block-triple motifs by collecting all N180 state edges used by those block edges (both directions, all 4 fiber keys).
- If the firewall is enforcing a 'no XZ/Y/fermion translation' syndrome, bad overlap should concentrate on triangles that include XZ-directed edges and/or class1 syndrome triangles.
- The reported rates quantify that enrichment (or lack thereof) without requiring additional mapping assumptions.
