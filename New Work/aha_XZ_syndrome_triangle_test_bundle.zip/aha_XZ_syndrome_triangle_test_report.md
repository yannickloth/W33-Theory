# Test: is triangle syndrome linked to XZ-channel usage?

Triangle class counts: {0: 60, 1: 60}

## Ordered triangle distributions
- n_XZ by class: {'0': {0: 144, 1: 216}, '1': {0: 180, 1: 162, 3: 18}}
- n_H (swap-matrix edges) by class: {'0': {2: 228, 0: 132}, '1': {1: 312, 3: 48}}
## Unordered triple: does any orientation use XZ?
- force_XZ: {0: 36, 1: 30}
- min_XZ distribution class0: {0: 24, 1: 36}
- min_XZ distribution class1: {0: 30, 1: 27, 3: 3}
