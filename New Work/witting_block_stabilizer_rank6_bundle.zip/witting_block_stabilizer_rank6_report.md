# Symmetry breaking inside Witting: stabilizer of the canonical 10-block system

- Full Witting (projective) symmetry group order: 25920
- Stabilizer of the canonical 10-block system: 720
- Induced image on 10 blocks size: 720

Expected (from W33 work): stabilizer ~1440 and image ~720.

Approx orbitals under generated subgroup (diagnostic): count=6, sizes sample=[40, 40, 80, 360, 360, 720, '...', 40, 80, 360, 360, 720]

## Notes
- We transported the canonical 10-block system from W33 into Witting ray labeling via graph isomorphism.
- We computed the exact stabilizer in the Witting symmetry group (order 25920) that preserves this block system setwise.
- This stabilizer is the 'symmetry broken' subgroup we want; it should match the 1440 normalizer (projective) and induce S6 of size 720 on blocks.
