#!/usr/bin/env python3
"""
Enumerate double-sixes in the Schläfli graph (27 lines on a smooth cubic surface),
constructed from a 27-orbit of W(E6) acting on E8 roots.

This script fixes the key bug found in some earlier implementations:
- In the Schläfli graph, edges represent *skew* lines.
- A 'six' is a set of six pairwise skew lines => a K6 clique (NOT an independent set).
- A double-six (A,B) consists of two such sixes with a perfect matching of non-edges between them:
    each a in A is non-adjacent to exactly one b in B, and vice versa.

Outputs:
- double_six_example.json (one example double-six with explicit matching)
"""
from __future__ import annotations
import itertools, json
import numpy as np
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent

E8_SIMPLE_ROOTS = np.array(
    [
        [1, -1, 0, 0, 0, 0, 0, 0],  # a1
        [0, 1, -1, 0, 0, 0, 0, 0],  # a2
        [0, 0, 1, -1, 0, 0, 0, 0],  # a3
        [0, 0, 0, 1, -1, 0, 0, 0],  # a4
        [0, 0, 0, 0, 1, -1, 0, 0],  # a5
        [0, 0, 0, 0, 0, 1, -1, 0],  # a6
        [0, 0, 0, 0, 0, 1, 1, 0],  # a7
        [-0.5, -0.5, -0.5, -0.5, -0.5, -0.5, -0.5, -0.5],  # a8
    ],
    dtype=np.float64,
)
E6_SIMPLE_ROOTS = E8_SIMPLE_ROOTS[2:8]

def construct_e8_roots():
    roots = []
    for i in range(8):
        for j in range(i+1,8):
            for si in [1.0,-1.0]:
                for sj in [1.0,-1.0]:
                    r = np.zeros(8)
                    r[i], r[j] = si, sj
                    roots.append(r)
    for bits in range(256):
        signs = np.array([1.0 if (bits>>k)&1 else -1.0 for k in range(8)])
        if int(np.sum(signs<0))%2==0:
            roots.append(signs*0.5)
    return np.array(roots)

def snap(v,tol=1e-6):
    s = np.round(v*2)/2
    if np.max(np.abs(v-s))<tol:
        return tuple(float(x) for x in s)
    return tuple(float(round(x,8)) for x in v)

def weyl_reflect(v,alpha):
    return v - 2*np.dot(v,alpha)/np.dot(alpha,alpha)*alpha

def compute_we6_orbits(roots):
    keys=[snap(r) for r in roots]
    key_to_idx={k:i for i,k in enumerate(keys)}
    used=np.zeros(len(roots),dtype=bool)
    orbits=[]
    for start in range(len(roots)):
        if used[start]: 
            continue
        orbit=[start]
        used[start]=True
        frontier=[start]
        while frontier:
            cur=frontier.pop()
            v=roots[cur]
            for alpha in E6_SIMPLE_ROOTS:
                w=weyl_reflect(v,alpha)
                k=snap(w)
                j=key_to_idx.get(k)
                if j is not None and not used[j]:
                    used[j]=True
                    orbit.append(j)
                    frontier.append(j)
        orbits.append(orbit)
    return orbits

def build_schlafli_adj(roots, orbit_idx):
    n=len(orbit_idx)
    R=roots[orbit_idx]
    gram=R@R.T
    ip_counts=Counter()
    for i in range(n):
        for j in range(i+1,n):
            ip_counts[round(float(gram[i,j]),6)] += 1
    # adjacency is ip==1 for these 27-orbits
    adj=np.zeros((n,n),dtype=np.uint8)
    for i in range(n):
        for j in range(i+1,n):
            if abs(gram[i,j]-1.0)<1e-6:
                adj[i,j]=adj[j,i]=1
    # check valency 16
    deg=adj.sum(axis=1)
    if not np.all(deg==16):
        raise RuntimeError(f"Unexpected degrees: {Counter(deg.tolist())}")
    return adj, ip_counts

def find_k6_cliques(adj):
    n=adj.shape[0]
    # brute: choose 6 out of 27 => 296,010; feasible
    cliques=[]
    vertices=range(n)
    for comb in itertools.combinations(vertices,6):
        ok=True
        for i in range(6):
            a=comb[i]
            row=adj[a]
            for j in range(i+1,6):
                b=comb[j]
                if row[b]==0:
                    ok=False; break
            if not ok: break
        if ok:
            cliques.append(comb)
    return cliques

def is_double_six(adj, A, B):
    # In the Schläfli graph edges represent SKEWNESS.
    # In a double‑six, each a_i intersects all but one b_j,
    # hence each a_i is skew (adjacent) to exactly ONE b_j, and vice versa.
    if set(A) & set(B):
        return None
    pairing = {}
    used_b = set()
    # Each a has exactly one neighbor in B
    for a in A:
        nbrs = [b for b in B if adj[a,b]==1]
        if len(nbrs)!=1:
            return None
        b = nbrs[0]
        if b in used_b:
            return None
        pairing[int(a)] = int(b)
        used_b.add(b)
    # Each b has exactly one neighbor in A
    for b in B:
        nbrs = [a for a in A if adj[a,b]==1]
        if len(nbrs)!=1:
            return None
    return pairing
def main():
    roots=construct_e8_roots()
    orbits=compute_we6_orbits(roots)
    # pick a 27-orbit
    orbits27=[o for o in orbits if len(o)==27]
    if not orbits27:
        raise RuntimeError("No 27-orbits found")
    orbit=orbits27[0]
    adj, ip_counts = build_schlafli_adj(roots, orbit)
    cliques = find_k6_cliques(adj)
    # Deduplicate by set
    cliques_unique = []
    seen=set()
    for c in cliques:
        key=tuple(sorted(c))
        if key not in seen:
            seen.add(key)
            cliques_unique.append(key)
    # find double-sixes
    ds=[]
    for i in range(len(cliques_unique)):
        for j in range(i+1,len(cliques_unique)):
            A=cliques_unique[i]
            B=cliques_unique[j]
            pairing=is_double_six(adj,A,B)
            if pairing is not None:
                ds.append((A,B,pairing))
    out={
        "orbit_size": 27,
        "ip_counts": {str(k): int(v) for k,v in sorted(ip_counts.items())},
        "n_k6_cliques": len(cliques_unique),
        "n_double_sixes": len(ds),
    }
    # store example
    if not ds:
        raise RuntimeError("No double-sixes found")
    exA, exB, pairing = ds[0]
    example={
        "A": list(map(int, exA)),
        "B": list(map(int, exB)),
        "pairing_A_to_B_nonadjacent": pairing,
    }
    (ROOT/"double_six_example.json").write_text(json.dumps(example, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))
    print("Wrote double_six_example.json")

if __name__=="__main__":
    main()