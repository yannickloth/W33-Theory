#!/usr/bin/env python3
"""
Construct the full automorphism group of the symplectic generalized quadrangle W(3,3)
(point graph SRG(40,12,2,4)) as a permutation group on the 40 projective points.

Key idea:
- Work in V = F_3^4 with the standard symplectic form:
    <x,y> = x0*y2 - x2*y0 + x1*y3 - x3*y1  (mod 3)
- The point set is projective points of PG(3,3): 1D subspaces of V (40 points).
- An automorphism of W(3,3) is induced by a (projective) symplectic similitude:
    M^T J M = μ J (mod 3), with μ in F_3^* = {1,2}.
  Two matrices differing by a scalar act identically on projective points.

This script:
1) Builds the 40 projective points and W33 adjacency.
2) Finds a small generating set of symplectic/similitude matrices.
3) Closes the generated permutation group on 40 points (expected order 51840).
4) Computes stabilizer sizes for a point and a line (K4).

Outputs a JSON summary to artifacts/w33_aut_group_summary.json
"""
from __future__ import annotations
import itertools, random, time, json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent
ART = ROOT / "artifacts"
ART.mkdir(parents=True, exist_ok=True)

MOD = 3

def mod_inv(a:int)->int:
    a%=MOD
    if a==1: return 1
    if a==2: return 2
    raise ValueError("no inv for 0")

def mat_det_mod(M:np.ndarray)->int:
    # Gaussian elimination mod 3
    A = M.copy()%MOD
    n = A.shape[0]
    det = 1
    row = 0
    for col in range(n):
        pivot = None
        for r in range(row, n):
            if A[r,col]%MOD!=0:
                pivot = r
                break
        if pivot is None:
            return 0
        if pivot != row:
            A[[row,pivot]] = A[[pivot,row]]
            det = (-det) % MOD
        piv = int(A[row,col]%MOD)
        det = (det*piv) % MOD
        invp = mod_inv(piv)
        A[row,:] = (A[row,:]*invp) % MOD
        for r in range(row+1, n):
            if A[r,col]%MOD!=0:
                factor = int(A[r,col]%MOD)
                A[r,:] = (A[r,:] - factor*A[row,:]) % MOD
        row += 1
    return det%MOD

def mat_inv_mod(M:np.ndarray)->np.ndarray:
    A = M.copy()%MOD
    n = A.shape[0]
    I = np.eye(n, dtype=int)
    aug = np.concatenate([A, I], axis=1) % MOD
    row = 0
    for col in range(n):
        pivot = None
        for r in range(row, n):
            if aug[r,col]%MOD!=0:
                pivot = r; break
        if pivot is None:
            raise ValueError("singular")
        if pivot!=row:
            aug[[row,pivot]] = aug[[pivot,row]]
        piv = int(aug[row,col]%MOD)
        invp = mod_inv(piv)
        aug[row,:] = (aug[row,:]*invp)%MOD
        for r in range(n):
            if r==row: continue
            if aug[r,col]%MOD!=0:
                factor = int(aug[r,col]%MOD)
                aug[r,:] = (aug[r,:] - factor*aug[row,:])%MOD
        row += 1
    return aug[:,n:]%MOD

def canonical_point(v):
    # projective point: scale so first nonzero coordinate is 1
    v = np.array(v, dtype=int) % MOD
    if not np.any(v): raise ValueError("zero")
    for i in range(4):
        if v[i]%MOD!=0:
            inv = mod_inv(int(v[i]))
            return tuple(int((inv*x)%MOD) for x in v)
    raise RuntimeError("unreachable")

def symp_form(x,y)->int:
    return (x[0]*y[2] - x[2]*y[0] + x[1]*y[3] - x[3]*y[1]) % MOD

def build_points():
    pts=[]
    seen=set()
    for v in itertools.product([0,1,2], repeat=4):
        if v==(0,0,0,0): continue
        rep = canonical_point(v)
        if rep not in seen:
            seen.add(rep)
            pts.append(rep)
    pts.sort()
    idx = {p:i for i,p in enumerate(pts)}
    return pts, idx

def build_w33_adj(pts):
    n=len(pts)
    adj = np.zeros((n,n), dtype=np.uint8)
    for i in range(n):
        for j in range(i+1,n):
            if symp_form(pts[i], pts[j])==0:
                adj[i,j]=adj[j,i]=1
    return adj

def k4_lines_from_adj(adj):
    # In W(3,3), maximal cliques are K4 and there are 40 of them.
    n = adj.shape[0]
    lines=set()
    # speed trick: each line is the common neighborhood of an edge?
    # brute: find all K4
    for a in range(n):
        na = np.where(adj[a]==1)[0]
        for b_i in range(len(na)):
            b = int(na[b_i])
            if b<=a: continue
            common = [int(x) for x in na if adj[b,x]]
            # choose two from common
            for c_i in range(len(common)):
                c=common[c_i]
                if c<=b: continue
                # candidates for d in common ∩ N(c)
                for d in common[c_i+1:]:
                    if d<=c: continue
                    if adj[c,d]:
                        lines.add(tuple(sorted((a,b,c,int(d)))))
    return sorted(lines)

# Symplectic matrix J representing the bilinear alternating form.
J = np.array([
    [0,0,1,0],
    [0,0,0,1],
    [2,0,0,0],
    [0,2,0,0],
], dtype=int) % MOD

def is_similitude(M):
    M = M % MOD
    if mat_det_mod(M)==0: return None
    MTJM = (M.T @ J @ M) % MOD
    # Try mu=1 or 2
    for mu in (1,2):
        if np.array_equal(MTJM, (mu*J)%MOD):
            return mu
    return None

def random_invertible_matrix():
    while True:
        M = np.random.randint(0,3,(4,4),dtype=int)
        if mat_det_mod(M)!=0:
            return M

def find_generators(max_tries=20000, want=4):
    gens=[]
    mus=[]
    tries=0
    while len(gens)<want and tries<max_tries:
        tries += 1
        M = random_invertible_matrix()
        mu = is_similitude(M)
        if mu is None: 
            continue
        # reject duplicates by hash
        key = tuple(M.flatten().tolist())
        if key in {tuple(g.flatten().tolist()) for g in gens}:
            continue
        gens.append(M%MOD)
        mus.append(mu)
    return gens, mus

def perm_from_matrix(M, pts, idx):
    # act on projective points
    perm=[None]*len(pts)
    for i,p in enumerate(pts):
        v = np.array(p, dtype=int)
        w = (M @ v) % MOD
        rep = canonical_point(w)
        perm[i] = idx[rep]
    return tuple(perm)

def perm_compose(p,q):
    # p∘q : apply q then p
    return tuple(p[i] for i in q)

def perm_inverse(p):
    inv=[0]*len(p)
    for i,j in enumerate(p):
        inv[j]=i
    return tuple(inv)

def close_group(generators):
    # BFS closure of permutations
    gens = list(generators)
    gens_inv = [perm_inverse(g) for g in gens]
    all_gens = gens + gens_inv
    idp = tuple(range(len(gens[0])))
    seen={idp}
    q=[idp]
    while q:
        cur=q.pop()
        for g in all_gens:
            nxt = perm_compose(g, cur)
            if nxt not in seen:
                seen.add(nxt)
                q.append(nxt)
    return list(seen)

def main():
    pts, idx = build_points()
    adj = build_w33_adj(pts)
    lines = k4_lines_from_adj(adj)
    if len(lines)!=40:
        raise RuntimeError(f"Expected 40 K4 lines, got {len(lines)}")

    # Find generator matrices and close group, iteratively if needed.
    np.random.seed(0)
    gens_mat, mus = find_generators(want=6)
    perms = [perm_from_matrix(M, pts, idx) for M in gens_mat]

    # Iteratively add generators until group size reaches 51840 or stops growing.
    target = 51840
    best=[]
    used=[]
    for p in perms:
        used.append(p)
        G = close_group(used)
        if len(G)>len(best):
            best=G
        if len(G)==target:
            break

    G = best
    # Stabilizers
    # point stabilizer at point 0
    stab_point0 = sum(1 for g in G if g[0]==0)
    # line stabilizer for first line
    L0 = set(lines[0])
    stab_line0 = 0
    for g in G:
        image = {g[i] for i in L0}
        if image==L0:
            stab_line0 += 1

    # orbit size of a line under group (should be 40)
    orbit_lines = set()
    for g in G[:5000] if len(G)>5000 else G:
        orbit_lines.add(tuple(sorted(g[i] for i in L0)))
    # compute full orbit exactly
    orbit_lines = set(tuple(sorted(g[i] for i in L0)) for g in G)
    orbit_line_size = len(orbit_lines)

    out = {
        "n_points": 40,
        "n_lines": 40,
        "group_order": len(G),
        "target_order": target,
        "point_stabilizer_size": stab_point0,
        "line_stabilizer_size": stab_line0,
        "line_orbit_size": orbit_line_size,
        "generators_found": len(used),
        "generator_multipliers": mus[:len(used)],
        "note": "Permutation group generated from projective symplectic similitudes.",
    }
    (ART / "w33_aut_group_summary.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))

if __name__ == "__main__":
    main()
