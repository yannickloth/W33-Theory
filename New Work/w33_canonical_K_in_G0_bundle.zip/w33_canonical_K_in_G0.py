#!/usr/bin/env python3
# Canonical K in G0 computed in notebook; see summary/report.
