# Canonical K (order 720) inside G0

- time: 10.305s
- |G|=51840, |G0|=25920
- Found some K in 1417 trials; enumerated 36 coset reps (expect 36)
- Canonical K chosen by lex-min signature of subgroup element ordering.
- DS orbit partition under canonical K: [60, 120, 180, 360]
- Normalizer size in full G (exact, via 3 true generators): 1440