#!/usr/bin/env python3
import json, itertools, zipfile
from pathlib import Path

OUT=Path("/mnt/data")

# load local 1-form clock
local=json.loads((OUT/'toe_local_1form_clock.json').read_text())

def parse_xy(s): return (int(s[0]),int(s[1]))
I=((1,0),(0,1)); S=((0,1),(1,0))
def mclass(M):
    if M==I: return 0
    if M==S: return 1
    return 2

aff={}
def mat_mul(M,x): return ((M[0][0]&x[0])^(M[0][1]&x[1]), (M[1][0]&x[0])^(M[1][1]&x[1]))
def add(u,v): return (u[0]^v[0], u[1]^v[1])
def mm(MA,MB):
    a,b=MA[0]; c,d=MA[1]
    e,f=MB[0]; g,h=MB[1]
    return (((a&e)^(b&g), (a&f)^(b&h)),
            ((c&e)^(d&g), (c&f)^(d&h)))
def compose_aff(f,g):
    (M1,t1)=f; (M2,t2)=g
    M=mm(M1,M2)
    t=add(mat_mul(M1,t2), t1)
    return (M,t)

GL2=[((1,0),(0,1)), ((0,1),(1,0)), ((1,1),(0,1)), ((1,0),(1,1)), ((0,1),(1,1)), ((1,1),(1,0))]
def inv_aff(affine):
    M,t=affine
    for Minv in GL2:
        if mm(Minv,M)==I:
            return (Minv, mat_mul(Minv,t))
    raise RuntimeError

for key,val in local['local_table'].items():
    A,B=key.split('->'); A=int(A); B=int(B)
    M=(tuple(val['M'][0]), tuple(val['M'][1]))
    t=tuple(val['t'])
    aff[(A,B)]=(M,t)

def get_aff(u,v):
    if (u,v) in aff:
        return aff[(u,v)]
    return inv_aff(aff[(v,u)])

def hol_triangle(a,b,c):
    return compose_aff(get_aff(c,a), compose_aff(get_aff(b,c), get_aff(a,b)))

parity={}
for comb in itertools.combinations(range(10),3):
    a,b,c=comb
    M,_=hol_triangle(a,b,c)
    parity[comb]=mclass(M)

counts={0:0,1:0,2:0}
for v in parity.values():
    counts[v]+=1

class1=[tri for tri,val in parity.items() if val==1]
pair_counts={}
for a,b,c in class1:
    for u,v in [(a,b),(a,c),(b,c)]:
        if u>v: u,v=v,u
        pair_counts[(u,v)] = pair_counts.get((u,v),0)+1

print("triangle class counts:", counts)
print("lambda set:", sorted(set(pair_counts.values())))
