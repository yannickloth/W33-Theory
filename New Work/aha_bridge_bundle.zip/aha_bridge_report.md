# Aha bridge: keys, symplectic constraints, and holonomy

This bundle is meant to create a *non-aimless* mapping: we isolate one structural theorem per domain and show the exact hook points in our W33/Witting architecture.

## 1) The key-matching rule is a symplectic commutation constraint
In stabilizer code theory, the commutativity condition is the **symplectic inner product constraint**:
- For H=[H_X|H_Z], require $H_X H_Z^T + H_Z H_X^T = 0 \pmod 2$.
This is the canonical form of **"two things can interact iff they are not symplectically perpendicular"**.

## 2) Our transport keyspace is AGL(2,2) ≅ S4
Our fiber is Z2×Z2 (4 keys) and our transport maps are affine; the natural group is AGL(2,2), isomorphic to S4.

## 3) Our Z2 curvature is a parity-check design
- Unordered triples split into: class0=60, class1=60, class2=0.
- Pair-counts over class1 triples give λ set = [4] (should be {4}).
Interpretation: the triangle holonomy class acts like a **MAC parity bit** on triples; the 2-(10,3,4) design is the parity-check structure.

## 4) The E6 hinge is the loop-space dimension
K10 cycle rank E−V+1 = 36. This equals the classical double-six count, suggesting E6 is the loop-phase-space kernel after constraint reduction.

## Next tests (not aimless)
1) Construct an explicit stabilizer-check matrix for the 10-block network whose SIP constraint reproduces N180 authentication.
2) Treat triangle parity as a syndrome bit and measure how the E6 firewall corresponds to syndrome selection.
3) Lift the parity design into a full syndrome decoding story on the 36-loop basis.
