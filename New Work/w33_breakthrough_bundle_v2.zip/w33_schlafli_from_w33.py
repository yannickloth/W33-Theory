#!/usr/bin/env python3
"""Build a Schläfli SRG(27,16,10,8) directly *inside* W33.

Key construction (purely from W33 adjacency):

Fix a base point v0.
Let H27(v0) be the 27 non-neighbors of v0 in W33.
For u,v in H27(v0), define:
  c_full(u,v) = number of common neighbors of u and v in the full W33
  c_h12(u,v)  = number of common neighbors of u and v inside H12(v0)

Empirical fact (and provable from the Heisenberg local model):
  c_full(u,v) in {2,4}
  c_h12(u,v)  in {1,4}
Moreover, the pairs with c_h12=4 form 9 disjoint 3-cycles (the 9 Heisenberg fibers).

Define the derived graph S(v0) on the 27 vertices H27(v0) by
  u~v  iff  c_full(u,v)=4  AND  c_h12(u,v) != 4.

Then S(v0) is strongly regular SRG(27,16,10,8), i.e. the Schläfli graph.

This script:
- Constructs W33 from F3^4 symplectic form.
- Builds S(v0) for v0=0.
- Verifies SRG parameters.
- Enumerates K6 cliques ("sixes") and double-sixes.

Outputs:
- artifacts/w33_schlafli_from_w33_summary.json
"""

from __future__ import annotations

import itertools
import json
from collections import Counter
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
ART = ROOT / "artifacts"
ART.mkdir(parents=True, exist_ok=True)

MOD = 3


def canonical(v):
    v = list(v)
    for i in range(4):
        if v[i] != 0:
            inv = 1 if v[i] == 1 else 2
            return tuple((inv * x) % MOD for x in v)
    raise ValueError("zero")


def omega(x, y):
    return (x[0] * y[2] - x[2] * y[0] + x[1] * y[3] - x[3] * y[1]) % MOD


def build_w33():
    pts = []
    seen = set()
    for v in itertools.product([0, 1, 2], repeat=4):
        if v == (0, 0, 0, 0):
            continue
        rep = canonical(v)
        if rep not in seen:
            seen.add(rep)
            pts.append(rep)
    pts.sort()
    n = len(pts)
    adj = np.zeros((n, n), dtype=np.uint8)
    for i in range(n):
        for j in range(i + 1, n):
            if omega(pts[i], pts[j]) == 0:
                adj[i, j] = adj[j, i] = 1
    return pts, adj


def h12_set(adj, v0):
    return {i for i in range(adj.shape[0]) if adj[v0, i] == 1}


def h27_list(adj, v0):
    return [i for i in range(adj.shape[0]) if i != v0 and adj[v0, i] == 0]


def srg_verify(A, n, k, lam, mu):
    deg = A.sum(axis=1)
    if not np.all(deg == k):
        return False, f"degree mismatch {Counter(deg.tolist())}"
    for i in range(n):
        for j in range(i + 1, n):
            common = int(np.sum(A[i] & A[j]))
            if A[i, j]:
                if common != lam:
                    return False, f"lambda fail ({i},{j}) common={common}"
            else:
                if common != mu:
                    return False, f"mu fail ({i},{j}) common={common}"
    return True, "OK"


def find_k6_cliques(A):
    n = A.shape[0]
    nbr = [set(np.where(A[i] == 1)[0]) for i in range(n)]
    out = set()

    def extend(clique, candidates):
        if len(clique) == 6:
            out.add(tuple(sorted(clique)))
            return
        if len(clique) + len(candidates) < 6:
            return
        for v in sorted(list(candidates)):
            new_cand = candidates.intersection(nbr[v])
            candidates.remove(v)
            extend(clique + [v], new_cand)

    extend([], set(range(n)))
    return sorted(out)


def is_double_six(A, S, T):
    # Here A is the Schläfli adjacency where edges represent "skew".
    # A double-six has each s adjacent to exactly one t, and each t adjacent to exactly one s.
    if set(S) & set(T):
        return None
    pairing = {}
    used_t = set()
    for s in S:
        nbrs = [t for t in T if A[s, t] == 1]
        if len(nbrs) != 1:
            return None
        t = nbrs[0]
        if t in used_t:
            return None
        used_t.add(t)
        pairing[int(s)] = int(t)
    for t in T:
        nbrs = [s for s in S if A[s, t] == 1]
        if len(nbrs) != 1:
            return None
    return pairing


def main():
    pts, adj = build_w33()
    n = adj.shape[0]
    v0 = 0
    H12 = h12_set(adj, v0)
    H27 = h27_list(adj, v0)
    if len(H27) != 27:
        raise RuntimeError("expected 27 nonneighbors")
    # build derived Schläfli
    idx = {u: i for i, u in enumerate(H27)}
    S = np.zeros((27, 27), dtype=np.uint8)
    nbr = [set(np.where(adj[i] == 1)[0]) for i in range(n)]
    for i, a in enumerate(H27):
        for b in H27[i + 1 :]:
            cf = len(nbr[a] & nbr[b])
            if cf != 4:
                continue
            ch = len((nbr[a] & nbr[b]) & H12)
            if ch == 4:
                continue
            ia, ib = idx[a], idx[b]
            S[ia, ib] = S[ib, ia] = 1

    ok, msg = srg_verify(S, 27, 16, 10, 8)
    if not ok:
        raise RuntimeError(f"Schläfli verification failed: {msg}")

    k6 = find_k6_cliques(S)
    # enumerate double-sixes
    ds = []
    for i in range(len(k6)):
        for j in range(i + 1, len(k6)):
            pairing = is_double_six(S, k6[i], k6[j])
            if pairing is not None:
                ds.append((k6[i], k6[j], pairing))

    summary = {
        "base_point": v0,
        "h27_vertices": H27,
        "schlafli_srg": [27, 16, 10, 8],
        "n_k6_sixes": len(k6),
        "n_double_sixes": len(ds),
        "example_double_six": {
            "S": list(map(int, ds[0][0])) if ds else None,
            "T": list(map(int, ds[0][1])) if ds else None,
            "pairing_S_to_T": ds[0][2] if ds else None,
        },
    }
    out_path = ART / "w33_schlafli_from_w33_summary.json"
    out_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
