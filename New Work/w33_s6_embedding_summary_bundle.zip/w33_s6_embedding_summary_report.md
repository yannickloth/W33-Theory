# W33 ↔ S6 embedding summary

Group sizes: {'G': 51840, 'G0': 25920, 'Kcanon': 720, 'N_normalizer': 1440, 'image_on_blocks': 720}

## Key map
- Normalizer N of canonical K has order 1440 and maps onto S6 on the 10 blocks with kernel 2.

## Stabilizer checks (S6)
- |Stab(letter)| = 120
- |Stab(duad)| = 48
- |Stab(3+3 partition)| = 72

## Next steps
- We have an explicit isomorphism between the induced action of N on the 10 W33 blocks and the natural S6 action on 3+3 partitions of 6 letters.
- This pins down a canonical S6 labelling inside W33, enabling direct subgroup chains S6->S5->S4->... to be lifted to actual W33 automorphisms (up to the Z2 kernel).
- Next: compute how the rank-6 relation set (E20,E40,E180,N180,N360) transforms under the S6 letter action, and identify which relations correspond to duads/synthemes/pentads in the outer automorphism picture.
