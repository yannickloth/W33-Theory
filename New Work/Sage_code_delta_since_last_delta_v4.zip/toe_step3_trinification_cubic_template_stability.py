# Stability test for trinification cubic template solve; see JSON.
