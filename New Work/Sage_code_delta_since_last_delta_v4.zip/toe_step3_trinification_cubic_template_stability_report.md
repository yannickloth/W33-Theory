# Trinification cubic template stability test

## Baseline v2 solve
- min_eigenvalue: 1.528e-15
- residual_energy_sampled: 3.379e-30

## Stability across random generator samples
- min_eigenvalue stats: {'mean': 1.5276786069377878e-15, 'std': 0.0, 'min': 1.5276786069377878e-15, 'max': 1.5276786069377878e-15}
- residual energy stats: {'mean': 3.378916769634268e-30, 'std': 0.0, 'min': 3.378916769634268e-30, 'max': 3.378916769634268e-30}

## Interpretation
- If min_eigenvalue and residual energy stay ~0 across random generator samples, the structured cubic is genuinely invariant for the extracted subalgebra (major breakthrough).
- If some samples spike, it indicates the extracted generator set still contains non-stabilizer directions; we should intersect stabilizers by excluding offending generators.
- The alpha vector should be stable up to scale/sign; large variation indicates ansatz family still too flexible or coordinate labeling imperfect.

## Next
- Compute per-generator residuals for the best alpha and identify specific offending generators to prune.
- Re-run subalgebra extraction with a hard constraint that preserves this cubic (projected invariance).
- Promote the resulting cubic to a full Sym^3 tensor in this coordinate basis and test invariance energy globally.
