# Projection-fixed trinification solve; see JSON/MD for outputs.
