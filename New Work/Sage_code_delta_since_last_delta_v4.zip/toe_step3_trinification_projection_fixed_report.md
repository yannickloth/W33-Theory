# Trinification cubic solve with projection fixed (expanded monomial universe)

- initial support size: 84
- expanded U size: 2929 (iters=2)
- min eigenvalue: 1.66974e-13
- residual_energy_fullU: 1.67599e-28
- alpha: [2.670802183115653e-17, -3.6464547484047077e-16, 1.0120310860474789e-15, 4.852546580269734e-16, 0.0, 1.238590617563174e-17, -0.7071067811865472, -6.903380736254227e-17, 0.707106781186547]

- This is the corrected invariance solve: derivatives are evaluated in an expanded monomial universe U that includes one-step images under the generators.
- If residual_energy_fullU is still ~0, we have a genuine structured cubic invariant (major breakthrough).
- If residual is nonzero, we now have an honest objective; next step is to enlarge U further (more closure rounds) or expand template family.
