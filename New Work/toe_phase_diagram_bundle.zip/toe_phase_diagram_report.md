# Phase diagram for the 3-field effective theory

## Notable lambda values
- lambda_max_E6_alignment: 0.0
- lambda_max_gap: 5.0
- lambda_min_energy: 5.0
- lambda_best_phase_score: 0.0

## Phase transitions (dominant sector changes)
- none in scanned range

## Phase segments
- {'lambda_from': 0.0, 'lambda_to': 5.0, 'dominant_sector': 2, 'max_E6_align_in_segment': 0.8664934280206622, 'min_energy_in_segment': -3.089277435620857e-30, 'max_gap_in_segment': 2.910757295463482e-30}

## Notes
- Dominant sector is argmax of |ground eigenvector component|; mix entropy computed from squared amplitudes.
- E6 alignment metric uses cosine similarity with (Schläfli - bad) vector from the earlier mapping.
- Use transitions + segment summaries as the phase diagram skeleton; plots provide visual confirmation.
