# Dynkin lock attempt v2

- tol=1e-08, stabilizer_count=82
- cartan_rank=6, root_clusters=19, eps_root=0.0002
- best_score=9

## Best rounded Cartan matrix
- [2, 0, -1, -1, 0, 0]
- [0, 2, 0, 0, 0, 0]
- [0, 0, 2, 0, 0, 0]
- [-1, 0, -1, 2, -1, 0]
- [0, 0, -1, -1, 2, 0]
- [0, 0, 0, 0, 0, 2]

- simple_root_indices: [18, 8, 3, 7, 17, 12]

## Next
- If score==0, output Dynkin graph edges and verify 72 roots total.
- If score>0, compute an empirical bilinear form B(x,y)=Tr(ad_x ad_y) on Cartan space to replace Euclidean dot product.
- Then redo Cartan matrix computation with that metric.
