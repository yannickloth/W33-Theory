# Q8-lifted inverse solve (set-size constraint)

- best_cost: 55 / 120 triples
- perfect: False
- odd_ok: 41/60, even_ok: 24/60
- p-set-size distribution: {1: 43, 2: 77}
- p=2 edges (total/free): 0/0

- This uses the empirically correct spin constraint: even triples have orientation-invariant p; odd triples have two-valued p across orientations.
- If perfect is achieved, the Q8 sign lift is determined (up to gauge) by the S6-native syndrome design plus the observed (h,t) transport.
- If not, remaining mismatch indicates we must allow p∈Z4 fully (0,1,2,3) or include k6/Z6 phase constraints.
