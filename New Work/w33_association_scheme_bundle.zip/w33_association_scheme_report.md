# W33 association-scheme algebra from canonical edge partition

Relations: ['I', 'E20', 'E40', 'E180', 'N']

Valencies (row sums):
- I: 1
- E20: 1
- E40: 2
- E180: 9
- N: 27

Commutative adjacency algebra: True

## Key products
- E20*E20 = {'I': 1, 'E20': 0, 'E40': 0, 'E180': 0, 'N': 0}
- E20*E40 = {'I': 0, 'E20': 0, 'E40': 1, 'E180': 0, 'N': 0}
- E20*E180 = {'I': 0, 'E20': 0, 'E40': 0, 'E180': 0, 'N': 0}
- E40*E40 = {'I': 2, 'E20': 2, 'E40': 0, 'E180': 0, 'N': 0}
- E40*E180 = {'I': 0, 'E20': 0, 'E40': 0, 'E180': 0, 'N': 1}
- E180*E180 = {'I': 9, 'E20': 0, 'E40': 0, 'E180': 2, 'N': 2}
- N*N = {'I': 27, 'E20': 18, 'E40': 18, 'E180': 18, 'N': 18}

## Spectra
- spectrum(E20) = {'-1.0': 20, '1.0': 20}
- spectrum(E40) = {'-2.0': 10, '-0.0': 20, '2.0': 10}
- spectrum(E180) = {'-3.0': 15, '-1.0': 9, '3.0': 15, '9.0': 1}
- spectrum(N) = {'-3.0': 24, '3.0': 15, '27.0': 1}
