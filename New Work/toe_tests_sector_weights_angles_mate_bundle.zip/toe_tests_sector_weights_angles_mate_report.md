# TOE tests: sector weights on tetrads, projector overlap angles, mate involution

## Projector sanity
- E0: ||E^2-E||=1.418e-15, ||E-E^T||=0.000e+00
- E1: ||E^2-E||=3.829e-15, ||E-E^T||=0.000e+00
- E2: ||E^2-E||=3.641e-15, ||E-E^T||=0.000e+00
- E3: ||E^2-E||=3.219e-15, ||E-E^T||=0.000e+00
- E4: ||E^2-E||=3.091e-15, ||E-E^T||=0.000e+00
- E5: ||E^2-E||=3.629e-15, ||E-E^T||=0.000e+00

## Sector weights on tetrads
- Distinct weight signatures across 40 tetrads: 1
Top signatures (w0..w5):
- count 40: [0.1, 0.5, 0.9, 1.0, 1.0, 0.5]

## Projector overlap angles (radians)
[[5.37e-08, 1.5707963268, 1.5707963268, 1.5707963268, 1.5707963268, 1.5707963268], [1.5707963268, 4.94e-08, 1.5707963268, 1.5707963268, 1.5707963268, 1.5707963268], [1.5707963268, 1.5707963268, 3.33e-08, 1.5707963268, 1.5707963268, 1.5707963268], [1.5707963268, 1.5707963268, 1.5707963268, 2.11e-08, 1.5707963268, 1.5707963268], [1.5707963268, 1.5707963268, 1.5707963268, 1.5707963268, 2.58e-08, 1.5707963268], [1.5707963268, 1.5707963268, 1.5707963268, 1.5707963268, 1.5707963268, 5.37e-08]]

## Mate involution
Commutator norms ||[P_mate,Ei]||_F:
- E0: 4.010e-16
- E1: 2.645e-14
- E2: 1.960e-14
- E3: 3.197e-14
- E4: 1.616e-14
- E5: 1.450e-14

Mate preserves tetrad signatures for 40/40 tetrads (by pairing B->mate(B)).

## Notes
- Weights w_i(B) computed as sum of diagonal projector weights over the four ray-labels in tetrad B.
- Angles computed from Frobenius inner products Tr(EiEj).
- Mate involution is the E20 matching transported into Witting labeling; commutators show which idempotent sectors are mate-invariant.
