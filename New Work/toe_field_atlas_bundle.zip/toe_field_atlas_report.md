# Field atlas (transport/phase/constraint) with soft sector couplings

## Edge set sizes
{'attempted_nonorth': 540, 'authenticated_N180': 180, 'blocked_bad': 27}

## Field layers
- **transport**: AGL(2,2) connection on Z2^2 fiber; per ordered block edge has affine (M,t)
- **phase**: edge tick k6 in Z6 on directed fiber edges; loop phases are Bargmann invariants
- **constraint**: E6 bad predicate blocks a subset of nonorth pairs (firewall)

## Notes
- Soft sector membership from idempotent diagonals; couplings computed as expected outer products summed over edges.
- Delta matrices indicate which sector-pairs are selectively strengthened by authenticated channels (N180) vs raw contact, and which are selectively suppressed by the E6 firewall.
