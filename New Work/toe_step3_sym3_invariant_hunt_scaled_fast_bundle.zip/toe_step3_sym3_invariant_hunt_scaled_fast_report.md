# Sym^3(27) cubic invariant hunt (scaled fast)

- generators: 38 (edges 30 + cartan 8)
- steps=30, batch=6, eta0=0.02, decay=0.97
- init: warm start from small run
- final energy: 6.813716396689415
- tensor saved: toe_candidate_cubic_tensor_sym3_scaled_fast.npy

## History (every 5 steps)
- step 0: eta=0.02 eval_energy=7.55113
- step 5: eta=0.0171747 eval_energy=7.35048
- step 10: eta=0.0147485 eval_energy=7.18124
- step 15: eta=0.012665 eval_energy=7.04822
- step 20: eta=0.0108759 eval_energy=6.95164
- step 25: eta=0.00933949 eval_energy=6.87387
- step 29: eta=0.00826819 eval_energy=6.81372
