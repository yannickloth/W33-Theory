# Fast scaled Sym^3 invariant hunt using matmul-based derivation. See JSON/MD.
