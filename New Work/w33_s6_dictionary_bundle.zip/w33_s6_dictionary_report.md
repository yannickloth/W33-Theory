# Dictionary: W33 blocks ↔ S6 outer geometry

We embed the canonical S6 identification back into W33 via the 10 K4 blocks (the 10 disjoint 4-cycles + diagonals).

## Key identification
- The 6-letter set comes from the duad-graph construction inside Aut(2-(10,3,4)).
- Each of the 10 design points corresponds to a partition of the 6 letters into two 3-sets (3+3), i.e. two disjoint triangles in K6.
- In W33, the 10 parabolic blocks (K4 cells) are exactly these 10 design points.

## What this gives
- A canonical map: W33 vertex → block id (0..9)
- A canonical map: block id → partition of 6 letters into two triples
- A canonical map: block id → excluded duads (two triangles) on the 6 letters

See `w33_s6_dictionary.json` for full explicit tables.
