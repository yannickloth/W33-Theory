# Exact match: Witting symmetry-broken orbital algebra = W33 rank‑6 scheme

- Full Witting projective symmetry: 25920
- Block stabilizer (cards/table symmetry breaking): 720
- Orbitals on ordered pairs: 6
- Undirected relation valencies: [1, 1, 2, 9, 9, 18]

## Relation identification
- relation0: I (diagonal)
- relation1: E20 (perfect matching edges inside K4 blocks)
- relation2: E40 (10 disjoint 4-cycles inside K4 blocks)
- relation3: E180 (remaining edges of W33)
- relation4: N180 (nonedge relation defined by mate cross-adjacency)
- relation5: N360 (remaining nonedges)

## Key theorem (empirical, now proved by equality of matrices)
After transporting the canonical W33 relations into the Witting ray labeling, the six undirected orbitals of the 720 stabilizer subgroup match those relations exactly (identity matrix match).

This means: **the rank‑6 Bose–Mesner algebra we computed is precisely the orbital algebra of the symmetry-broken Witting configuration**.
