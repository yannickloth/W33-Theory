# Final theorem-level bridge: E6 firewall = witness-subset syndrome, and it forbids the XZ/Y channel

## Theorem
- Let v0 be the chosen embedding vertex in SRG(40,12,2,4). Let H12 be its neighbor set and H27 its non-neighbor set.
- For any nonorth pair {u,v}⊂H27, let W(u,v)=N(u)∩N(v) be its 4 common neighbors in the orth graph.
- Then the E6 firewall predicate 'bad' is exactly: bad(u,v) ⇔ W(u,v) ⊂ H12.
- Moreover, every bad edge is cross-block and forbids the Pauli translation channel t=(1,1) (XZ/Y/fermion).

## Verified counts
- bad_edges: 27
- pred_bad_edges: 27
- symdiff: 0
- bad_crossblock: 27
- bad_with_XZ: 0
- schlafli_crossblock: 297
- schlafli_with_XZ: 81

## Interpretation
- W(u,v) ⊂ H12 means the entire 'witness' for the interaction lives inside the neighborhood of v0 — a local-only transcript.
- In crypto terms this is precisely a vulnerable handshake (no distributed witness). The firewall deletes it.
- The deleted edges are exactly those that would otherwise avoid using the composite channel XZ; equivalently, the firewall enforces that the fermion/composite translation cannot propagate through locally witnessed interactions.
