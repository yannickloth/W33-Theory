# Normalizer action on the canonical edge partition

- |N| = 1440 (expected 1440)

- Preserve counts: {'all_parts': 1440, 'E20': 1440, 'E40': 1440, 'E180': 1440}

- Distinct part-image patterns: 1; top: [(('E20', 'E40', 'E180'), 1440)]


## Induced action on 10 squares (E40)

- distinct permutations seen: 720

- top: [{'count': 2, 'perm': [7, 3, 4, 1, 6, 8, 9, 5, 0, 2]}, {'count': 2, 'perm': [0, 7, 6, 8, 9, 5, 4, 3, 1, 2]}, {'count': 2, 'perm': [7, 5, 4, 0, 6, 8, 2, 3, 1, 9]}]


## Induced action on 20 matching edges (E20)

- distinct permutations seen: 720

- top: [{'count': 2, 'perm': [4, 17, 18, 0, 16, 15, 11, 12, 13, 10, 6, 9, 8, 7, 19, 14, 3, 1, 2, 5]}, {'count': 2, 'perm': [16, 9, 5, 4, 0, 18, 1, 8, 12, 17, 15, 19, 13, 7, 2, 10, 3, 6, 14, 11]}, {'count': 2, 'perm': [4, 15, 10, 0, 3, 17, 2, 12, 7, 18, 6, 9, 8, 13, 1, 14, 16, 19, 11, 5]}]


## Key findings

- If all N elements preserve (E20,E40,E180) setwise, the partition is invariant under the full normalizer.

- The induced action on the 10 squares and 20 matching edges gives a second-stage quotient that may realize a base-10 structure (10 squares) and a pairing structure (20 edges).
