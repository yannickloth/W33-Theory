# Step 3: cubic invariant hunt on extracted subalgebra

- selected_edge_generators: 74
- cartan_generators: 8
- total_generators: 82
- train_steps: 18
- batch: 12
- eta0: 0.018
- decay: 0.985
- eval_tests: 16
- eval_each: 20
- init_tensor: toe_candidate_cubic_tensor_sym3_multicache_batched_v2.npy

## Aggregate subset-energy stats
- energy_mean: 3.63592
- energy_std: 0.663232
- energy_min: 2.64339
- energy_max: 5.261

- tensor saved: toe_candidate_cubic_tensor_sym3_subalgebra.npy

If the extracted subalgebra is close to e6 and an invariant cubic exists in this basis, these energies should be significantly lower than full-algebra runs and stabilize with training.

## Next
- Hold-out within subalgebra: train on 70% of generators, evaluate on 30% disjoint and compare.
- If energies remain high, the cubic is basis-misaligned; attempt basis change or use Lanczos on operator A for this subalgebra.
- If energies drop strongly, attempt to sparsify tensor toward 45-term form via L1-regularized basis search.
