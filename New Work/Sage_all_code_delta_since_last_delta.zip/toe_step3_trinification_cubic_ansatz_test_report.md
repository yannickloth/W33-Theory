# Trinification cubic ansatz test on 27 vertices

- support monomials: 27 (cycle=9, det-slices=18)
- generators tested (sample): 40 / 82
- nullspace_dim estimate: 9

- If nullspace_dim>0, this structured cubic ansatz aligns with an invariant of the candidate algebra in the trinification coordinate system.
- If nullspace_dim=0, either (i) the algebra is not yet the true stabilizer, or (ii) the invariant cubic is not supported on this simple SU(3)^3-style 27-monomial set and requires richer contractions/basis adjustment.
