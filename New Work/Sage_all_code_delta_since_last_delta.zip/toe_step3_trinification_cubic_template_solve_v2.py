# Trinification template solve v2; see JSON/MD.
