# Step 3: subalgebra pruning round 2

- additional pruned (round2): 3
- total pruned extracted positions: 10
- remaining edge generators: 64
- holdout ratio (hold/train): 1.915

- train_mean: 1.06801
- hold_mean: 2.04552

## Next
- Compare ratio trend round1 vs round2. If moving toward 1, continue small pruning until stability.
- If ratio worsens, switch pruning criterion to marginal holdout effect or commutator-rank contribution.
- Once stable, rerun cubic hunt with Lanczos on the pruned generator set.
