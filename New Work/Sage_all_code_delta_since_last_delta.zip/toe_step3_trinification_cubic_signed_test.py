# Signed trinification cubic test; see JSON/MD for details.
