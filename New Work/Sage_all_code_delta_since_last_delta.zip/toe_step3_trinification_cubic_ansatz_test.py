# Trinification cubic ansatz test; see JSON/MD for results.
