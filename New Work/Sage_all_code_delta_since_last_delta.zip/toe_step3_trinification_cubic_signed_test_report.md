# Trinification cubic signed test (cycle + det-slices)

- support triples: 27
- generators sampled: 60/82
Residual energy stats (||A_X c||^2):
- mean: 1.8
- std: 5.97439
- min: 0
- max: 22

## Interpretation
- This does not require solving for coefficients: it tests the most natural SU(3)^3 cubic (cycle + signed det slices) directly.
- If residuals are near 0 for most generators, we have a strong invariant candidate in this basis.
- If residuals are large, then either the correct cubic needs additional term families, or our coordinate system needs refinement, or the generator set is not yet the true stabilizer.

## Next
- Augment ansatz with additional SU(3)^3 invariants: mixed-slice contraction terms (c fixed but rows/cols shifted).
- Instead of fixed coefficients, solve for best coefficients in this support family (least squares / nullspace) using sampled generators.
- Use residuals to identify which generators violate invariance most and compare to ε-grading.
