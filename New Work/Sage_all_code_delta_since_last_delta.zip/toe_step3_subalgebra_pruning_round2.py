# Subalgebra pruning round 2; see JSON/MD for results.
