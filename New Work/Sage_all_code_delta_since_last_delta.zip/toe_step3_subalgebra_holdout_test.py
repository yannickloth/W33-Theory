# Hold-out within extracted subalgebra test; see JSON.
