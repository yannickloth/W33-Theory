# Trinification cubic template solve v2 (includes trace mixing terms)

- templates K=9, support monomials p=84
- generators sampled: 82/82
- min eigenvalue: 1.52768e-15
- residual_energy_sampled: 3.37892e-30
- alpha: [9.256415581301337e-34, 1.9270091248423876e-17, -4.1343855352806885e-17, 3.33066907387547e-16, 1.5191959027398395e-16, -4.222412495129318e-18, -0.7071067811865475, -7.866981809251698e-18, 0.7071067811865475]

- This directly implements the SU(3)^3 decomposition of the E6 cubic: det(M0)+det(M1)+det(M2) - Tr(M0 M1 M2) (plus optional shifts), but lets data choose the best combination.
- If min_eigenvalue and residual_energy drop significantly vs the previous K=6 solve, we are converging on the correct structured cubic in this coordinate basis.
- If not, the 3×3×3 labeling needs refinement or the generator set still contains non-stabilizer directions.

## Next
- Compare to the K=6 solve numerically; if improved, run stability test with different generator samples.
- If improved a lot, use this coefficient vector as initialization for full Sym^3 hunt restricted to this support.
- If not improved, re-optimize the 3×3×3 labeling to maximize invariance of the structured cubic.
