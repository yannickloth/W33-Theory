# Cubic invariant hunt on extracted subalgebra; see JSON.
