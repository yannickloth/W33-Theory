# Step 3: hold-out test within extracted subalgebra

- generators_total: 82
- train_generators: 57
- hold_generators: 25
- steps: 25
- batch: 10
- eta0: 0.018
- decay: 0.985
- eval_each: 20
- num_tests: 12
- init_tensor: toe_candidate_cubic_tensor_sym3_subalgebra.npy

## Results
- train_mean: 2.60962
- hold_mean: 3.70966
- ratio_hold_train: 1.422
- tensor saved: toe_candidate_cubic_tensor_sym3_subalgebra_holdout.npy

## Interpretation
- If ratio_hold_train is near 1, the tensor is invariant for the whole extracted subalgebra (not overfitting).
- If ratio is significantly >1, the extracted set still contains directions not compatible with the invariant, or we need more training / Lanczos.
- This is the most direct 'E6 fingerprint' test we can do in-chat.

## Next
- If ratio near 1: attempt to compress/sparsify tensor into a canonical 45-term basis (learn basis change).
- If ratio high: refine the extracted subalgebra (prune generators that spike hold energy) and repeat.
- Run Lanczos on the extracted subalgebra operator A for a more reliable smallest-eigenvector.
