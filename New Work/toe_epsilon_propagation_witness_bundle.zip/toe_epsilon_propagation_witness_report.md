# ε-channel propagation witness test

## Definition
ε-edge iff cross-block translation t=(1,1) (Pauli XZ ~ iY) in either direction between the two blocks

## Counts
- H27_vertices: 27
- pool_edges: 243
- schlafli_edges: 216
- bad_edges: 27
- eps_edges_in_schlafli: 54
- eps_edges_in_bad: 0

## Witness support distributions (Schläfli edges)
- eps: {'n': 54, 'w_out_3': 54, 'w_in_1': 54}
- non-eps: {'n': 162, 'w_out_3': 162, 'w_in_1': 162}

## ε-flow graph (only ε Schläfli edges)
- components>1: 3
- top component sizes: [9, 9, 9]

## Takeaways
- E6 firewall is equivalent to the witness-subset syndrome: bad(u,v) iff W(u,v)⊂H12.
- All ε-edges are Schläfli (allowed) edges; ε never appears on bad edges (categorical prohibition).
- Empirically, ε-edges always have witnesses outside H12, i.e. their transcript is distributed/nonlocal.
- Thus ε-channel propagation is intrinsically nonlocal in the witness sense — matching fermion/parity nonlocality intuition.
