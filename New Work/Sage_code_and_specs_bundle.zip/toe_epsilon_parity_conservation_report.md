# ε-parity conservation test (topological charge candidate)

## Candidate invariant
There exists a global Z2 potential f on H27 such that for all allowed (Schläfli) edges, f(u)⊕f(v)=ε(u,v), where ε(u,v)=1 iff the composite channel t=(1,1) is present between their blocks. This makes ε-count along any allowed path path-independent mod2.

## Cocycle solve on Schläfli graph
- consistent_on_schlafli: False
- num_components_labeled: 1
- num_labeled_vertices: 27
- num_inconsistency_edges: 212

## Firewall violation test
- bad_edges_total: 27
- bad_edges_that_would_violate_cocycle_if_allowed: 10

Examples (up to 10):
- {'edge': [24, 30], 'label_u': 0, 'label_v': 1, 'flip': 0}
- {'edge': [18, 23], 'label_u': 0, 'label_v': 1, 'flip': 0}
- {'edge': [31, 38], 'label_u': 0, 'label_v': 1, 'flip': 0}
- {'edge': [14, 18], 'label_u': 1, 'label_v': 0, 'flip': 0}
- {'edge': [1, 2], 'label_u': 0, 'label_v': 1, 'flip': 0}
- {'edge': [11, 16], 'label_u': 0, 'label_v': 1, 'flip': 0}
- {'edge': [27, 30], 'label_u': 0, 'label_v': 1, 'flip': 0}
- {'edge': [2, 3], 'label_u': 1, 'label_v': 0, 'flip': 0}
- {'edge': [11, 21], 'label_u': 0, 'label_v': 1, 'flip': 0}
- {'edge': [36, 38], 'label_u': 0, 'label_v': 1, 'flip': 0}

## Cycle sanity example
{'cycle_nodes': [31, 1, 1, 14], 'back_edge': [31, 14], 'flip_parity': 1}

## Key readout
- If the cocycle is consistent, then ε-parity between endpoints is a conserved 'charge' in the allowed graph (Schläfli): any two paths between the same endpoints have the same ε-count mod2.
- If many bad edges violate this cocycle relation, then the firewall can be read as enforcing the global ε-parity potential (preventing local-only edges that would break the invariant).
