# S6-native constraint solve: reconstruct D4 connection from odd-triple curvature

- best_cost (violated triples): 0 / 120
- perfect solution found: True
- agreement with observed on 36 free edges: 10/36 = 0.278

- If best_cost=0, then the S6-native syndrome rule plus the fixed star gauge fully determines a consistent D4 connection on all edges.
- Match_rate measures how close that purely constrained solution is to the observed transport; if high, it suggests near-uniqueness (up to residual gauge) and that transport is largely fixed by curvature.
- If best_cost>0, constraints may require a broader group than D4 or additional phase/clock terms.
