# Local 1-form clock on N180 edges: Z2^2 translation × Z6 phase

- directed fiber edges: 360
- k6 distribution: {'0': 90, '3': 20, '2': 36, '5': 89, '4': 36, '1': 89}
- clock pairs present: 23/24
- missing pairs: [{'t': [1, 1], 'k6': 3}]

## Notes
- This is a local 1-form: a phase class k6 assigned to each directed N180 interaction edge in the 10-block bundle.
- Because each transport has translation t_AB ∈ Z2^2 and each edge carries phase class k6 ∈ Z6, the natural local clock space is Z2^2×Z6 (24 states).
- This is the per-edge refinement of the loop holonomy clock; loop phases are products of edge phases and are constrained by affine holonomy.
