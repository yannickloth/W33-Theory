# S6-native connection solve attempt (equivariant/gauge perspective)

## Pure gauge fit test
- violated directed edges: 72
## Triangle holonomy in D4 label group
- total holonomy distribution: {'(0, (1, 0))': 28, '(1, (0, 0))': 29, '(1, (1, 1))': 31, '(0, (0, 1))': 32}
- odd triple holonomy distribution: {'(1, (0, 0))': 29, '(1, (1, 1))': 31}
- even triple holonomy distribution: {'(0, (1, 0))': 28, '(0, (0, 1))': 32}

## Interpretation
If violated_directed_edges>0, the connection is not pure gauge; the obstruction is exactly the curvature.
Odd triples should concentrate on nontrivial holonomy class; even triples on identity, matching the syndrome definition.
