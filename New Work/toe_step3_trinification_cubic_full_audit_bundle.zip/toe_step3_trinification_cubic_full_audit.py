# Full cubic audit; see JSON/MD for details.
