# Full audit: structured trinification cubic vs extracted generators

- templates K=9, support p=84
- min_eigenvalue (global): 1.528e-15

## Residual stats
- min_residual: 0
- median_residual: 0
- mean_residual: 4.12063e-32
- max_residual: 6.38773e-31
- min_eigenvalue: 1.52768e-15
- stabilizer_generators_count (residual<=1e-8): 82/82

## Top offenders
- {'gen': 'cartan_6', 'index': 80, 'residual': 6.387730341916376e-31}
- {'gen': 'cartan_0', 'index': 74, 'residual': 4.227392718042966e-31}
- {'gen': 'cartan_3', 'index': 77, 'residual': 4.2032452428906345e-31}
- {'gen': 'cartan_1', 'index': 75, 'residual': 4.199395263792821e-31}
- {'gen': 'cartan_7', 'index': 81, 'residual': 4.16905857578454e-31}
- {'gen': 'cartan_2', 'index': 76, 'residual': 4.1654610928732835e-31}
- {'gen': 'edge_13_22', 'index': 46, 'residual': 4.1561775086882294e-31}
- {'gen': 'cartan_5', 'index': 79, 'residual': 2.230797225459438e-31}
- {'gen': 'cartan_4', 'index': 78, 'residual': 4.9909726894388094e-33}
- {'gen': 'edge_4_12', 'index': 44, 'residual': 0.0}
- {'gen': 'edge_0_23', 'index': 45, 'residual': 0.0}
- {'gen': 'edge_3_10', 'index': 42, 'residual': 0.0}
- {'gen': 'edge_18_24', 'index': 47, 'residual': 0.0}
- {'gen': 'edge_9_24', 'index': 56, 'residual': 0.0}
- {'gen': 'edge_16_18', 'index': 49, 'residual': 0.0}
- {'gen': 'edge_4_19', 'index': 50, 'residual': 0.0}
- {'gen': 'edge_0_4', 'index': 51, 'residual': 0.0}
- {'gen': 'edge_11_24', 'index': 52, 'residual': 0.0}
- {'gen': 'edge_17_18', 'index': 53, 'residual': 0.0}
- {'gen': 'edge_3_23', 'index': 54, 'residual': 0.0}

## Next
- Compute rank estimate of the stabilizer generator set (expect ~78).
- Rerun commutator-rank probe and compare to 78; if matches, we can assert E6-algebra emergence.
- Map generator actions back to block/ε structure to interpret as symmetry breaking constraints.
