# Automorphism group of the 2-(10,3,4) design from the Z2 cocycle

- v=10, b=60, k=3, λ=4
- Computed stabilizer of point 0 (0 fixed): |Stab(0)| = 72
- Runtime: 0.016s

## Stabilizer element-order distribution
{'1': 1, '2': 21, '3': 8, '4': 18, '6': 24}

## Inferred full group order
If point-transitive: |Aut(design)| = 10 * |Stab(0)| = 720

## Images of point 1 under Stab(0)
[1, 2, 3, 4, 5, 6, 7, 8, 9]
