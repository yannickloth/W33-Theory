# Sector role clustering from Field Atlas + E6 alignment

## E0
- primary_role: dark
- auth_gain: 6.17995e-18, block_gain: 5.42101e-18
- ent_auth: 1.64085, auth_rate_proxy: 1
- scores: {'router': 0.0, 'endpoint': 0.0, 'firewalled': 0.0, 'dark': 2.215886870113365}
- E6 involvement: {'schlafli_incidence': 10.800000000000018, 'bad_incidence': 1.3499999999999992, 'schlafli_minus_bad': 9.450000000000019}

## E1
- primary_role: router
- auth_gain: 1.83881e-16, block_gain: 1.66533e-16
- ent_auth: 1.64085, auth_rate_proxy: 1
- scores: {'router': 0.0, 'endpoint': 0.0, 'firewalled': 0.0, 'dark': -0.2639904038751176}
- E6 involvement: {'schlafli_incidence': 53.999999999999986, 'bad_incidence': 6.74999999999999, 'schlafli_minus_bad': 47.24999999999999}

## E2
- primary_role: router
- auth_gain: 1.43982e-15, block_gain: 1.18655e-15
- ent_auth: 1.64085, auth_rate_proxy: 1
- scores: {'router': 0.0, 'endpoint': 0.0, 'firewalled': 0.0, 'dark': -0.5399709883511055}
- E6 involvement: {'schlafli_incidence': 97.20000000000029, 'bad_incidence': 12.15, 'schlafli_minus_bad': 85.05000000000028}

## E3
- primary_role: router
- auth_gain: 5.41234e-16, block_gain: 4.51028e-16
- ent_auth: 1.64085, auth_rate_proxy: 1
- scores: {'router': 0.0, 'endpoint': 0.0, 'firewalled': 0.0, 'dark': -0.5739632363673464}
- E6 involvement: {'schlafli_incidence': 107.99999999999999, 'bad_incidence': 13.500000000000005, 'schlafli_minus_bad': 94.49999999999999}

## E4
- primary_role: router
- auth_gain: 4.71845e-16, block_gain: 3.53884e-16
- ent_auth: 1.64085, auth_rate_proxy: 1
- scores: {'router': 0.0, 'endpoint': 0.0, 'firewalled': 0.0, 'dark': -0.5739632363673464}
- E6 involvement: {'schlafli_incidence': 108.0, 'bad_incidence': 13.500000000000004, 'schlafli_minus_bad': 94.5}

## E5
- primary_role: router
- auth_gain: 2.42861e-16, block_gain: 2.15106e-16
- ent_auth: 1.64085, auth_rate_proxy: 1
- scores: {'router': 0.0, 'endpoint': 0.0, 'firewalled': 0.0, 'dark': -0.26404201153910983}
- E6 involvement: {'schlafli_incidence': 54.0, 'bad_incidence': 6.7499999999999964, 'schlafli_minus_bad': 47.25}

## Interpretation
- router: high authenticated amplification + high entropy (connects broadly across sectors)
- endpoint: high authenticated amplification + low entropy (connects strongly but narrowly)
- firewalled: high firewall amplification (disproportionately present in bad predicate)
- dark: low auth_rate_proxy (weak authenticated presence relative to raw contact)
