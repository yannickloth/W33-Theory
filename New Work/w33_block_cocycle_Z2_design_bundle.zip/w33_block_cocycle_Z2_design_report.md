# Z2 reduction of the D4 block cocycle: a 2-(10,3,4) design

We have a 10×4 block system. The inter-block bijections π_{ij} live in D4. The cocycle defect δ(i,j,k)=π_{ik}^{-1}π_{jk}π_{ij} takes only identity or reflections.

## Step 1: Quotient reflections by opposite-reflection (multiply by r180)
This collapses the 4 reflections into 2 classes (a Z2 value).

## Step 2: δ̄ on unordered triples
After this quotient, δ̄ is well-defined on unordered triples {i,j,k} of distinct blocks and is invariant under ordering.

## Result: a 2-(10,3,4) design
- Number of blocks (triples with δ̄=1): 60
- Each vertex occurs in 18 such triples.
- Each pair occurs in exactly 4 such triples (λ=4).

This gives a canonical Z2 triple-parity structure on the 10 blocks.
