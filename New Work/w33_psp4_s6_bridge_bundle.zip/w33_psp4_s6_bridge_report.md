# Bridging the S6-like subgroup to the index-2 mu=1 subgroup (PSp4(3) candidate)

- Built full G (|G|=51840) in 0.802s

- Built mu=1 subgroup G0 (|G0|=25920) in 0.632s

- DS0 stabilizer H in G has size 72

- Found K⊂G0 of order 720: True (trials 1417)

  - K generator orders: [5, 2, 6]

- Using small generators, computed |<H,K>| inside G0 as 25920


## Interpretation

- If |<H,K>| = 25920, then H and K generate all of G0 ≅ PSp4(3), and K is a maximal S6-subgroup.

- If |<H,K>| is smaller, we need to adjust K choice (different conjugate) or use additional generators.