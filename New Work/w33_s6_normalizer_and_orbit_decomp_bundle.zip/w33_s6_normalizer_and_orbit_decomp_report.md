# Orbit decomposition of 720 double-sixes under an S6-sized subgroup K

- Found K of order 720 after 843 trials.

- K generator orders: [4, 5, 4]

- K splits the 720 DS into 4 orbits with sizes: [60, 120, 180, 360]

- Normalizer size |N_G(K)| = 1440

- Distinct normalizer permutations on K-DS-orbits: 1


## Top normalizer-induced permutations on K-orbits

- count 1440: [0, 1, 2, 3]


## Notes

- This particular K is not transitive on the 720 DS orbit; it has multiple orbit sizes.

- Normalizer size 1440 indicates N_G(K) is a Z2-extension of K (likely).

- The normalizer's induced action permutes the K-orbits on DSs; the distribution above summarizes that.
