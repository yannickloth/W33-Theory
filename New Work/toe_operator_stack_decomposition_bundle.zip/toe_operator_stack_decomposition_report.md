# Operator stack decomposition in rank-6 idempotent basis

- chosen v: 0
- H27 size: 27
- ||S - (nonedge-bad)||_F = 0.000e+00

## nonedge_sub_on_H27
- Fro norm: 22.0454, trace: 0
- alpha sector averages:
  - E0: 12.15
  - E1: -1.35
  - E2: -1.35
  - E3: -1.35
  - E4: 1.35
  - E5: 1.35
- scalar-fit residuals:
  - E0: 1.30109e-14
  - E1: 2.46475
  - E2: 3.00749
  - E3: 3.94018
  - E4: 3.32039
  - E5: 0.67082

## bad_predicate
- Fro norm: 7.34847, trace: 0
- alpha sector averages:
  - E0: 1.35
  - E1: -0.15
  - E2: -0.15
  - E3: -0.15
  - E4: 0.15
  - E5: 0.15
- scalar-fit residuals:
  - E0: 1.53185e-15
  - E1: 1.25499
  - E2: 0.972111
  - E3: 1.8775
  - E4: 2.24165
  - E5: 0.67082

## S_schlafli
- Fro norm: 20.7846, trace: 0
- alpha sector averages:
  - E0: 10.8
  - E1: -1.2
  - E2: -1.2
  - E3: -1.2
  - E4: 1.2
  - E5: 1.2
- scalar-fit residuals:
  - E0: 1.43509e-14
  - E1: 1.34164
  - E2: 2.54558
  - E3: 2.56905
  - E4: 5.53173
  - E5: 1.34164

## Notes
- Each operator is embedded as a 40x40 matrix supported on the H27 indices (global Witting labeling).
- alphas are sector averages Tr(Ei O)/Tr(Ei); residuals measure deviation from scalar on each sector.
- norm_coupling shows cross-sector coupling induced by the operator.
- Compare S_schlafli to nonedge_minus_bad to confirm exact equality.
