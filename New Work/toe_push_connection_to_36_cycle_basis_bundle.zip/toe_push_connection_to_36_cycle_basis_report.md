# Push N180 connection onto the 36-cycle (loop) basis of K10

Holonomy matrices: {'((1, 0), (0, 1))': 18, '((0, 1), (1, 0))': 18}

Holonomy translations: {'(0, 1)': 8, '(0, 0)': 9, '(1, 1)': 9, '(1, 0)': 10}

Fiber return counts: {'(0, 1)': 8, '(0, 0)': 9, '(1, 0)': 10}

Phase k6 counts: {'5': 10, '1': 5, '4': 6, '0': 6}

See CSV for per-cycle records.
