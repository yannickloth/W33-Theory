# Next steps: build the *correct* Heisenberg–Weyl/Clifford model for the 40 Witting states

## What we tested
- 2-qubit Clifford on C^4
- GF(3) omega^x embedding of 40 projective points into C^4

## What happened
- The omega^x embedding from GF(3)^4 projective points into C^4 does not make W33 K4 lines orthonormal bases under Hermitian inner product (max overlap ~1).
- Attempted to lift Aut(W33) generator permutations to SU(4) unitaries under omega embedding; robust Procrustes lifting failed (no unitary realizing those permutations on rays).
- Therefore the correct '40 rays / 40 tetrads' Hilbert-space embedding must use the Witting configuration definition (GF(4)/E8 complexification phases), not the GF(3) omega embedding.
- Next step is to construct the Witting 40 rays explicitly (from Vlasov's papers or standard Witting polytope coordinates) and then re-run: (a) Clifford/Heisenberg–Weyl subgroup, (b) compare invariance of rank-6 idempotents.

## What to do next (action plan)
1. Parse 'Scheme of quantum communications based on Witting polytope' to extract explicit 40 state vectors or generating rules for them.
1. Or parse 'Quantum entanglement and contextuality with complexifications of E8 root system' for the explicit ray construction.
1. Once 40 vectors are built, compute tetrads (bases) and verify each state belongs to 4 bases (40 bases).
1. Then compute Clifford/metaplectic group preserving the set and compare with rank-6 idempotents commutators.
