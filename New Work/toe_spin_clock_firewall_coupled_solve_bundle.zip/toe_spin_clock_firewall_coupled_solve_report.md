# Spin–clock coupled inverse solve with firewall constraints

- best_cost: 289 (even_penalty=289, odd_penalty=0)
- perfect: False
Even size distribution: {6: 50, 5: 9, 4: 1}
Odd size distribution: {4: 11, 3: 6, 6: 29, 5: 14}
- p=2 edges (free/total): 0/0
- p=2 on forbidden pairs: 0 (should be 0)

- This solve couples Q8 sign to Z6 clock and enforces firewall prohibition by forbidding p=2 on vulnerable/ε-related block pairs.
- A perfect cost=0 would mean the combined constraints are jointly satisfiable and the lift is essentially forced.
- If cost>0, the next escalation is to allow p in Z4 or to include an additional term depending directly on k6 (not only parity/set sizes).
