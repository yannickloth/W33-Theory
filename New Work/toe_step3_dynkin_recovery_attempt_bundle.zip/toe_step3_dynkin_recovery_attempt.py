# Dynkin recovery attempt; see JSON/MD.
