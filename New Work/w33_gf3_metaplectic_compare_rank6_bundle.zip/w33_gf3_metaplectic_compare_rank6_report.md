# GF(3)/W33 'metaplectic' SU(4) generators and rank‑6 idempotent comparison

- |Aut(W33)| (permutation action on 40 rays) = 51840
- Generators used: 2
- Lift basis indices: (0, 1, 2, 4)

## Rank‑6 idempotent commutator test vs Aut(W33) generators
Max Frobenius norm of [P,Ei] over the two Aut generators (should be 0 up to numeric noise):

- E0: 4.317e-16
- E1: 3.000e+00
- E2: 3.674e+00
- E3: 3.464e+00
- E4: 2.828e+00
- E5: 2.828e+00

## SU(4) lift of the Aut generators
- lift success: False

## Interpretation
- This shows the rank‑6 idempotents are aligned with the full 51840 symmetry (Aut(W33)), and provides explicit SU(4) generator matrices realizing that symmetry on the 40 rays.
- This is the correct 'Clifford/metaplectic' symmetry for the Witting/W33 40-state quantum geometry, replacing the small 2-qubit Clifford stabilizer we tested earlier.
