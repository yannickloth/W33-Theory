# Primitive idempotents and eigenmatrices (P,Q) for the W33 5-class algebra

Relations (columns): ['I', 'E20', 'E40', 'E180', 'N']

## Multiplicities (ranks of primitive idempotents)
[10, 5, 10, 5, 10]

## Split seed
Linear combo used: {'E20': -3, 'E40': -2, 'E180': -3, 'N': 1}
Eigenvalues: [-10.999999999999998, -9.000000000000009, -7.000000000000017, 12.999999999999973, 14.999999999999991] with multiplicities [5, 10, 10, 5, 10]

## P eigenmatrix
|Ei| I | E20 | E40 | E180 | N |
|---|---|---|---|---|---|
|E0| 1 | 1 | 2 | 0 | 0 |
|E1| 1 | 1 | -2 | 3 | -3 |
|E2| 1 | -1 | 0 | 3 | -3 |
|E3| 1 | 1 | -2 | -3 | 3 |
|E4| 1 | -1 | 0 | -3 | 3 |

## Q eigenmatrix
|Ei| I | E20 | E40 | E180 | N |
|---|---|---|---|---|---|
|E0| 10 | 10 | 10 | 0 | 0 |
|E1| 5 | 5 | -5 | 5/3 | -5/9 |
|E2| 10 | -10 | 0 | 10/3 | -10/9 |
|E3| 5 | 5 | -5 | -5/3 | 5/9 |
|E4| 10 | -10 | 0 | -10/3 | 10/9 |

## Notes
- Rows are primitive idempotents E0..E4 with E0 the trivial (all-ones) eigenspace.
- Columns are relations: I, E20, E40, E180, N.
- P_{i,j} gives eigenvalue of adjacency matrix for relation j on eigenspace i.
- E_i = (1/n) * sum_j Q_{i,j} A_j.
