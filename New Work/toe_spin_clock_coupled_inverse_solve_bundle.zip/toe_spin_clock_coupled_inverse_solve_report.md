# Spin–clock coupled inverse solve (Q8 sign + Z6 k6)

Define lifted phase Phi = k6_sum + sign_sum mod6, where sign_sum is derived from p_AB∈{0,2} mapped to 0/3 ticks and reversed on opposite orientation. This couples Q8 sign to the Z6 clock.

- best_cost: 289 (even_penalty=289, odd_penalty=0)
Even size distribution: {6: 50, 5: 9, 4: 1}
Odd size distribution: {4: 11, 3: 6, 6: 29, 5: 14}
- p=2 edges (free/total): 0/0

- This is the first explicit coupled inverse solve using the actual k6 clock data (which depends on the transported key x).
- If even triples compress while odd remain expanded, that's a concrete signature that the Q8 sign is locked to the Z6 clock in exactly the way expected for a spin–clock coupling.
- Next refinement: incorporate the firewall/ε constraint by forbidding p=2 on edges that would correspond to ε-channel in vulnerable witness configurations.
