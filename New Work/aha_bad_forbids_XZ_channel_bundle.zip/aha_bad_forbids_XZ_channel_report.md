# Aha: E6 firewall forbids the XZ (11) translation channel

## Statement
When we interpret the Z2×Z2 translation tick t as a Pauli-frame update X^t0 Z^t1, the composite channel **XZ (t=11)** never appears on E6 bad (firewall) edges.

## Evidence
- bad edges count with XZ: 0
- Schläfli edges count with XZ: 54
- Authenticated N180 edges count with XZ: 36

## Interpretation
- Interpret fiber label x∈Z2^2 as Pauli exponent (a,b) -> X^a Z^b.
- Translation t_AB is then a Pauli-frame update; t=11 corresponds to XZ (~ iY), the composite/fermion channel in toric-code language (epsilon = e*m).
- The E6 bad predicate (firewall) removes exactly those interactions where the composite channel would be used; i.e., it enforces a 'no-fermion-channel' rule at those edges.
- This is a crisp encryption/topological selection rule: certain session-key translations are disallowed in vulnerable witness configurations.

## Next test
- Compute the same signature exclusion on the 36-loop basis and check whether forbidden XZ translations correspond to syndrome bits (odd triples) or loop parity.
