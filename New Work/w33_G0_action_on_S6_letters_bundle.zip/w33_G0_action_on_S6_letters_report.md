# Explicit S6 action induced from W33 via the 10 parabolic blocks

We use the canonical K-induced block system (10 blocks of size 4) and the canonical dictionary mapping each block to a 3+3 partition of 6 letters.

## Group sizes
{'G': 51840, 'G0': 25920, 'K': 720, 'N': 1440, 'S6_image_on_blocks': 720}

## Stabilizers in S6 image (on 6 letters)
{'stab_letter0': 120, 'stab_duad_01_setwise': 48, 'stab_partition_part0': 72}

## Stabilizers pulled back to N (|N|=1440)
{'preimage_stab_letter0': 240, 'preimage_stab_duad_01_setwise': 96, 'preimage_stab_partition_part0': 144}

## Stabilizer chain in N fixing ordered letters
- fix_0: 240
- fix_0_1: 48
- fix_0_1_2: 12
- fix_0_1_2_3: 4
- fix_0_1_2_3_4: 2
- fix_0_1_2_3_4_5: 2

Kernel Z2 persists after fixing all letters.
