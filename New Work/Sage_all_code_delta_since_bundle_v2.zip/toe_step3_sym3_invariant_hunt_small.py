# Reduced Sym^3 invariant hunt. See JSON/MD for parameters.
