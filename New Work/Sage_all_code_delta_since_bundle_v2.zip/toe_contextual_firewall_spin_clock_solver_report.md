# Contextual firewall spin–clock inverse solve (fast incremental)

- solver: contextual firewall constrained spin–clock inverse solve (fast incremental)
- Nsamp: 2500
- nvar: 72
- forbidden_transitions: 288
- best_cost: 242
- even_size_distribution: {'4': 15, '5': 18, '3': 3, '6': 24}
- odd_size_distribution: {'4': 19, '6': 14, '5': 23, '3': 4}
- even_penalty: 243
- odd_penalty: 0
- p2_transition_count: 37

## Notes
- This solve applies firewall at transition level (A,B,x) rather than block-pair level.
- Objective uses sampled triangle traversals; to harden the result, increase Nsamp and/or evaluate on full traversal set.
