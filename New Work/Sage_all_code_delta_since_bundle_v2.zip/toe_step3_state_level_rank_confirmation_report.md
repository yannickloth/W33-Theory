# Step 3: state-level Lie rank confirmation pass

- proj_dim=500, comm_samples=10000, seed=0, threshold=1e-06
- Schläfli edges: 216

## Results
- rank_edge_only: 248
- rank_edge_plus_cartan: 271

## Interpretation
- If these ranks are stable and far below proj_dim, they are likely the true span ranks for the generated Lie algebra under the current generator model.
- If rank_edge_plus_cartan ≈ rank_edge_only, the Cartan directions are already generated (or irrelevant for span) by commutators of edge generators.
- If ranks are near 78, it strongly supports an e6 minrep-like algebra emerging from the contextual Z6×Q8 weighting; otherwise further invariants (e.g., cubic form preservation) are needed.
