# Sym^3(27) multicache generalization test (batched) — v2

- init tensor: toe_candidate_cubic_tensor_sym3_multicache_batched.npy
- train steps=20, eta0=0.012, decay=0.99
- caches=8, eval_each=20, unique_idx=212

## Per-cache ratios
- cache 0: ratio=1.227 (E_train=3.2934, E_hold_mean=4.04167)
- cache 1: ratio=1.280 (E_train=3.92514, E_hold_mean=5.02361)
- cache 2: ratio=1.512 (E_train=3.90194, E_hold_mean=5.90026)
- cache 3: ratio=1.454 (E_train=3.61548, E_hold_mean=5.25536)
- cache 4: ratio=1.529 (E_train=3.44101, E_hold_mean=5.2612)
- cache 5: ratio=1.761 (E_train=2.91127, E_hold_mean=5.1256)
- cache 6: ratio=1.314 (E_train=4.22055, E_hold_mean=5.5444)
- cache 7: ratio=1.758 (E_train=3.625, E_hold_mean=6.37162)

## Aggregate
- ratio_mean: 1.47921
- ratio_std: 0.19092
- ratio_min: 1.2272
- ratio_max: 1.7606

- tensor saved: toe_candidate_cubic_tensor_sym3_multicache_batched_v2.npy
