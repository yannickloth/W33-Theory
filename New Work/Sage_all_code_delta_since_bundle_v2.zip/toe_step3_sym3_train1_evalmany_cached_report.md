# Sym^3(27) invariant hunt: train-once, evaluate-many (cached)

- init_tensor: toe_candidate_cubic_tensor_sym3_refined_holdout_fast.npy
- train_size: 140
- steps: 18
- batch: 10
- eta0: 0.02
- decay: 0.985
- eval_each: 30
- num_hold_tests: 12
- holdout_pool_cached: 76
- train_cache: 60
- note: We precompute ||D_X(T)||^2 once for a pool of generators; subset energies are sums of cached values.

## Results
- E_train_eval30_cached: 6.00945
- holdout energies cached (n=12): [6.905408, 7.34569, 7.984998, 6.211948, 6.231264, 7.787534, 7.246842, 6.82364, 5.782452, 6.624134, 7.059879, 7.405009]
Aggregate:
- E_train_eval30_cached: 6.00945
- E_hold_mean: 6.95073
- E_hold_std: 0.631472
- E_hold_min: 5.78245
- E_hold_max: 7.985
- ratio_mean_over_train: 1.15663
- tensor saved: toe_candidate_cubic_tensor_sym3_train1_evalmany_cached.npy

## Interpretation
- If holdout energies cluster near train energy (ratio near 1), tensor is aligning with a global invariant direction.
- If ratio >> 1, tensor is not generalizing; need Lanczos on full operator or a better generator subalgebra.
- If both are high, invariant likely exists but requires basis change or more accurate generator algebra.

## Next
- Repeat with different holdout_pool_sel and train_sel to reduce cache bias.
- Increase cached holdout pool size toward all hold edges (96) if needed.
- Use the learned tensor as warm start for a longer Lanczos run with a larger generator sample.
