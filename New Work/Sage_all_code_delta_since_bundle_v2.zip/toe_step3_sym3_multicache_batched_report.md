# Sym^3(27) cubic tensor: multicache generalization test (batched)

## Setup
- init_tensor: toe_candidate_cubic_tensor_sym3_train1_evalmany_cached.npy
- train_size: 140
- train_steps: 10
- batch: 8
- eta0: 0.012
- decay: 0.99
- num_caches: 8
- hold_pool_size: 40
- train_cache_size: 40
- eval_each: 20
- num_hold_tests_per_cache: 10
- unique_edge_indices_evaluated: 212
- note: We compute ||D_X(T)||^2 once per unique edge index across all caches; subset energies are sums of cached values.

## Per-cache ratios
- cache 0: ratio=1.114 (E_train=3.58686, E_hold_mean=3.99718, std=0.342603)
- cache 1: ratio=1.188 (E_train=4.02787, E_hold_mean=4.78342, std=0.469558)
- cache 2: ratio=1.465 (E_train=3.95762, E_hold_mean=5.79808, std=0.751771)
- cache 3: ratio=1.478 (E_train=3.53017, E_hold_mean=5.21873, std=0.416844)
- cache 4: ratio=1.366 (E_train=3.72982, E_hold_mean=5.09414, std=0.521516)
- cache 5: ratio=1.581 (E_train=3.19132, E_hold_mean=5.0444, std=0.666382)
- cache 6: ratio=1.138 (E_train=4.63611, E_hold_mean=5.27487, std=0.534892)
- cache 7: ratio=1.625 (E_train=3.74638, E_hold_mean=6.08818, std=0.823911)

## Aggregate
- ratio_mean: 1.36933
- ratio_std: 0.188004
- ratio_min: 1.1144
- ratio_max: 1.62509

- tensor saved: toe_candidate_cubic_tensor_sym3_multicache_batched.npy

## Interpretation
- Ratios near 1 across caches indicate the tensor is capturing a global invariant direction of the algebra.
- Large ratios or large variance indicates either overfitting, insufficient training, or that invariance requires a basis change / true e6 generator set.

## Next
- Increase train_steps modestly (e.g., 20) and re-run caching to see if ratios move toward 1.
- Increase hold_pool_size/train_cache_size to 60 if runtime permits.
- Use this tensor as warm start for a longer Lanczos run with a larger generator sample.
