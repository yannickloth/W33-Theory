# Step 3: exact-firewall restricted Z6-twisted sl9 rank

- forbidden pairs total: 9 (exact firewall-only: 0, epsilon: 9)
- allowed basis dim: 62 / 80 (removed 18)
- closure rank: 62 (rounds=1), gap to 78: -16

## Interpretation
- This replaces the coarse restriction (forbid if any bad edge exists) with an exact aggregated witness restriction (forbid only if the pair is purely bad).
- If rank moves closer to 78 relative to the coarse model, that supports E6 emerging only when firewall is applied correctly (contextually).
- If rank remains far from 78, the missing ingredient is likely the Q8 lift (spin sign) in the structure constants, not just Z6 clock phase.

## Next
- Compute closure with no pair sampling (full pair set) for a smaller seed (e.g., odd-loop generators) to get an exact rank.
- Integrate Q8 sign lift into coefficients: use p in Z4 or Z2×Z6 as the coefficient field.
- Compute the automorphism group of the resulting bracketed subspace (linear maps preserving bracket) to compare with Weyl(E6).
