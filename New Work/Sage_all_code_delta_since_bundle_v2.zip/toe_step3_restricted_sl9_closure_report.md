# Step 3: restricted sl9 closure under firewall/ε generator deletion

- forbidden block pairs: 36
- restricted closure dim (support): 8 (E=0, H=8), full=80, drop=72
- odd-loop-seeded closure dim: 8, drop from full=72

- This computes a restricted Lie-bracket closure in an sl9 ambient, where forbidden block pairs (firewall/ε) delete corresponding oriented root generators.
- If the resulting closure dimension approaches 78, that supports an E6-like emergence (dim E6 = 78).
- If the closure remains far from 78, then exceptional structure must be imposed via phase-dependent structure constants (Q8/Z6) rather than simple generator deletion.
