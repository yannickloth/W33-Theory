# Batched multicache generalization test for Sym^3 invariance. See JSON.
