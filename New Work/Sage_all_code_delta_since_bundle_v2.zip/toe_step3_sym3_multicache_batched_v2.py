# v2 multicache batched generalization test; see JSON.
