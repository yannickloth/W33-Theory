# Step 3: explicit isomorphism Aut(design) ≅ S6 (outer action resolved)

## Key result
- Aut(design) on 10 points has size 720.
- In the 10-point action, point stabilizers have size 72 (index 10), so this is an outer S6 action.
- We find an index-6 subgroup H of size 120 (an S5), and use cosets G/H to build a 6-letter action.
- The induced action has size 720 → explicit isomorphism to S6.

## Index-6 subgroup (size 120)
- generators (10-point perms): [(8, 3, 2, 6, 7, 0, 9, 1, 5, 4), (4, 0, 9, 2, 1, 8, 5, 7, 6, 3), (6, 2, 9, 5, 7, 4, 3, 0, 8, 1)]
## Coset reps (6 letters)
- letter 0: rep (0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
- letter 1: rep (0, 1, 2, 3, 9, 7, 8, 5, 6, 4)
- letter 2: rep (0, 1, 3, 2, 5, 4, 6, 9, 8, 7)
- letter 3: rep (0, 1, 3, 2, 7, 9, 8, 4, 6, 5)
- letter 4: rep (0, 2, 1, 3, 6, 5, 4, 7, 9, 8)
- letter 5: rep (0, 2, 1, 3, 8, 7, 9, 5, 4, 6)

## Generator pair in S6 (found)
- g6_a = (4, 5, 3, 1, 2, 0)
- g6_b = (1, 4, 3, 0, 5, 2)

## Point stabilizers in 10-point action
Each point stabilizer has size 72; mapped into S6 it may fix no single letter (outer action).
- point 0: Stab size=72, image_size=72, fixed_letters=[]
- point 1: Stab size=72, image_size=72, fixed_letters=[]
- point 2: Stab size=72, image_size=72, fixed_letters=[]
- point 3: Stab size=72, image_size=72, fixed_letters=[]
- point 4: Stab size=72, image_size=72, fixed_letters=[]
- point 5: Stab size=72, image_size=72, fixed_letters=[]
- point 6: Stab size=72, image_size=72, fixed_letters=[]
- point 7: Stab size=72, image_size=72, fixed_letters=[]
- point 8: Stab size=72, image_size=72, fixed_letters=[]
- point 9: Stab size=72, image_size=72, fixed_letters=[]
