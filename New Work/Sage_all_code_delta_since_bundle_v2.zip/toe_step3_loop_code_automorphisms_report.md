# Step 3: loop-code automorphisms (E6 hinge route)

## Triangle syndrome design
- triangle class counts: {'0': 60, '1': 60}
- odd triples: 60
- lambda set: [4]

## Automorphism sizes
- Aut_design_size: 720
- Aut_design_fix0_size: 72
- induced_action_on_36_loops_size: 72

## Sample design automorphisms (10-point perms)
- (0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
- (0, 1, 2, 3, 9, 7, 8, 5, 6, 4)
- (0, 1, 3, 2, 5, 4, 6, 9, 8, 7)
- (0, 1, 3, 2, 7, 9, 8, 4, 6, 5)
- (0, 1, 6, 8, 4, 9, 2, 7, 3, 5)
- (0, 1, 6, 8, 5, 7, 3, 9, 2, 4)
- (0, 1, 8, 6, 7, 5, 3, 4, 2, 9)
- (0, 1, 8, 6, 9, 4, 2, 5, 3, 7)
- (0, 2, 1, 3, 6, 5, 4, 7, 9, 8)
- (0, 2, 1, 3, 8, 7, 9, 5, 4, 6)
- (0, 2, 3, 1, 5, 6, 4, 8, 9, 7)
- (0, 2, 3, 1, 7, 8, 9, 6, 4, 5)

## Interpretation
- Aut(design) size=720 strongly suggests S6 (since |S6|=720).
- Stabilizer of a point of size 120 strongly suggests S5 (since |S5|=120).
- Thus the 2-(10,3,4) triangle-syndrome design carries an S6 symmetry, grounding the E6/double-six hinge story.
