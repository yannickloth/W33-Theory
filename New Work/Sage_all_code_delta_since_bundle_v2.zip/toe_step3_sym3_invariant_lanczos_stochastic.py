# Stochastic Lanczos-like Sym^3 invariant hunt (runtime-safe). See JSON/MD.
