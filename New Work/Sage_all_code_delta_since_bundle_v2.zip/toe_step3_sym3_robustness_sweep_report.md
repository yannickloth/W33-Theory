# Sym^3(27) cubic invariant hunt: robustness sweep over train/hold splits

- init tensor: toe_candidate_cubic_tensor_sym3_refined_holdout_fast.npy
- splits=6, train_size=120, steps=40, batch=12
- eval per side: 60 generators

## Per-split results
- split 0: E_train=7.95402 E_hold=16.8367 ratio=2.117
- split 1: E_train=9.7296 E_hold=15.3318 ratio=1.576
- split 2: E_train=11.5537 E_hold=14.0594 ratio=1.217
- split 3: E_train=10.6932 E_hold=12.8849 ratio=1.205
- split 4: E_train=12.4207 E_hold=12.1418 ratio=0.978
- split 5: E_train=9.67846 E_hold=15.1048 ratio=1.561

## Aggregate
- E_train_mean: 10.3383
- E_train_std: 1.43934
- E_hold_mean: 14.3932
- E_hold_std: 1.57127
- ratio_mean: 1.4421
- ratio_std: 0.367392
- ratio_min: 0.977545
- ratio_max: 2.11676

## Interpretation
- If E_hold tracks E_train across splits (ratio near 1 with small spread), the tensor is aligning with an invariant direction of the underlying algebra, not memorizing a subset.
- If E_hold >> E_train systematically, we are overfitting and need the smallest-eigenvector method (Lanczos on the full operator) or a better generator subalgebra approximation.
- If both energies remain far from 0, either the generator set is not yet the true e6 stabilizer in this basis or the invariant requires a basis change to become numerically accessible.

## Next
- Use the best split tensor as warm start and increase eval_generators_each to full 216 edge generators for definitive energy.
- Build a reduced generator set from the rank-confirmed subalgebra (not random edges) and repeat.
- Attempt to learn a linear basis change that sparsifies the invariant (moving toward the 45-term Cayley–Salmon form).
