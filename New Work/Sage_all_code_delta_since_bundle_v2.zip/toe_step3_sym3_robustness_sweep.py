# Robustness sweep for Sym^3 invariance energy across splits. See JSON.
