# Generated in-chat; see JSON/MD for outputs.
