# Sym^3(27) invariant hunt: stochastic Lanczos-like run (runtime-safe)

- generators: 20 (edges 16 + cartan 4)
- k_eff=8, batch_size=4
- tridiagonal min eig: -2.12283
- Rayleigh quotient (eval all gens): 8.92518
- tensor saved: toe_candidate_cubic_tensor_sym3_lanczos_stochastic.npy

- Increase batch_size and k_iters, or cycle through all generators across iterations to reduce stochasticity.
- Use the resulting tensor as a warm start for the fast SGD solver on the full generator set.
- Hold-out test: build a different sampled edge set and check whether rq stays low.
