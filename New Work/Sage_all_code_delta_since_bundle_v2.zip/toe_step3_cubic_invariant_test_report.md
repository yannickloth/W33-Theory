# Step 3: cubic invariant test (45 tritangent-plane monomials)

## Goal
Find an invariant cubic supported on the 45 complement triangles (tritangent planes) under the contextual Z6×Q8 Schläfli-edge generator set.

## Setup
- triangles_count: 45
- monomial_universe_count: 1125
- unknown_coeffs: 45
- approach: For each generator X, build linear map A_X: c -> coefficients of degree-3 monomials in d/dt C(e^{tX}x)|_{t=0}. Accumulate Gram = Σ A_X^* A_X. Nullspace(Gram) gives invariant coefficient vectors.

## Outcome
- nullspace_dim: 0
- min_eigenvalue: 48.0
- max_eigenvalue: 48.0
- interpretation: No nonzero coefficient vector on these 45 monomials is invariant under the current generator set. This suggests the E6 cubic invariant is not represented in this coordinate basis as a sparse 45-term sum (or the generator set is not yet the true e6 stabilizer).

## Next steps
- General cubic search: allow a full symmetric cubic tensor on 27 vars (dim Sym^3 = C(29,3)=3654). Search for invariant tensor by minimizing Σ||X·T||^2 or by iterative nullspace projection.
- Change coordinate basis: the classical 45-term Cayley–Salmon cubic uses a special coordinate system; our H27 labeling is not that basis. Need to find the basis change (linear transform) that makes the invariant sparse.
- Tighten the generator set to the inferred e6 candidate: use the rank-confirmed subalgebra (if near 78) and re-run invariant search.
