# Step 3 algebra probe: A8 roots → sl9 bracket closure from loop generators

## A8 identification
36 rooted loops (i-0-j-i) with 1<=i<j<=9 are in bijection with the 36 positive roots of A8: alpha_ij = e_i - e_j (i<j). Oriented loops correspond to full root set (72).

- odd syndrome loops: 18
- even syndrome loops: 18
- syndrome counts: {0: 18, 1: 18}

## sl9 closure (basis-support)
- closure dims: {'odd': 80, 'even': 80, 'all': 80}
- iterations: {'odd': 2, 'even': 2, 'all': 2}

## Commutator-induced loop graph
- edges: 90
- top component sizes: [36]

- Compute the *exact* linear Lie algebra dimension over R (not just basis-support closure) by tracking coefficients (structure constants) and taking span rank.
- Test whether imposing firewall/epsilon restrictions on allowed commutators reduces the closure dimension to 78 (E6) or other Lie-type dimensions.
- Upgrade bracket to use measured phase/holonomy signs (Q8/Z6) as structure constants to distinguish between sl9 and exceptional subalgebras.
