# Step 3: state-level su(27) Lie rank estimate (contextual Z6×Q8 phases)

- initial generators: 242 (edges 216 + Cartan 26)
- sampled commutators: 2500
- rank estimate (proj_dim=300): 247

- If rank_est clusters near 78, that's strong evidence the contextual phase-weighted Schläfli generators realize (or are close to) the 27-dim minrep of e6.
- If rank_est is far larger, we must enforce additional invariants (e.g., cubic form preservation) or restrict generators by firewall at the state level.
- If rank_est is smaller, the generator set is too constrained or requires including both directional phases per edge.
