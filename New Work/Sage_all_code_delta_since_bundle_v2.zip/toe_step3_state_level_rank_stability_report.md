# Step 3: state-level Lie rank stability sweep (reduced)

- Schläfli edges: 216
- Cartan generators: 26

## Top stable settings
- edge_only | proj_dim=300 comm_samples=1500 ranks=[224, 224] mean=224.00
- edge_only | proj_dim=300 comm_samples=500 ranks=[224, 224] mean=224.00
- edge_only | proj_dim=200 comm_samples=1500 ranks=[200, 200] mean=200.00
- edge_plus_cartan | proj_dim=200 comm_samples=1500 ranks=[200, 200] mean=200.00
- edge_only | proj_dim=200 comm_samples=500 ranks=[200, 200] mean=200.00
- edge_plus_cartan | proj_dim=200 comm_samples=500 ranks=[200, 200] mean=200.00

## All results
- edge_only | proj_dim=200 comm_samples=500 ranks=[200, 200] mean=200.00
- edge_only | proj_dim=200 comm_samples=1500 ranks=[200, 200] mean=200.00
- edge_only | proj_dim=300 comm_samples=500 ranks=[224, 224] mean=224.00
- edge_only | proj_dim=300 comm_samples=1500 ranks=[224, 224] mean=224.00
- edge_plus_cartan | proj_dim=200 comm_samples=500 ranks=[200, 200] mean=200.00
- edge_plus_cartan | proj_dim=200 comm_samples=1500 ranks=[200, 200] mean=200.00
- edge_plus_cartan | proj_dim=300 comm_samples=500 ranks=[247, 250] mean=248.50
- edge_plus_cartan | proj_dim=300 comm_samples=1500 ranks=[247, 250] mean=248.50

## Notes
- This is a reduced sweep to keep runtime bounded; if ranks are consistent across seeds and below proj_dim, the estimate is likely exact.
- If rank is far above 78, we likely need additional invariants (e.g., cubic form preservation) or tighter firewall filtering at the state-generator level.
- Next: repeat with larger comm_samples (e.g., 5000) but single seed, or increase proj_dim to 500 for confirmation.
