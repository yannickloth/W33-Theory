# Generated in-chat; see JSON for full settings/results.
