# Sym^3(27) cubic invariant hunt (reduced run)

- generators: 32 (edges 24 + cartan 8)
- steps=25, batch=4, eta=0.05
- final energy: 4.997133506236033
- tensor saved: toe_candidate_cubic_tensor_sym3_small.npy

## History
- step 0: eval_energy=7.37972
- step 5: eval_energy=6.78059
- step 10: eval_energy=6.18701
- step 15: eval_energy=5.81919
- step 20: eval_energy=5.33382
- step 24: eval_energy=4.99713

## Next
- Scale generator set (more edges) and steps; use larger eval set; track energy decay.
- Switch to implicit Lanczos/power on L=Σ(-D_X^2) to target smallest eigenvector more reliably.
- If energy plateaus far from 0, constrain generators to the rank-confirmed subalgebra before searching for invariant.
