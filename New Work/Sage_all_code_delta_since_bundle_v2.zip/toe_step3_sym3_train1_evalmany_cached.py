# Cached train-once evaluate-many holdout for Sym^3 invariance. See JSON.
