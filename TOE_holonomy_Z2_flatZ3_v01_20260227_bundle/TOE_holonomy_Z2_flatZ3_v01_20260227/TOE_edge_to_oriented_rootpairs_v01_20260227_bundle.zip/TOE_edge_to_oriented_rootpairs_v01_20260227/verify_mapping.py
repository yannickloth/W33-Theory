
#!/usr/bin/env python3
import json, math
from collections import deque

def perm_order(p):
    n=len(p); vis=[False]*n; lcms=1
    for i in range(n):
        if not vis[i]:
            j=i; cyc=0
            while not vis[j]:
                vis[j]=True; j=p[j]; cyc+=1
            lcms = lcms*cyc//math.gcd(lcms,cyc)
    return lcms

def canon_rot(triple):
    rots = [tuple(triple[i:]+triple[:i]) for i in range(3)]
    return min(rots)

def act_on_triple(g, T):
    img = []
    for a,b in T:
        img.append(tuple(sorted((g[a], g[b]))))
    return canon_rot(img)

def main():
    edge_gens=json.load(open("sp43_generators_on_edges_240.json"))
    root_gens=json.load(open("sp43_generators_on_roots_240.json"))
    m=json.load(open("edge_to_oriented_rootpair_triple.json"))
    # Build edge list in same order as keys in CSV? We'll just validate equivariance on ids via CSV.
    import pandas as pd
    df=pd.read_csv("edge_to_oriented_rootpair_triple.csv")
    # mapping by edge_id
    edge_to_T={}
    for _,row in df.iterrows():
        eid=int(row.edge_id)
        T=((int(row.pair1_a),int(row.pair1_b)),
           (int(row.pair2_a),int(row.pair2_b)),
           (int(row.pair3_a),int(row.pair3_b)))
        edge_to_T[eid]=T

    # Check generator orders match expected (3,3,3,3,3,3,4,4,2,2)
    orders_e=[perm_order(p) for p in edge_gens]
    orders_r=[perm_order(p) for p in root_gens]
    assert orders_e==orders_r, (orders_e, orders_r)

    # Check equivariance
    for gi in range(len(edge_gens)):
        gE=edge_gens[gi]; gR=root_gens[gi]
        for eid in range(240):
            eid2=gE[eid]
            if edge_to_T[eid2] != act_on_triple(gR, list(edge_to_T[eid])):
                raise RuntimeError(f"Equivariance failed at gen {gi} edge {eid}")
    print("OK: equivariant mapping edge -> oriented rootpair triple (size 240).")
if __name__=="__main__":
    main()
