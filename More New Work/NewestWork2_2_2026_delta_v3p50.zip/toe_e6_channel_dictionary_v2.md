# TOE E6 Channel Dictionary v2 (operator-supported)

This upgrades v1 by matching each certified simple root to an **actual exported E6 basis operator** and extracting a representative (p→q) support in the Cartan eigenbasis.

- firewall bad-edge list present: False
- perm_to_canonical: [1, 2, 5, 4, 0, 3]

## α1
- cert key: [-123194, -3839, -1262, -153894, 124141, 38006, -16792, -113338, 132631, 171051, 59949, 54254]
- cert weight (real6): [-0.123194, -0.003839, -0.001262, -0.153894, 0.124141, 0.038006]
- matched root key: [-0.0, 0.0, -0.005479, -0.0, -0.0, 0.0] (L∞ err 1.54e-01)
- top basis candidates: [{'basis_index': 3, 'mass': 0.12135026776391679}, {'basis_index': 4, 'mass': 0.12135026776391677}]
- representative basis index: 3
- dominant support p→q: [7, 2]
- Schläfli edge: True
- firewall blocked: False
- phase bins Z12/Z24: 2 / 4

## α2
- cert key: [-103878, 131637, 53732, 146817, 154414, -43409, 181280, 155033, 77919, -224048, -56770, 100255]
- cert weight (real6): [-0.103878, 0.131637, 0.053732, 0.146817, 0.154414, -0.043409]
- matched root key: [-0.0, 0.0, -0.005479, -0.0, -0.0, 0.0] (L∞ err 1.54e-01)
- top basis candidates: [{'basis_index': 3, 'mass': 0.12135026776391679}, {'basis_index': 4, 'mass': 0.12135026776391677}]
- representative basis index: 3
- dominant support p→q: [7, 2]
- Schläfli edge: True
- firewall blocked: False
- phase bins Z12/Z24: 2 / 4

## α3
- cert key: [-19316, -135476, -54994, -300710, -30273, 81415, -164487, -41694, -210550, 52997, -3178, -154510]
- cert weight (real6): [-0.019316, -0.135476, -0.054994, -0.30071, -0.030273, 0.081415]
- matched root key: [-0.0, 0.0, -0.005479, -0.0, -0.0, 0.0] (L∞ err 3.01e-01)
- top basis candidates: [{'basis_index': 3, 'mass': 0.12135026776391679}, {'basis_index': 4, 'mass': 0.12135026776391677}]
- representative basis index: 3
- dominant support p→q: [7, 2]
- Schläfli edge: True
- firewall blocked: False
- phase bins Z12/Z24: 2 / 4

## α4
- cert key: [19316, 135476, 54994, 300710, 30273, -81415, -164487, -41694, -210550, 52997, -3178, -154510]
- cert weight (real6): [0.019316, 0.135476, 0.054994, 0.30071, 0.030273, -0.081415]
- matched root key: [-0.0, 0.0, -0.005479, -0.0, -0.0, 0.0] (L∞ err 3.01e-01)
- top basis candidates: [{'basis_index': 3, 'mass': 0.12135026776391679}, {'basis_index': 4, 'mass': 0.12135026776391677}]
- representative basis index: 3
- dominant support p→q: [7, 2]
- Schläfli edge: True
- firewall blocked: False
- phase bins Z12/Z24: 2 / 4

## α5
- cert key: [22155, 86930, -114556, 572928, 88505, 80341, 0, 0, 0, 0, 0, 0]
- cert weight (real6): [0.022155, 0.08693, -0.114556, 0.572928, 0.088505, 0.080341]
- matched root key: [-0.5, 0.0, -0.0, 0.0, 0.0, 0.0] (L∞ err 5.73e-01)
- top basis candidates: [{'basis_index': 0, 'mass': 0.5971449356583509}, {'basis_index': 2, 'mass': 0.29857246782917546}]
- representative basis index: 0
- dominant support p→q: [0, 26]
- Schläfli edge: True
- firewall blocked: False
- phase bins Z12/Z24: 8 / 16

## α6
- cert key: [112116, -39627, 58540, -132570, -168393, -78177, 37219, 67403, 61528, -52574, -105446, 97112]
- cert weight (real6): [0.112116, -0.039627, 0.05854, -0.13257, -0.168393, -0.078177]
- matched root key: [-0.0, 0.0, -0.005479, -0.0, -0.0, 0.0] (L∞ err 1.68e-01)
- top basis candidates: [{'basis_index': 3, 'mass': 0.12135026776391679}, {'basis_index': 4, 'mass': 0.12135026776391677}]
- representative basis index: 3
- dominant support p→q: [7, 2]
- Schläfli edge: True
- firewall blocked: False
- phase bins Z12/Z24: 2 / 4

