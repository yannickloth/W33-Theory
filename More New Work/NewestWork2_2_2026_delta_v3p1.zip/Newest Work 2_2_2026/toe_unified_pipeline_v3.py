#!/usr/bin/env python3
"""
Unified TOE pipeline v3.

Stages:
  1) compute_double_sixes.py  (E8 -> W(E6) orbit -> Schläfli graph -> K6 cliques -> double-sixes)
  2) verify_toe_bridge.py    (W33 firewall split 216/27 inside H27 nonorth pairs)
  3) e8_e6_a2_fusion.py      (E8 -> E6 ⊕ A2 decomposition, SU(3) weights)
  4) Load Chat artifacts     (cubic stabilizer / Dynkin attempts)
  5) Cross-check Dynkin vs double-six chain:
       - Choose best Dynkin candidate from chat artifacts
       - Verify E6 Cartan invariants from candidate
       - Compare with double-six stabilizer order and 15-remaining structure

Outputs:
  artifacts_unified_v3/UNIFIED_REPORT_V3.json
  artifacts_unified_v3/summary.md
  stdout/stderr logs per stage.
"""
from __future__ import annotations
import json, subprocess, sys
from pathlib import Path
import importlib.util

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "artifacts_unified_v3"
OUT.mkdir(parents=True, exist_ok=True)

CHAT_ART = Path("/mnt/data/chat_artifacts")
EXT_ART = Path("/mnt/data/newest_work_2_2_2026/artifacts")

def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, str(path))
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)  # type: ignore
    return mod

def run(cmd: list[str], name: str) -> None:
    p = subprocess.run(cmd, cwd=str(ROOT), capture_output=True, text=True)
    (OUT / f"{name}.stdout.txt").write_text(p.stdout, encoding="utf-8", errors="replace")
    (OUT / f"{name}.stderr.txt").write_text(p.stderr, encoding="utf-8", errors="replace")
    if p.returncode != 0:
        raise RuntimeError(f"{name} failed with code {p.returncode}. See {OUT}/{name}.stderr.txt")

def stage1_double_sixes():
    mod = load_module(ROOT/"compute_double_sixes.py", "compute_double_sixes_mod")
    roots = mod.construct_e8_roots()
    we6_orbits = mod.compute_we6_orbits(roots)
    sizes = sorted([len(o) for o in we6_orbits], reverse=True)
    orbit_27s = [o for o in we6_orbits if len(o) == 27]
    if not orbit_27s:
        raise RuntimeError("No 27-orbit found in WE6 orbits")
    adj, ip_counts = mod.build_schlafli_adjacency(roots, orbit_27s[0])
    ok, msg = mod.verify_srg(adj, 27, 16, 10, 8)
    k6 = mod.find_k_cliques(adj, 6)
    ds = mod.find_double_sixes(adj, k6)
    stab = mod.compute_stabilizer_order(adj, ds[0]) if ds else None
    rem15 = mod.analyze_15_remaining(adj, ds[0]) if ds else None
    return {
        "e8_root_count": len(roots),
        "orbit_sizes": sizes,
        "ip_counts": {str(k): int(v) for k,v in ip_counts.items()},
        "srg_ok": ok,
        "srg_msg": msg,
        "k6_cliques": len(k6),
        "double_sixes": len(ds),
        "stabilizer_order_first": stab,         # (s6_count, swap_ok)
        "remaining15_summary_first": rem15,     # dict
    }

def stage2_verify_bridge():
    run([sys.executable, "verify_toe_bridge.py"], "verify_toe_bridge")
    art = EXT_ART / "toe_bridge_verification.json"
    return json.loads(art.read_text()) if art.exists() else {"status":"no_artifact"}

def stage3_fusion():
    run([sys.executable, "e8_e6_a2_fusion.py"], "e8_e6_a2_fusion")
    art = EXT_ART / "e8_e6_a2_fusion.json"
    return json.loads(art.read_text()) if art.exists() else {"status":"no_artifact"}

def load_chat_artifacts():
    # Load every toe_step3_dynkin*.json and relevant stabilizer summaries if present
    out = {}
    for fn in CHAT_ART.glob("toe_step3_*.json"):
        try:
            out[fn.name] = json.loads(fn.read_text())
        except Exception:
            out[fn.name] = {"parse_error": True}
    return out

def dynkin_score_from_cartan(Cr: list[list[int]]) -> int:
    import numpy as np
    Crn = np.array(Cr, dtype=int)
    if Crn.shape != (6,6):
        return 10**9
    if not np.all(np.diag(Crn)==2):
        return 10**6
    bad = 0
    for i in range(6):
        for j in range(6):
            if i==j: 
                continue
            if Crn[i,j] not in (0,-1):
                bad += 4
    edges = int(np.sum(Crn[np.triu_indices(6,1)]==-1))
    bad += abs(edges-5)*3
    degs = sorted([int(np.sum(Crn[i,:]==-1)) for i in range(6)])
    bad += sum(abs(a-b) for a,b in zip(degs, sorted([1,1,1,2,2,3])))
    return int(bad)

def pick_best_dynkin(chat: dict) -> dict:
    """
    Prefer Killing-metric based candidates over older Euclidean/early attempts.

    Priority order:
      1) toe_step3_dynkin_eps_sweep_killing.json  (explicit eps sweep best_run)
      2) toe_step3_dynkin_metric_sweep_fast.json
      3) toe_step3_dynkin_killing_metric_v2.json
      4) toe_step3_dynkin_lock_attempt_v2.json
      5) any other toe_step3_dynkin*.json containing a best.C_round

    Returns: {"source":..., "best":..., "score":...}
    """
    priority = [
        "toe_step3_dynkin_eps_sweep_killing.json",
        "toe_step3_dynkin_metric_sweep_fast.json",
        "toe_step3_dynkin_killing_metric_v2.json",
        "toe_step3_dynkin_lock_attempt_v2.json",
    ]

    def get_candidate(name: str, obj: dict):
        b = obj.get("best")
        if not isinstance(b, dict):
            # eps_sweep file stores best_run.best maybe
            br = obj.get("best_run")
            if isinstance(br, dict) and isinstance(br.get("best"), dict):
                b = br["best"]
            else:
                return None
        Cr = b.get("C_round")
        if not isinstance(Cr, list):
            return None
        sc = b.get("score")
        if not isinstance(sc, int):
            sc = dynkin_score_from_cartan(Cr)
        return {"source": name, "best": b, "score": int(sc)}

    # Try priority list first
    for name in priority:
        obj = chat.get(name)
        if isinstance(obj, dict):
            cand = get_candidate(name, obj)
            if cand is not None:
                return cand

    # Fallback: scan all
    best = None
    for name, obj in chat.items():
        if not isinstance(obj, dict):
            continue
        cand = get_candidate(name, obj)
        if cand is None:
            continue
        key = (cand["score"], name)
        if best is None or key < best[0]:
            best = (key, cand)
    return best[1] if best else {"missing": True}

def stage5_crosscheck(double6: dict, bridge: dict, fusion: dict, chat: dict):
    checks = {}
    # Double-six invariants
    checks["double_six"] = {
        "e8_roots_240": (double6.get("e8_root_count")==240),
        "k6_cliques_72": (double6.get("k6_cliques")==72),
        "double_sixes_36": (double6.get("double_sixes")==36),
        "stabilizer_tuple": double6.get("stabilizer_order_first"),
        "remaining15": double6.get("remaining15_summary_first"),
    }
    # Firewall invariants
    fw = bridge.get("firewall", {}) if isinstance(bridge, dict) else {}
    good = fw.get("kernel_edges") if isinstance(fw, dict) else None
    bad = fw.get("bad_edges") if isinstance(fw, dict) else None
    total = fw.get("nonorth_pairs_in_H27") if isinstance(fw, dict) else None
    checks["firewall"] = {
        "good": good, "bad": bad, "total": total,
        "matches_216_27_243": (good==216 and bad==27 and total==243)
    }
    # Fusion invariants
    counts = fusion.get("counts", {}) if isinstance(fusion, dict) else {}
    checks["fusion"] = {
        "e8_roots_240": (counts.get("e8_roots")==240),
        "we6_orbit_sizes": counts.get("we6_orbit_sizes"),
        "a2_cartan_ok": fusion.get("checks", {}).get("a2_cartan_ok") if isinstance(fusion.get("checks", {}), dict) else None,
    }
    # Dynkin candidate
    dyn = pick_best_dynkin(chat)
    checks["dynkin_candidate"] = dyn
    if "best" in dyn:
        Cr = dyn["best"].get("C_round")
        checks["dynkin_candidate"]["computed_score"] = dynkin_score_from_cartan(Cr) if isinstance(Cr, list) else None
    # Human-facing link: if dynkin score 0 and double-six stabilizer (720,True) -> order 1440, we are at E6
    checks["breakthrough"] = {
        "dynkin_score_is_0": (dyn.get("score")==0),
        "double_six_stabilizer_is_S6xZ2": (double6.get("stabilizer_order_first")==[720, True] or double6.get("stabilizer_order_first")== (720, True)),
        "firewall_exact": (good==216 and bad==27 and total==243),
    }
    return checks

def main():
    report = {}
    report["stage1_double_sixes"] = stage1_double_sixes()
    report["stage2_verify_bridge"] = stage2_verify_bridge()
    report["stage3_fusion"] = stage3_fusion()
    report["chat_artifacts"] = load_chat_artifacts()
    report["checks"] = stage5_crosscheck(report["stage1_double_sixes"], report["stage2_verify_bridge"], report["stage3_fusion"], report["chat_artifacts"])

    (OUT/"UNIFIED_REPORT_V3.json").write_text(json.dumps(report, indent=2), encoding="utf-8")

    # summary
    lines = []
    lines.append("# Unified TOE Pipeline v3 Summary")
    d6 = report["stage1_double_sixes"]
    lines.append(f"- E8 roots: {d6.get('e8_root_count')}")
    lines.append(f"- K6 cliques: {d6.get('k6_cliques')} (expect 72)")
    lines.append(f"- Double-sixes: {d6.get('double_sixes')} (expect 36)")
    lines.append(f"- Stabilizer (S6 count, swap_ok): {d6.get('stabilizer_order_first')} (expect (720,True))")
    fw = report["checks"]["firewall"]
    lines.append(f"- Firewall (good,bad,total): {(fw.get('good'), fw.get('bad'), fw.get('total'))} (expect (216,27,243))")
    dyn = report["checks"]["dynkin_candidate"]
    lines.append(f"- Dynkin candidate source: {dyn.get('source')}, score: {dyn.get('score')}")
    lines.append("")
    lines.append("## Breakthrough flags")
    for k,v in report["checks"]["breakthrough"].items():
        lines.append(f"- {k}: {v}")
    (OUT/"summary.md").write_text("\n".join(lines), encoding="utf-8")
    print("Wrote artifacts_unified_v3/UNIFIED_REPORT_V3.json and summary.md")

if __name__ == "__main__":
    main()
