# TOE Coupling Pruning v1

We test how couplings vanish as firewall strength increases by pruning operator support on firewall-bad edges.

- overlap kill threshold: 0.2
- total couplings analyzed: 15
- counts by class: {'backbone': 10, 'mixed': 2, 'coset': 3}

## Outputs
- coupling_pruning_curves.png
- coupling_kill_hist.png
- toe_coupling_pruning_summary.json
