#!/usr/bin/env python3
"""
Unified TOE pipeline v2.

Adds Stage 4 cross-checks against the in-chat "cubic stabilizer / Cartan rank-6" artifacts extracted from ChatGPT bundles.

Outputs:
  artifacts_unified_v2/UNIFIED_REPORT_V2.json
  artifacts_unified_v2/summary.md
"""
from __future__ import annotations
import json, subprocess, sys, shutil
from pathlib import Path
import importlib.util

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "artifacts_unified_v2"
OUT.mkdir(parents=True, exist_ok=True)

CHAT_ART = Path("/mnt/data/chat_artifacts")

def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, str(path))
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)  # type: ignore
    return mod

def run(cmd: list[str], name: str) -> str:
    p = subprocess.run(cmd, cwd=str(ROOT), capture_output=True, text=True)
    (OUT / f"{name}.stdout.txt").write_text(p.stdout, encoding="utf-8", errors="replace")
    (OUT / f"{name}.stderr.txt").write_text(p.stderr, encoding="utf-8", errors="replace")
    if p.returncode != 0:
        raise RuntimeError(f"{name} failed with code {p.returncode}. See {OUT}/{name}.stderr.txt")
    return p.stdout

def stage_compute_double_sixes():
    mod = load_module(ROOT/"compute_double_sixes.py", "compute_double_sixes_mod")
    roots = mod.construct_e8_roots()
    we6_orbits = mod.compute_we6_orbits(roots)
    sizes = sorted([len(o) for o in we6_orbits], reverse=True)
    orbit_27s = [o for o in we6_orbits if len(o) == 27]
    # build schlafli adjacency for first 27-orbit
    adj, ip_counts = mod.build_schlafli_adjacency(roots, orbit_27s[0])
    ok, msg = mod.verify_srg(adj, 27, 16, 10, 8)
    k6 = mod.find_k_cliques(adj, 6)
    ds = mod.find_double_sixes(adj, k6)
    stab = mod.compute_stabilizer_order(adj, ds[0]) if ds else None
    rem15 = mod.analyze_15_remaining(adj, ds[0]) if ds else None
    return {
        "e8_root_count": len(roots),
        "orbit_sizes": sizes,
        "ip_counts": {str(k): int(v) for k,v in ip_counts.items()},
        "srg_ok": ok,
        "srg_msg": msg,
        "k6_cliques": len(k6),
        "double_sixes": len(ds),
        "stabilizer_order_first": stab,   # (s6_count, swap_ok)
        "remaining15_summary_first": rem15,
    }

def stage_verify_toe_bridge():
    run([sys.executable, "verify_toe_bridge.py"], "verify_toe_bridge")
    art = Path("/mnt/data/newest_work_2_2_2026/artifacts/toe_bridge_verification.json")
    if art.exists():
        return json.loads(art.read_text(encoding="utf-8"))
    return {"status": "no_artifact"}

def stage_e8_e6_a2_fusion():
    run([sys.executable, "e8_e6_a2_fusion.py"], "e8_e6_a2_fusion")
    art = Path("/mnt/data/newest_work_2_2_2026/artifacts/e8_e6_a2_fusion.json")
    if art.exists():
        return json.loads(art.read_text(encoding="utf-8"))
    return {"status":"no_artifact"}

def load_chat_artifacts():
    need = [
        "toe_step3_breakthrough_full_sym3_audit.json",
        "toe_step3_tolerance_sweep_stabilizer_rank.json",
        "toe_step3_dynkin_killing_metric_v2.json",
        "toe_step3_dynkin_eps_sweep_killing.json",
        "toe_step3_dynkin_metric_sweep_fast.json",
        "toe_step3_closure_residuals_basis78.json",
    ]
    out = {}
    for fn in need:
        p = CHAT_ART / fn
        out[fn] = json.loads(p.read_text()) if p.exists() else {"missing": True}
    return out

def cross_checks(double6: dict, bridge: dict, fusion: dict, chat: dict):
    checks = {}
    checks["double_six_counts"] = {
        "k6_cliques_is_72": (double6.get("k6_cliques")==72),
        "double_sixes_is_36": (double6.get("double_sixes")==36),
        "stabilizer_1440": (double6.get("stabilizer_order_first") and double6.get("stabilizer_order_first")[0]==720),
    }
    fw = bridge.get("firewall", {})
    if isinstance(fw, dict):
        good = fw.get("kernel_edges")
        bad  = fw.get("bad_edges")
        total = fw.get("nonorth_pairs_in_H27")
    else:
        good = bad = total = None
    counts = {"good": good, "bad": bad, "total": total} if (good is not None and bad is not None and total is not None) else None
    checks["firewall_counts"] = {
        "expected": {"good":216, "bad":27, "total":243},
        "observed": counts,
        "matches": (counts=={"good":216,"bad":27,"total":243}) if isinstance(counts, dict) else False,
    }
    # sanity: E8 roots count 240
    checks["fusion_counts"] = {
        "e8_roots_240": (fusion.get("counts",{}).get("e8_roots")==240) if isinstance(fusion, dict) else False
    }
    return checks

def main():
    report = {}
    report["stage1_double_sixes"] = stage_compute_double_sixes()
    report["stage2_verify_bridge"] = stage_verify_toe_bridge()
    report["stage3_e8_e6_a2_fusion"] = stage_e8_e6_a2_fusion()
    report["chat_artifacts"] = load_chat_artifacts()
    report["checks"] = cross_checks(report["stage1_double_sixes"], report["stage2_verify_bridge"], report["stage3_e8_e6_a2_fusion"], report["chat_artifacts"])

    (OUT/"UNIFIED_REPORT_V2.json").write_text(json.dumps(report, indent=2), encoding="utf-8")

    lines = []
    lines.append("# Unified TOE Pipeline v2 Summary")
    d6 = report["stage1_double_sixes"]
    lines.append(f"- E8 roots: {d6.get('e8_root_count')}")
    lines.append(f"- K6 cliques: {d6.get('k6_cliques')} (expect 72)")
    lines.append(f"- Double-sixes: {d6.get('double_sixes')} (expect 36)")
    lines.append(f"- Stabilizer (S6 count, swap_ok): {d6.get('stabilizer_order_first')}")
    fw = report["checks"]["firewall_counts"]
    lines.append(f"- Firewall counts observed: {fw.get('observed')} (expect good=216,bad=27,total=243)")
    lines.append("")
    lines.append("## Checks")
    for k,v in report["checks"].items():
        lines.append(f"- **{k}**: {v}")
    (OUT/"summary.md").write_text("\n".join(lines), encoding="utf-8")

    print("Wrote artifacts_unified_v2/UNIFIED_REPORT_V2.json and summary.md")

if __name__ == "__main__":
    main()