# Unified TOE Pipeline v2 Summary
- E8 roots: 240
- K6 cliques: 72 (expect 72)
- Double-sixes: 36 (expect 36)
- Stabilizer (S6 count, swap_ok): (720, True)
- Firewall counts observed: {'good': 216, 'bad': 27, 'total': 243} (expect good=216,bad=27,total=243)

## Checks
- **double_six_counts**: {'k6_cliques_is_72': True, 'double_sixes_is_36': True, 'stabilizer_1440': True}
- **firewall_counts**: {'expected': {'good': 216, 'bad': 27, 'total': 243}, 'observed': {'good': 216, 'bad': 27, 'total': 243}, 'matches': True}
- **fusion_counts**: {'e8_roots_240': True}