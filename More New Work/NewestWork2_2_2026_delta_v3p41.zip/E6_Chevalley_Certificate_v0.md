# E6 Chevalley Certificate v0

- Cartan ad commutator max norm: 3.736e-15
- weight clusters total: 76
- zero weight multiplicity: 3
- nonzero weight clusters: 75 (pairs 7)
- simple roots found (heuristic): 40
- selected 6 simple roots: [(-0.0, 0.0, -0.0, 1e-06, -0.0, 0.0), (-0.0, 1e-06, 0.0, 1e-06, 0.0, 0.0), (1e-06, 1e-06, 0.0, 0.0, 0.0, -2e-06), (0.0, 2e-06, 2e-06, -1e-06, 1e-06, -1e-06), (3e-06, -0.0, 0.0, -0.0, -2e-06, -3e-06), (2e-06, 4e-06, 0.0, 4e-06, 2e-06, 5e-06)]
- dynkin edges (dot heuristic): []
- degree multiset: [0, 0, 0, 0, 0, 0]

Notes:
- Certificate v0: root-weight clustering is computed from ad(Cartan) acting on the exported 78-basis (from v3p38 export).
- Simple roots and Dynkin adjacency are inferred using a dot-product heuristic in weight coordinates; the next refinement is to compute the Killing metric on Cartan (Tr(ad_i ad_j)) and use it to derive the canonical E6 Cartan matrix and Serre checks.
