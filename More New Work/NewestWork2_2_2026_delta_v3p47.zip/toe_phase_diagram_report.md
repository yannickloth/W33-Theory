# TOE Phase Diagram Demo v4

We sweep two knobs:
- firewall_strength ∈ [0,1]: probability of blocking a 'bad' edge (if the bad-edge list exists)
- phase_noise σ: random phase jitter on each directed edge weight

At each grid point we compute:
- best conserved Cartan charge (minimizing drift + commutator norm)
- triangle holonomy entropy (Z24 bins)

## Outputs
- phase_diagram_score.png
- phase_diagram_drift.png
- phase_diagram_comm.png
- phase_diagram_hol_entropy.png
- phase_diagram_edgecount.png
- toe_phase_diagram_summary.json
