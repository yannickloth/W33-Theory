# Dynkin Channel Dictionary: E6 nodes → Schläfli edge channels → double-six sectors

This ties each Dynkin node (simple root) to concrete stabilizer generators (edge channels) and classifies them by where they act relative to a reference double-six.

## Reference double-six (one of 36)
- L: [0, 1, 2, 3, 4, 26]
- M: [19, 20, 21, 22, 24, 25]
- remaining15: [5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 23]
- matching L→M: {0: 19, 1: 20, 2: 21, 3: 22, 4: 24, 26: 25}

## Dynkin edges
[[0, 3], [1, 2], [2, 4], [2, 5], [3, 4]]

## Node a6 (dynkin_node=0)
- cluster_id: 15
- class_hist: {'between_L_M': 1}
- epsilon_hist: {0: 1}
### Top channels
- ['edge', 4, 21] | count=2 | class=between_L_M | epsilon=0

## Node a2 (dynkin_node=1)
- cluster_id: 4
- class_hist: {'touch_L': 1, 'within_remaining15': 4}
- epsilon_hist: {0: 4, 1: 1}
### Top channels
- ['edge', 0, 16] | count=4 | class=touch_L | epsilon=0
- ['edge', 14, 16] | count=4 | class=within_remaining15 | epsilon=0
- ['edge', 16, 18] | count=4 | class=within_remaining15 | epsilon=0
- ['edge', 16, 17] | count=4 | class=within_remaining15 | epsilon=1
- ['edge', 15, 16] | count=4 | class=within_remaining15 | epsilon=0

## Node a3 (dynkin_node=2)
- cluster_id: 18
- class_hist: {'within_remaining15': 1}
- epsilon_hist: {0: 1}
### Top channels
- ['edge', 5, 9] | count=2 | class=within_remaining15 | epsilon=0

## Node a5 (dynkin_node=3)
- cluster_id: 22
- class_hist: {}
- epsilon_hist: {}
### Top channels

## Node a4 (dynkin_node=4)
- cluster_id: 9
- class_hist: {'touch_L': 1}
- epsilon_hist: {0: 1}
### Top channels
- ['edge', 1, 5] | count=2 | class=touch_L | epsilon=0

## Node a1 (dynkin_node=5)
- cluster_id: 3
- class_hist: {'within_L': 2, 'between_L_M': 1, 'touch_L': 1}
- epsilon_hist: {0: 4}
### Top channels
- ['edge', 0, 4] | count=2 | class=within_L | epsilon=0
- ['edge', 4, 19] | count=2 | class=between_L_M | epsilon=0
- ['edge', 2, 4] | count=2 | class=within_L | epsilon=0
- ['edge', 4, 17] | count=2 | class=touch_L | epsilon=0

