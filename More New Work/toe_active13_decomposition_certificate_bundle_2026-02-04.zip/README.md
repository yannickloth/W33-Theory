# Active-13 decomposition certificate (27-rep)

This bundle proves that, in the joint Cartan eigenbasis, the extracted 78-dimensional Lie algebra (your W33-derived operator space) decomposes the 27-dimensional representation as:

- an **active 13-dimensional invariant subspace** (vertices 0..12) where all root-current dynamics lives, and
- **14 isolated singlets** (vertices 13..26) on which *every* algebra generator is numerically zero.

It also exports the Schläfli (27,16)-regular graph restricted to the active 13 vertices; this induced subgraph has 49 edges, exactly:
- 45 root-step edges (distance 1 in the root graph)
- 4 two-step edges (distance 2 via vertex 12)

Files:
- `active_vertices_13.csv`, `isolated_vertices_14.csv`
- `projector_active13.npy`, `projector_isolated14.npy`
- `algebra_generators_isolated14_vanish_certificate.csv`
- `schlafli_active13_edges_49.csv`
- `summary.json`
