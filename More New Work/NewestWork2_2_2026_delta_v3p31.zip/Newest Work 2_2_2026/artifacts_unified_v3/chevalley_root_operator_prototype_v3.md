# Chevalley root-operator prototype v3

This artifact demonstrates explicit root operators in the 27-weight basis:
- Choose E = U E_{pq} U^* between Cartan eigenstates p→q.
- Define F as transpose-conjugate, H=[E,F].
- Then [H,E] = aE with integer a (Cartan action).

## Selected p→q operators
- a1: root=(0.0, 0.0, 0.0, 0.0, 1.0, 0.0) p=4 q=8 edge=(0, 4)
- a2: root=(0.0, 0.0, 0.0, 0.0, 1.0, 0.0) p=24 q=10 edge=(0, 16)
- a3: root=(0.0, 1.0, 0.0, -1.0, 0.0, 0.0) p=21 q=23 edge=(5, 9)
- a4: root=(0.0, 0.0, 0.0, 2.0, 0.0, 0.0) p=23 q=7 edge=(1, 5)
- a5: root=(0.0, 0.0, -1.0, 0.0, 0.0, 0.0) p=3 q=22 edge=(3, 8)
- a6: root=(-1.0, 0.0, 0.0, 0.0, 0.0, 0.0) p=0 q=2 edge=None

## Resulting rounded Cartan matrix
[[2, 0, 0, 0, 0, 0], [0, 2, 0, 0, 0, 0], [0, 0, 2, -1, 0, 0], [0, 0, -1, 2, 0, 0], [0, 0, 0, 0, 2, 0], [0, 0, 0, 0, 0, 2]]

## Closure rank from commutators: 20

## Next
- Use the dynkin-locked root clusters to choose the six true simple roots (not dominant edges).
- Then pick E_{alpha_i} as a matrix unit between weights realizing that root, and propagate roots by commutators to fill 78.
