# Unified TOE Pipeline v3 Summary
- E8 roots: 240
- K6 cliques: 72 (expect 72)
- Double-sixes: 36 (expect 36)
- Stabilizer (S6 count, swap_ok): (720, True) (expect (720,True))
- Firewall (good,bad,total): (216, 27, 243) (expect (216,27,243))
- Dynkin candidate source: toe_step3_dynkin_lock_attempt_v2.json, score: 9

## Breakthrough flags
- dynkin_score_is_0: False
- double_six_stabilizer_is_S6xZ2: True
- firewall_exact: True