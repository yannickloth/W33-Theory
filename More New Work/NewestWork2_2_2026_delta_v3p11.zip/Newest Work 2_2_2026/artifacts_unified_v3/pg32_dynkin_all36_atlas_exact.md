# PG(3,2) × Dynkin channel atlas over all 36 double-sixes (exact-map channels)

This is the upgraded atlas using the **exact Dynkin→generator mapping** channel sets.

Metrics:
- match_frac: remaining15–remaining15 channels on matching-lines
- tri_frac: remaining15–remaining15 channels on triangle-lines
- touch_frac: channels touching remaining15 (remaining↔L/M)

## a1
- edges used: 4
- match_frac: {'mean': 0.2850877192982456, 'stdev': 0.2639607635672119, 'min': 0.0, 'max': 1.0, 'n': 19}
- tri_frac: {'mean': 0.7149122807017544, 'stdev': 0.2639607635672119, 'min': 0.0, 'max': 1.0, 'n': 19}
- touch_frac: {'mean': 0.5277777777777778, 'stdev': 0.23405971592156552, 'min': 0.0, 'max': 1.0, 'n': 36}

## a2
- edges used: 5
- match_frac: {'mean': 0.23916666666666667, 'stdev': 0.25277762515257907, 'min': 0.0, 'max': 1.0, 'n': 20}
- tri_frac: {'mean': 0.7608333333333334, 'stdev': 0.25277762515257907, 'min': 0.0, 'max': 1.0, 'n': 20}
- touch_frac: {'mean': 0.5333333333333333, 'stdev': 0.2, 'min': 0.0, 'max': 0.8, 'n': 36}

## a3
- edges used: 1
- match_frac: {'mean': 0.0, 'stdev': 0.0, 'min': 0.0, 'max': 0.0, 'n': 10}
- tri_frac: {'mean': 1.0, 'stdev': 0.0, 'min': 1.0, 'max': 1.0, 'n': 10}
- touch_frac: {'mean': 0.5555555555555556, 'stdev': 0.49690399499995325, 'min': 0.0, 'max': 1.0, 'n': 36}

## a4
- edges used: 1
- match_frac: {'mean': 0.0, 'stdev': 0.0, 'min': 0.0, 'max': 0.0, 'n': 10}
- tri_frac: {'mean': 1.0, 'stdev': 0.0, 'min': 1.0, 'max': 1.0, 'n': 10}
- touch_frac: {'mean': 0.5555555555555556, 'stdev': 0.49690399499995325, 'min': 0.0, 'max': 1.0, 'n': 36}

## a5
- edges used: 0
- match_frac: None
- tri_frac: None
- touch_frac: None

## a6
- edges used: 1
- match_frac: {'mean': 1.0, 'stdev': 0.0, 'min': 1.0, 'max': 1.0, 'n': 12}
- tri_frac: {'mean': 0.0, 'stdev': 0.0, 'min': 0.0, 'max': 0.0, 'n': 12}
- touch_frac: {'mean': 0.4444444444444444, 'stdev': 0.49690399499995325, 'min': 0.0, 'max': 1.0, 'n': 36}

