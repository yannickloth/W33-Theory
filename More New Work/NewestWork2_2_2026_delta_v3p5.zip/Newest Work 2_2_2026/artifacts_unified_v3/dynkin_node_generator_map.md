# Dynkin node → stabilizer generator mapping (frequency-based)

- tol: 1e-08
- eps_root: 0.0001
- bsub: 220
- stabilizer generators analyzed: 82/82
- root clusters found (under this recluster): 19

## Dynkin edges
[(0, 3), (1, 2), (2, 4), (2, 5), (3, 4)]

## Mapping
### Node 0 (a6)
- target cluster id: 15
- top generators:
  - count=2 gen=('edge', 4, 21)

### Node 1 (a2)
- target cluster id: 4
- top generators:
  - count=4 gen=('edge', 0, 16)
  - count=4 gen=('edge', 14, 16)
  - count=4 gen=('edge', 16, 18)
  - count=4 gen=('edge', 16, 17)
  - count=4 gen=('edge', 15, 16)

### Node 2 (a3)
- target cluster id: 18
- top generators:
  - count=2 gen=('edge', 5, 9)

### Node 3 (a5)
- target cluster id: 22
- **status:** cluster_id_not_found_under_current_recluster

### Node 4 (a4)
- target cluster id: 9
- top generators:
  - count=2 gen=('edge', 1, 5)

### Node 5 (a1)
- target cluster id: 3
- top generators:
  - count=2 gen=('edge', 0, 4)
  - count=2 gen=('edge', 4, 19)
  - count=2 gen=('edge', 2, 4)
  - count=2 gen=('edge', 4, 17)

