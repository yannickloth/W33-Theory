# E6 algebra solve v5 attempt (complex Schur weights, partial roots)

- basis_dim: 78
- cartan_indices: [23, 29, 13, 19, 8, 38]
- ad_norms: [2.0000000465136045, 0.0, 1.7320507642193104, 0.7071068492969229, 1.5811388002866118, 1.7320508717708787]
- schur_combo_imag_diag_max: 1.0000000232568023
- distinct_weight_keys_imag: 18
- distinct_root_keys_mod_sign: 9
- root_mult_hist_mod_sign: {2: 8, 4: 1}

## Root keys (mod sign)
- (-0.0, 0.5, -0.0, -0.0, -0.0, -0.0)
- (0.0, 0.0, 0.0, 0.5, 0.0, 0.0)
- (-0.0, 0.467, -0.0, -0.0, 0.948, -0.0)
- (0.0, 0.426, 0.0, 0.0, -0.547, 0.0)
- (-0.0, -0.0, -0.0, -0.0, 0.5, -0.0)
- (0.0, 0.0, 0.0, 0.0, 0.0, 0.5)
- (1.0, 0.0, 0.0, 0.0, 0.0, 0.0)
- (0.0, 0.0, 0.0, 1.0, 0.0, 0.0)
- (0.0, 0.0, 0.5, 0.0, 0.0, 0.0)

## Notes
- v5 attempt: build ad(H) in correct basis coefficients (QR-based coefficient solve), use complex Schur to extract eigenvalues (imag parts) as weights.
- We currently recover only 9 positive root keys (mod sign), far fewer than E6's 36. This indicates Cartan selection and/or basis construction still needs refinement.
- Next: (1) enforce Cartan from the dynkin_lock_killing_parametric_v2 run (the one that locks Dynkin), (2) compute ad(H) on the commutator-closed basis with exact coefficient solve, (3) increase numerical precision and tighten commuting tolerance.
