
import numpy as np, time, argparse, os, json
def vec(M): return M.reshape(-1)
def close(basis, G0, eps=1e-9, max_new=100000, max_sec=3600):
    # build orthonormal Q via QR
    V=np.stack([vec(M) for M in basis], axis=0)
    Qmat,_=np.linalg.qr(V.T)
    Qrows=Qmat.T
    basis=list(basis)
    start=time.time()
    # process queue = all indices; for speed, you can restrict to a tail window
    queue=list(range(len(basis)))
    added=0
    while queue and added<max_new and time.time()-start<max_sec:
        i=queue.pop(0)
        X=basis[i]
        for Y in G0:
            C=X@Y-Y@X
            v=vec(C)
            coeff=Qrows.conj()@v
            v_res=v-coeff@Qrows
            n=np.sqrt(np.vdot(v_res,v_res).real)
            if n>eps:
                v_new=v_res/n
                Qrows=np.vstack([Qrows, v_new[None,:]])
                basis.append(C)
                queue.append(len(basis)-1)
                added+=1
        if (i%50)==0:
            print("i",i,"dim",len(basis),"queue",len(queue),"added",added,"sec",time.time()-start, flush=True)
    return np.array(basis), {'dim':len(basis),'added':added,'queue_left':len(queue),'sec':time.time()-start}
if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--basis", required=True)
    ap.add_argument("--gen", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--eps", type=float, default=1e-9)
    ap.add_argument("--max_sec", type=float, default=3600)
    ap.add_argument("--tail_only", type=int, default=0, help="if >0, only process last N basis elements as queue seed")
    args=ap.parse_args()
    basis=np.load(args.basis)
    G0=np.load(args.gen)
    if args.tail_only>0:
        basis_seed=basis
        # run closure but start queue on tail; still uses full basis span for projections
        # (edit close() accordingly if desired)
    basis2, stats=close(basis, G0, eps=args.eps, max_sec=args.max_sec)
    np.save(args.out, basis2)
    with open(os.path.splitext(args.out)[0] + "_stats.json","w") as f:
        json.dump(stats,f,indent=2)
    print("DONE",stats)
