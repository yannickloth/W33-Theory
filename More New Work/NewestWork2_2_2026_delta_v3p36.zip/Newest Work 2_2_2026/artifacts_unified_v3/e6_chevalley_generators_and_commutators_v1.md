# E6 Chevalley generators + commutator table v1

## Dimensions
- D6: 66
- coset: 12
- E6: 78
- zero_weight_mult: 78
- root_weight_clusters: 0

## Cartan basis indices (in E6 basis)
[0, 3, 1, 2, 4, 5]

## First 30 generators
- 0: H1
- 1: H2
- 2: H3
- 3: H4
- 4: H5
- 5: H6

## Commutator table (first 30 generators, sparse coefficients)
Each entry stores [G_i,G_j] projected onto the 78-d E6 basis, keeping top coefficients.

Total pairs stored: 15
