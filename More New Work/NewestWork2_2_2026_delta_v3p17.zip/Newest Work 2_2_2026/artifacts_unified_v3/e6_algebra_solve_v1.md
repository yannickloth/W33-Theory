# E6 algebra solve v1 (Cartan + ad(H) weight probe)

- basis_dim: 82
- cartan_idx: [21, 69, 60, 79, 78, 63]
- cartan_rank: 6
- distinct_weights: 1
- zero_weight_key: (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
- root_weight_count: 0
- root_weight_sampled: 0

## Top weight multiplicities (rounded)
- {'weight': '(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)', 'mult': 82}

## Root basis sample (weight -> eigenvector index)

## Notes
- This is algebra solve v1 (provisional): we form a 78-dim commutator-closed basis, select a commuting Cartan, build ad(H) matrices, and approximate root weights via eigenvectors of a random combination of ad(H).
- Next v2: enforce integrality/normalization (Chevalley), extract ± pairs, and compute full structure constants in the Cartan–Weyl basis.
