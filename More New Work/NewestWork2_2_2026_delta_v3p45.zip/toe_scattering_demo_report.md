# TOE Scattering-as-Protocol Demo v2

This demo treats evolution as a **permissioned step operator** on the 27-state Schläfli sector and measures **sector leakage** under a Cartan charge split.

## Graph
- schlafli_edges: 216
- all_edges_used: 216
- firewall_edges_used: 216
- blocked_edges_detected: 0

## Charge sectors
- plus_dim: 2
- minus_dim: 2
- zero_dim: 23
- eigen_min: -0.24999999999999986
- eigen_max: 0.24999999999999983

## Leakage results (1 - dominant-sector probability)
- all_edges_plus: dominant=plus max_leak=0.9277 mean_leak=0.8893
- all_edges_minus: dominant=minus max_leak=0.9440 mean_leak=0.8969
- all_edges_loc: dominant=plus max_leak=0.9604 mean_leak=0.8991
- firewall_plus: dominant=plus max_leak=0.9277 mean_leak=0.8893
- firewall_minus: dominant=minus max_leak=0.9440 mean_leak=0.8969
- firewall_loc: dominant=plus max_leak=0.9604 mean_leak=0.8991

## Interpretation
- If firewall edges reduce leakage, the decoder behaves like a **selection rule / superselection constraint**.
- If leakage persists, the chosen Cartan is not the conserved charge for this step operator; try other Cartan directions or linear combinations.
