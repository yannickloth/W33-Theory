# TOE Scattering-as-Protocol Demo v2

Inputs (expected in /mnt/data):
- toe_discrete_gauge_field_holonomy.json
- toe_local_1form_clock.json
- toe_contextual_firewall_spin_clock_solver.json
- Schläfli adjacency + H27 mapping (from toe_E6_schlafli_from_rank6_restriction bundle)
- Cartan_mats.npy (from v3p38 export)

Outputs:
- toe_scattering_demo_summary.json
- toe_scattering_demo_report.md
- toe_scattering_demo_report.pdf

What it measures:
- Builds a step operator U on allowed edges (with and without firewall blocks)
- Splits Hilbert space into charge sectors using eigen-split of one Cartan generator
- Evolves three initial states (plus-sector, minus-sector, localized injection)
- Reports leakage from the dominant initial sector over time
