# E6 metric-aware simple root search (v2)

We used a metric estimate in Cartan-dual space (from observed root covariance) to select simple-root candidates.

## Result
- Found 6 roots with E6 Dynkin **graph structure** under inner product tolerance.
- Cartan matrix rounding still shows +1 off-diagonals after sign flips ⇒ metric must be refined to the true Killing metric.

## Selected roots
- [-0.0, -0.0, 1.0, -0.0, 1.0, -0.0]  norm^2≈1.929
- [-0.0, 1.0, -1.0, -0.0, -0.0, -0.0]  norm^2≈1.982
- [0.0, 0.0, 0.0, 0.0, 1.0, -1.0]  norm^2≈2.018
- [-0.0, 1.0, -0.0, -0.0, -0.0, 1.0]  norm^2≈2.071
- [-0.0, -0.0, 1.0, -0.0, -1.0, -0.0]  norm^2≈1.929
- [-0.0, -0.0, -0.0, -0.0, 1.0, 1.0]  norm^2≈2.018

## Rounded Cartan (no sign flips)
[[2, -1, 1, 0, 0, 1], [-1, 2, 0, 1, -1, 0], [1, 0, 2, -1, -1, 0], [0, 1, -1, 2, 0, 1], [0, -1, -1, 0, 2, -1], [1, 0, 0, 1, -1, 2]]

## Best sign-flip Cartan
[[2, -1, -1, 0, 0, -1], [-1, 2, 0, -1, 1, 0], [-1, 0, 2, -1, -1, 0], [0, -1, -1, 2, 0, 1], [0, 1, -1, 0, 2, -1], [-1, 0, 0, 1, -1, 2]]

## Next
- Compute Killing metric on Cartan from ad(H) (in the true 78-d algebra basis) and rerun this search.
