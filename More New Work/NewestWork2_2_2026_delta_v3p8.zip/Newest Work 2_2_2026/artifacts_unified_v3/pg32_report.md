# PG(3,2) from the remaining 15

We identify the **remaining15 = C(6,2)** vertices (outside the reference double-six) with the **15 points of PG(3,2)** via the standard K6-edge model.

## Reference double-six split
- L (6): [0, 1, 2, 3, 4, 26]
- M (6): [19, 20, 21, 22, 24, 25]
- remaining15 (15): [5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 23]
- matching L→M: {0: 19, 1: 20, 2: 21, 3: 22, 4: 24, 26: 25}

## K6 / duad labeling
Each remaining vertex is labeled by a duad `{i,j}` on letters 0..5 (from the `a_meets` pairing).

## PG(3,2) construction
- **Points:** 15 duads (edges of K6)
- **Lines:** 35 triples of points, split into:
  - 20 triangle-lines: `{ij, jk, ki}` for each 3-subset {i,j,k}
  - 15 matching-lines: `{ab, cd, ef}` for each perfect matching of K6

## Incidence checks
- points: 15
- lines: 35
- incidences: 105 (expected 15×7 = 105)
- each point on 7 lines: True
- each line has 3 points: True

## Why this matters here
- The remaining15 sector is no longer “leftover”: it is a canonical **projective 3-space over F2**.
- This provides a canonical intermediate structure to relate:
  - the double-six / S6×Z2 symmetry breaking,
  - the firewall 216/27 split (channels touching remaining15),
  - and E8/E6 combinatorics.
