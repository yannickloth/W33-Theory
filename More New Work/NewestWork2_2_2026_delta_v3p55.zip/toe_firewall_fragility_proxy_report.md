# TOE Firewall Fragility v1 (proxy)

We estimate whether coset-heavy outputs are more fragile under firewall strengthening.

## Proxy model
- Uses only the **dominant support edge** of each coupling output.
- If that edge is a firewall-bad edge, survival≈(1-s); otherwise survival≈1.
This is a conservative lower bound.

## Counts
- backbone: 10
- coset: 3
- mixed: 2

## Output
- firewall_fragility_proxy.png
- toe_firewall_fragility_proxy_summary.json
