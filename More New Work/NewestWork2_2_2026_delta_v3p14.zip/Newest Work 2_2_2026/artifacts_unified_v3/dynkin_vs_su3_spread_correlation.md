# Dynkin nodes × SU(3) Z3 spreads on PG(3,2)

We compare Dynkin node channel edges restricted to the reference remaining15=PG(3,2) points, against the **best Z3-induced spreads** (5 disjoint PG lines covering all 15 points).

For each node we report the spread that maximizes the fraction of its collinear remaining15 edges lying **within the spread lines**.

- **a2**: hit_frac=0.000 (hit 0/4) | spread types={'matching': 3, 'triangle': 2} cycles=[[0, 2, 4], [1, 3, 5]]
- **a3**: hit_frac=0.000 (hit 0/1) | spread types={'matching': 3, 'triangle': 2} cycles=[[0, 2, 4], [1, 3, 5]]
