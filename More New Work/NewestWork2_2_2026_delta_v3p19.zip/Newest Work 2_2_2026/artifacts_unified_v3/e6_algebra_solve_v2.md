# E6 algebra solve v2 (invariant root-space extraction)

- basis_dim: 82
- cartan_idx: [21, 69, 60, 79, 78, 63]
- cartan_cluster_size_diag: 82
- clusters_total: 1
- root_keys_mod_sign: 0
- root_mult_hist: {}
- roots_extracted: 0

## Root multiplicity histogram (mod sign)

## Sample roots

## Notes
- v2: root spaces extracted by clustering diagonal ad(H) weights and refining within each cluster by restricted eigenvectors and residual check.
- Next: identify ± pairs, pick simple roots consistent with locked Dynkin, and normalize to Chevalley generators (H_i, E_{±α}).
