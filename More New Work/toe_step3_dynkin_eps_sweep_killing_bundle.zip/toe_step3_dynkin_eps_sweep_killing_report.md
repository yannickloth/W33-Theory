# Dynkin eps_root sweep under Killing proxy metric

- tol=1e-08, Bsub=150, cartan_rank=6
- metric eigs: [0.0, 2.407412143498128e-34]

- eps_root=1e-04: roots=19 best_score=6
- eps_root=2e-04: roots=19 best_score=6
- eps_root=3e-04: roots=19 best_score=6

## Best run
- eps_root=1e-04, roots=19, best_score=6
Rounded Cartan:
- [2, 0, -1, 0, -1, -1]
- [0, 2, 0, 0, 0, 0]
- [-1, 0, 2, 0, -1, 0]
- [0, 0, 0, 2, 0, 0]
- [0, 0, -1, 0, 2, 0]
- [-1, 0, 0, 0, 0, 2]

## Next
- If score==0: output Dynkin edges explicitly.
- If score>0: increase Bsub to 220 and repeat sweep; then do Cartan swap-search.
