# eps_root sweep under Killing metric; see JSON/MD.
