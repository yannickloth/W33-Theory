# Dynkin × SU(3) spread correlation over all 36 double-sixes

For each double-six, we rebuild PG(3,2) on remaining15 and compute, per Dynkin node, which Z3 spread captures the largest share of its collinear remaining15 edges.

## a1
- n double-sixes: 19
- hit_frac mean±stdev: 0.241 ± 0.272 (min 0.000, max 1.000)
- most common winning spreads: [(0, 16), (3, 2), (1, 1)]

## a2
- n double-sixes: 20
- hit_frac mean±stdev: 0.318 ± 0.266 (min 0.000, max 1.000)
- most common winning spreads: [(0, 11), (1, 6), (2, 2)]

## a3
- n double-sixes: 10
- hit_frac mean±stdev: 0.300 ± 0.458 (min 0.000, max 1.000)
- most common winning spreads: [(0, 7), (1, 3)]

## a4
- n double-sixes: 10
- hit_frac mean±stdev: 0.100 ± 0.300 (min 0.000, max 1.000)
- most common winning spreads: [(0, 9), (2, 1)]

## a6
- n double-sixes: 12
- hit_frac mean±stdev: 0.667 ± 0.471 (min 0.000, max 1.000)
- most common winning spreads: [(0, 4), (2, 4), (3, 2)]

