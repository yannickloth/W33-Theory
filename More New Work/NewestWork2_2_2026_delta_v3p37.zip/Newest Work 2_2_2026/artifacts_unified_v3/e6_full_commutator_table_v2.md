# E6 full commutator table v2 (sparse)

## Dimensions
- E6_basis_dim: 78
- zero_weight_mult: 78
- root_weight_clusters: 0
- generators_exported: 6
- pairs_exported: 15

## Cartan indices
[0, 3, 1, 2, 4, 5]

## Generators exported (first 20)
- 0: H1 (cartan)
- 1: H2 (cartan)
- 2: H3 (cartan)
- 3: H4 (cartan)
- 4: H5 (cartan)
- 5: H6 (cartan)

## Commutator pairs stored: 15
Each entry stores [G_i,G_j] projected onto the 78-d basis, keeping top coefficients.
