# PG(3,2) × Dynkin Pattern Extraction

We rank Dynkin nodes by **matching-line bias** vs **triangle-line bias** in the remaining15=PG(3,2) sector.

Definitions:
- match_mean: mean fraction of remaining15–remaining15 channels landing on matching-lines
- tri_mean: mean fraction landing on triangle-lines
- bias = match_mean − tri_mean

## Ranking (highest matching-line bias first)
- **a6**: bias=1.000 | match=1.000±0.000 | tri=0.000±0.000 | touch=0.444±0.497 | edges=1
- **a1**: bias=-0.430 | match=0.285±0.264 | tri=0.715±0.264 | touch=0.528±0.234 | edges=4
- **a2**: bias=-0.522 | match=0.239±0.253 | tri=0.761±0.253 | touch=0.533±0.200 | edges=5
- **a3**: bias=-1.000 | match=0.000±0.000 | tri=1.000±0.000 | touch=0.556±0.497 | edges=1
- **a4**: bias=-1.000 | match=0.000±0.000 | tri=1.000±0.000 | touch=0.556±0.497 | edges=1

## Interpretation hooks
- Nodes with strong **matching-line bias** are likely aligned with the **perfect-matching / duad** structure of K6, which is a known PG(3,2)↔E8 bridge route.
- Nodes with strong **triangle-line bias** are aligned with **triangle incidence** (3-subset structure) and may correspond to different SU(3) weight motion families.
