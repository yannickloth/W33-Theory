# TOE Firewall Fragility v4: per-channel kill order (full support)

- total channels analyzed: 12
- counts by class: {'backbone': 9, 'mixed': 1, 'coset': 2}

## Metrics
- thresholds: [0.9, 0.85, 0.8]

## Coset vs backbone statistics (Mann–Whitney U)
- auc: p=6.785e-01 (n_backbone=9, n_coset=2)
- kill_0.9: p=1.000e+00 (n_backbone=9, n_coset=2)
- kill_0.85: p=1.000e+00 (n_backbone=9, n_coset=2)
- kill_0.8: p=1.000e+00 (n_backbone=9, n_coset=2)

## Plots
- violin_kill_085.png
- violin_auc.png
- scatter_cosetfrac_vs_kill085.png
