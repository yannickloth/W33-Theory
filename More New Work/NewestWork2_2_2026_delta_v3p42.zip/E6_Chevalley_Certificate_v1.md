# E6 Chevalley Certificate v1

## Killing metric on Cartan (computed)
- eigenvalues: [-1.947315084474059e-16, -7.959249802941561e-17, -7.151833754168112e-17, 1.523926496583384e-17, 1.1087381545311429e-16, 3.1976879024787157e-16]

## Root recovery
- weight_clusters_total: 76
- zero_weight_mult: 3
- nonzero_weight_clusters: 75
- root_pairs: 7
- use_imag: True

## Status
not locked in-session; needs deterministic selection using root-graph + killing metric

Notes:
- We computed Killing metric on the Cartan in the 78-basis (Tr(ad_i ad_j)).
- Root-weight clusters were recovered from Schur diagonalization of ad(Cartan) on the 78-basis.
- A fully canonical simple-root set requires deterministic search over candidate roots using this metric; heuristic random search did not lock within time.
