# E6 root-space decomposition v1 (explicit 78 basis)

- D6_used: 66
- coset_dim: 13
- E6_basis_dim: 78

- zero-weight multiplicity: 78
- root weight clusters: 0 (pairs 0)

Sample root weights:
