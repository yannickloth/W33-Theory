# PG(3,2) × A2/SU(3) candidate via Z3 actions on K6

We model **remaining15** as PG(3,2) points via the K6-edge (duad) construction.
A natural A2/SU(3) ingredient is a **Z3** action; in S6 this corresponds to a product of two 3-cycles `(abc)(def)`.

## Key finding
- Every such Z3 generator partitions the 15 points into **5 orbits of size 3**.
- Each size-3 orbit is a **PG(3,2) line** (either a triangle-line or a matching-line).
- Therefore each Z3 gives a **spread** of 5 disjoint lines covering all 15 points.

This matches Marcelis-style PG(3,2) spread discussions and is a canonical bridge from PG(3,2) to E8/E6 combinatorics.

## Best Z3 generators (maximize tri-colored lines)
We define a phase-coloring by assigning colors 0/1/2 around each 3-cycle orbit; then count how many PG lines are tri-colored (0,1,2).

### perm=[2, 3, 4, 5, 0, 1] cycles=[[0, 2, 4], [1, 3, 5]]
- tri-colored lines: 17 / 35
- orbit line types: {'matching': 3, 'triangle': 2}
  - matching line points=[5, 18, 23]
  - triangle line points=[9, 13, 15]
  - matching line points=[8, 11, 14]
  - matching line points=[7, 12, 17]
  - triangle line points=[6, 10, 16]

### perm=[2, 3, 5, 4, 1, 0] cycles=[[0, 2, 5], [1, 3, 4]]
- tri-colored lines: 17 / 35
- orbit line types: {'matching': 3, 'triangle': 2}
  - matching line points=[5, 18, 23]
  - triangle line points=[8, 12, 15]
  - matching line points=[9, 10, 14]
  - matching line points=[6, 13, 17]
  - triangle line points=[7, 11, 16]

### perm=[3, 2, 4, 5, 1, 0] cycles=[[0, 3, 5], [1, 2, 4]]
- tri-colored lines: 17 / 35
- orbit line types: {'matching': 3, 'triangle': 2}
  - matching line points=[5, 18, 23]
  - matching line points=[7, 10, 15]
  - triangle line points=[6, 12, 14]
  - matching line points=[8, 13, 16]
  - triangle line points=[9, 11, 17]

### perm=[3, 2, 5, 4, 0, 1] cycles=[[0, 3, 4], [1, 2, 5]]
- tri-colored lines: 17 / 35
- orbit line types: {'matching': 3, 'triangle': 2}
  - matching line points=[5, 18, 23]
  - matching line points=[6, 11, 15]
  - triangle line points=[7, 13, 14]
  - matching line points=[9, 12, 16]
  - triangle line points=[8, 10, 17]

### perm=[4, 5, 0, 1, 2, 3] cycles=[[0, 4, 2], [1, 5, 3]]
- tri-colored lines: 17 / 35
- orbit line types: {'matching': 3, 'triangle': 2}
  - matching line points=[5, 18, 23]
  - triangle line points=[9, 13, 15]
  - matching line points=[8, 11, 14]
  - matching line points=[7, 12, 17]
  - triangle line points=[6, 10, 16]

### perm=[4, 5, 1, 0, 3, 2] cycles=[[0, 4, 3], [1, 5, 2]]
- tri-colored lines: 17 / 35
- orbit line types: {'matching': 3, 'triangle': 2}
  - matching line points=[5, 18, 23]
  - matching line points=[6, 11, 15]
  - triangle line points=[7, 13, 14]
  - matching line points=[9, 12, 16]
  - triangle line points=[8, 10, 17]

### perm=[5, 4, 0, 1, 3, 2] cycles=[[0, 5, 2], [1, 4, 3]]
- tri-colored lines: 17 / 35
- orbit line types: {'matching': 3, 'triangle': 2}
  - matching line points=[5, 18, 23]
  - triangle line points=[8, 12, 15]
  - matching line points=[9, 10, 14]
  - matching line points=[6, 13, 17]
  - triangle line points=[7, 11, 16]

### perm=[5, 4, 1, 0, 2, 3] cycles=[[0, 5, 3], [1, 4, 2]]
- tri-colored lines: 17 / 35
- orbit line types: {'matching': 3, 'triangle': 2}
  - matching line points=[5, 18, 23]
  - matching line points=[7, 10, 15]
  - triangle line points=[6, 12, 14]
  - matching line points=[8, 13, 16]
  - triangle line points=[9, 11, 17]

