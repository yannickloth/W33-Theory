# Chevalley root-operator construction v1 (Cartan-eigenbasis route)

## What we did
- Joint-diagonalized the imported Cartan H_i on the 27-dimensional representation.
- Computed weight vectors W[p] (p=0..26) in R^6.
- For stabilizer generators and sampled commutators, extracted candidate root differences r = W[p]-W[q].

## Root-difference catalog
- unique directed roots found: 80
- unique roots mod sign: 40
- coordinate alphabet: [-2.0, -1.0, 0.0, 1.0, 2.0]

Top roots by frequency (mod sign):
- (0.0, 0.0, 1.0, 0.0, 0.0, 0.0)  count=164  ||r||^2=1.0
- (1.0, -0.0, -0.0, -0.0, -0.0, -0.0)  count=148  ||r||^2=1.0
- (-0.0, -0.0, -0.0, -0.0, 1.0, -0.0)  count=112  ||r||^2=1.0
- (-0.0, 1.0, -0.0, -0.0, -0.0, -0.0)  count=108  ||r||^2=1.0
- (0.0, 0.0, 0.0, 0.0, 0.0, 1.0)  count=104  ||r||^2=1.0
- (0.0, 0.0, 0.0, 1.0, 0.0, 0.0)  count=40  ||r||^2=1.0
- (1.0, -0.0, -0.0, -0.0, -0.0, 1.0)  count=36  ||r||^2=2.0
- (1.0, -0.0, -0.0, -0.0, -0.0, -1.0)  count=36  ||r||^2=2.0
- (0.0, 0.0, 1.0, 0.0, 0.0, 1.0)  count=28  ||r||^2=2.0
- (-0.0, -0.0, 1.0, -0.0, -0.0, -1.0)  count=28  ||r||^2=2.0
- (1.0, 0.0, 0.0, 0.0, 1.0, 0.0)  count=24  ||r||^2=2.0
- (1.0, -0.0, -0.0, -0.0, -1.0, -0.0)  count=24  ||r||^2=2.0
- (-0.0, 1.0, -0.0, 1.0, -0.0, -0.0)  count=24  ||r||^2=2.0
- (0.0, 1.0, 0.0, -1.0, 0.0, 0.0)  count=24  ||r||^2=2.0
- (-0.0, -0.0, -0.0, 1.0, -0.0, 1.0)  count=24  ||r||^2=2.0

## Simple-root search
We attempted to select 6 simple roots among ||r||^2=2 candidates using Euclidean dot adjacency (-1) to match E6 Dynkin.
- We can find E6 *graph structure* on a subset, but cannot orient signs to make a proper Cartan matrix with off-diagonals in {0,-1} under Euclidean dot.
This indicates the correct inner product on these coordinates is not plain Euclidean; it should be induced from the Killing metric on the chosen Cartan.

## Next step (v2)
- Compute the Cartan inner product metric from ad(H) (Killing proxy) and redo the simple-root search with that metric.
- Then pick E_{alpha_i} as a matrix unit between weights (p->q) realizing that root, and generate the full root system by commutators.
