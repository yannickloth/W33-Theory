# Kernel transition operator in Cartan eigenbasis (2026-02-03)

This pack constructs an explicit transition operator in the joint Cartan eigenbasis
and compares its support to the final 216-edge Schläfli selection rule.

## Operators

- T_root_current_sum_27x27.npy

    T := sum_{alpha in Phi+} E_alpha + sum_{alpha in Phi+} F_alpha

  where the 36 positive-root generators (E_positive_36.npy) and 36 negative-root generators
  (F_negative_36.npy) are transformed into the joint Cartan eigenbasis using P, Pinv.

- T2_two_step_27x27.npy

    T^2

  which exhibits effective 2-step couplings.

## Support result on Schläfli edges

- Schläfli edges: 216
- Edges supported directly by T: 45
  (these coincide with the edges marked in_root_support=True in the selection-rule CSV)

See schlafli_edges_supported_by_T_45.csv

## The 4 special 2-step edges

The edges labeled ALLOW_2step_same_root have ~0 direct amplitude in T (~1e-15),
but nontrivial amplitude in T^2.

See two_step_edges_T2_amplitudes.csv
