# Dynkin node → stabilizer generator mapping (exact cluster IDs)

- tol: 1e-08
- eps_root: 0.0001
- bsub: 220
- clusters: 19
- stabilizer generators analyzed: 82/82

## Dynkin edges
[(0, 3), (1, 2), (2, 4), (2, 5), (3, 4)]

## Node 0 (a6)
- cluster id: 15
- count=2 gen=('edge', 4, 21)

## Node 1 (a2)
- cluster id: 4
- count=4 gen=('edge', 0, 16)
- count=4 gen=('edge', 14, 16)
- count=4 gen=('edge', 16, 18)
- count=4 gen=('edge', 16, 17)
- count=4 gen=('edge', 15, 16)

## Node 2 (a3)
- cluster id: 18
- count=2 gen=('edge', 5, 9)

## Node 3 (a5)
- cluster id: 22
- status: cluster_id_out_of_range

## Node 4 (a4)
- cluster id: 9
- count=2 gen=('edge', 1, 5)

## Node 5 (a1)
- cluster id: 3
- count=2 gen=('edge', 0, 4)
- count=2 gen=('edge', 4, 19)
- count=2 gen=('edge', 2, 4)
- count=2 gen=('edge', 4, 17)

