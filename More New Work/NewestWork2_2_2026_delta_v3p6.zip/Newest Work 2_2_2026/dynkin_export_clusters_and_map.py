
#!/usr/bin/env python3
"""Export exact Dynkin-lock root clusters and build a perfect-index Dynkin→generator map.

This script reproduces the SAME clustering as dynkin_lock_killing_parametric_v2.py (same eps_root, metric distance),
then maps each simple-root cluster id (from dynkin_lock_best.json) to top stabilizer generators.

Outputs (into artifacts_unified_v3):
  - dynkin_clusters_exact.json
  - dynkin_node_generator_map_exact.json
  - dynkin_node_generator_map_exact.md
  - dynkin_node_generator_map_exact.pdf
"""
from __future__ import annotations
import json, math, itertools
from pathlib import Path
from collections import defaultdict, Counter
import numpy as np
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter

BASE = Path("/mnt/data")
ROOT = BASE/"newest_work_2_2_2026"/"Newest Work 2_2_2026"
OUT = ROOT/"artifacts_unified_v3"
OUT.mkdir(parents=True, exist_ok=True)
CHAT = BASE/"chat_artifacts"

def load_json(p: Path):
    return json.loads(p.read_text(encoding="utf-8", errors="replace"))

def main():
    dyn_best = load_json(BASE/"newest_work_2_2_2026"/"artifacts"/"dynkin_lock_best.json")
    best_run = dyn_best["best_run"]
    eps_root = float(best_run["eps_root"])
    tol = float(dyn_best["tol"])
    bsub = int(dyn_best.get("bsub", 220))
    simple_idxs = [int(i) for i in best_run["best"]["idxs"]]

    # canonical labels from unified report
    report = load_json(OUT/"UNIFIED_REPORT_V3.json")
    Cr = np.array(report["checks"]["dynkin_candidate"]["best"]["C_round"], dtype=int)
    edges=[]
    deg=[0]*6
    for i in range(6):
        for j in range(i+1,6):
            if Cr[i,j]==-1 and Cr[j,i]==-1:
                edges.append((i,j)); deg[i]+=1; deg[j]+=1
    canonical = {2:"a3",4:"a4",3:"a5",0:"a6",1:"a2",5:"a1"}  # fixed for this graph

    # Load phase tables from /mnt/data
    hol = load_json(BASE/"toe_discrete_gauge_field_holonomy.json")
    clk = load_json(BASE/"toe_local_1form_clock.json")["local_table"]
    ctx = load_json(BASE/"toe_contextual_firewall_spin_clock_solver.json")
    p_transition = ctx["p_transition"]

    # Load schlafli adjacency, selected edges, H27 mapping
    S = np.load(CHAT/"toe_E6_schlafli_restrictions/S_schlafli_27.npy").astype(int)
    edge_list=[]
    for i in range(27):
        for j in range(i+1,27):
            if S[i,j]==1:
                edge_list.append((i,j))
    sel = load_json(CHAT/"toe_step3_subalgebra_extraction_fast.json")["selected_edge_indices"]
    H27 = [int(x) for x in load_json(CHAT/"toe_E6_schlafli_from_rank6_restriction_summary.json")["H27_global_indices"]]

    # block / label maps
    state_to_block={}
    vertex_label={}
    for b,info in hol["blocks"].items():
        b=int(b)
        for s in info["states"]:
            state_to_block[int(s)] = b
        for vtx,lab in info["labels"].items():
            vertex_label[int(vtx)] = tuple(lab)

    def parse_xy(s): return (int(s[0]), int(s[1]))
    k6={}
    for key,val in clk.items():
        A,B=key.split("->"); A=int(A); B=int(B)
        for xk,info in val["edges"].items():
            x=parse_xy(xk)
            k6[(A,B,x)] = int(info["k6"])%6

    def pbit(A,B,x): return 1 if int(p_transition.get(str((A,B,x)),0))==2 else 0
    zeta = np.exp(2j*np.pi/6).astype(np.complex64)

    def weight_for_dir(i,j):
        u=H27[i]; v=H27[j]
        bu=state_to_block[u]; bv=state_to_block[v]
        xu=vertex_label[u]
        if bu==bv:
            return np.complex64(1.0+0j)
        kk=k6[(bu,bv,xu)]
        pp=pbit(bu,bv,xu)
        return (zeta**np.int32(kk))*np.complex64((-1)**pp)

    # Build generators
    gens=[]
    gen_meta=[]
    for idx in sel:
        i,j=edge_list[int(idx)]
        w=weight_for_dir(i,j); th=float(np.angle(w))
        a=np.complex64(math.cos(th)+1j*math.sin(th))
        X=np.zeros((27,27),dtype=np.complex64)
        X[i,j]=a; X[j,i]=-np.conjugate(a)
        gens.append(X); gen_meta.append(("edge",int(i),int(j)))
    for k in range(8):
        D=np.zeros((27,27),dtype=np.complex64)
        D[k,k]=1; D[k+1,k+1]=-1
        gens.append(1j*D); gen_meta.append(("cartan_seed",int(k)))

    # Build cubic stabilizer
    alpha=np.array(load_json(CHAT/"toe_step3_breakthrough_full_sym3_audit.json")["solve"]["alpha"], dtype=np.float64)
    coords_data = load_json(CHAT/"toe_trinification_coords_27.json")
    coords = {int(k):(v["a"],v["b"],v["c"]) for k,v in coords_data["coords"].items()}
    inv_coords = {tuple(v): int(k) for k,v in coords.items()}
    perm_sign={}
    for perm in itertools.permutations([0,1,2]):
        inv=0
        for i in range(3):
            for j in range(i+1,3):
                if perm[i]>perm[j]: inv+=1
        perm_sign[perm] = -1 if inv%2 else 1

    templates=[]
    def add_temp(tris):
        d=defaultdict(int)
        for tri,coef in tris:
            d[tuple(sorted(tri))]+=int(coef)
        templates.append(dict(d))

    diag=[]
    for a in range(3):
        for b in range(3):
            for c in range(3):
                v0=inv_coords[(a,b,c)]
                v1=inv_coords[((a+1)%3,(b+1)%3,(c+1)%3)]
                v2=inv_coords[((a+2)%3,(b+2)%3,(c+2)%3)]
                diag.append(((v0,v1,v2),1))
    add_temp(diag)
    for c in range(3):
        det=[]
        for perm,sgn in perm_sign.items():
            verts=[inv_coords[(a,perm[a],c)] for a in range(3)]
            det.append((tuple(verts),sgn))
        add_temp(det)
    shiftA=[]; shiftB=[]
    for a in range(3):
        for b in range(3):
            for c in range(3):
                v0=inv_coords[(a,b,c)]
                v1=inv_coords[((a+1)%3,(b+2)%3,(c+1)%3)]
                v2=inv_coords[((a+2)%3,(b+1)%3,(c+2)%3)]
                shiftA.append(((v0,v1,v2),1))
                v1b=inv_coords[((a+1)%3,(b+1)%3,(c+2)%3)]
                v2b=inv_coords[((a+2)%3,(b+2)%3,(c+1)%3)]
                shiftB.append(((v0,v1b,v2b),1))
    add_temp(shiftA); add_temp(shiftB)
    t1=[]; t2=[]; t3=[]
    for a in range(3):
        for b in range(3):
            for c in range(3):
                t1.append(((inv_coords[(a,b,0)], inv_coords[(b,c,1)], inv_coords[(c,a,2)]),1))
                t2.append(((inv_coords[(a,b,0)], inv_coords[(b,c,2)], inv_coords[(c,a,1)]),1))
                t3.append(((inv_coords[(a,b,1)], inv_coords[(b,c,2)], inv_coords[(c,a,0)]),1))
    add_temp(t1); add_temp(t2); add_temp(t3)

    S0=set()
    for t in templates: S0.update(t.keys())
    nz_list=[[(int(a),int(b), gens[gi][int(a),int(b)]) for a,b in np.argwhere(np.abs(gens[gi])>1e-8)] for gi in range(len(gens))]
    cap=3654
    U=set(S0)
    for _ in range(5):
        added=0
        cur=list(U)
        for tri in cur:
            i,j,k=tri
            for nz in nz_list:
                for a,b,_ in nz:
                    if b==i:
                        u=tuple(sorted((a,j,k)))
                        if u not in U: U.add(u); added+=1
                    if b==j:
                        u=tuple(sorted((i,a,k)))
                        if u not in U: U.add(u); added+=1
                    if b==k:
                        u=tuple(sorted((i,j,a)))
                        if u not in U: U.add(u); added+=1
            if len(U)>=cap: break
        if added==0: break
    U=sorted(U); p=len(U)
    tri_index={tri:i for i,tri in enumerate(U)}
    template_vecs=np.zeros((p,len(templates)),dtype=np.float64)
    for k,t in enumerate(templates):
        for tri,coef in t.items():
            template_vecs[tri_index[tri],k]=coef
    c_comb=(template_vecs @ alpha).astype(np.complex64)
    nz_c=np.where(np.abs(c_comb)>1e-12)[0].tolist()

    def apply_AX(nzX):
        out=np.zeros(p,dtype=np.complex64)
        for t_idx in nz_c:
            c=c_comb[t_idx]
            if c==0: continue
            i,j,k=U[t_idx]
            for a,b,val in nzX:
                if b==i:
                    idx=tri_index.get(tuple(sorted((a,j,k))))
                    if idx is not None: out[idx]+=val*c
                if b==j:
                    idx=tri_index.get(tuple(sorted((i,a,k))))
                    if idx is not None: out[idx]+=val*c
                if b==k:
                    idx=tri_index.get(tuple(sorted((i,j,a))))
                    if idx is not None: out[idx]+=val*c
        return out

    residuals=np.array([float(np.vdot(apply_AX(nz_list[gi]), apply_AX(nz_list[gi])).real) for gi in range(len(gens))], dtype=float)
    stab_idx=[i for i in range(len(gens)) if residuals[i]<=tol]
    stab=[gens[i] for i in stab_idx]

    # Cartan (greedy degree-based) and Killing metric
    stabH=[(-1j)*M.astype(np.complex128) for M in stab]
    def comm_norm(A,B): return float(np.linalg.norm(A@B - B@A))
    eps_comm=1e-6
    deg_list=[]
    for i,A0 in enumerate(stabH):
        cnt=0
        for j,B0 in enumerate(stabH):
            if i!=j and comm_norm(A0,B0)<=eps_comm:
                cnt+=1
        deg_list.append((cnt,i))
    deg_list.sort(reverse=True)
    cart=[]
    for cnt,i in deg_list:
        A0=stabH[i]
        if all(comm_norm(A0,B0)<=eps_comm for B0 in cart):
            cart.append(A0)
        if len(cart)>=6: break

    def frob_inner(A,B): return float(np.vdot(A,B).real)
    cart_ortho=[]
    for H in cart:
        W_=H.copy()
        for Q_ in cart_ortho:
            W_ = W_ - (frob_inner(Q_,W_)/max(1e-12,frob_inner(Q_,Q_)))*Q_
        if np.linalg.norm(W_)>1e-8:
            cart_ortho.append(W_)
    cart_ortho=cart_ortho[:6]
    r=len(cart_ortho)

    def vecR(M): return np.concatenate([M.real.ravel(), M.imag.ravel()]).astype(np.float64)
    basis_mats=stab[:min(bsub, len(stab))]
    Bmat=np.stack([vecR(M) for M in basis_mats], axis=1)
    Q,_=np.linalg.qr(Bmat)
    def project(M): return Q.T @ vecR(M)
    def comm(A,B): return A@B - B@A
    ad=np.zeros((r,len(basis_mats),Q.shape[1]),dtype=np.float64)
    for i,H in enumerate(cart_ortho):
        for k,X in enumerate(basis_mats):
            ad[i,k,:]=project(comm(H, X.astype(np.complex128)))
    Bmetric=np.zeros((r,r),dtype=np.float64)
    for i in range(r):
        for j in range(r):
            Bmetric[i,j]=float(np.sum(ad[i,:,:]*ad[j,:,:]))
    Bmetric=(Bmetric+Bmetric.T)/2
    eig=np.linalg.eigvalsh(Bmetric)
    if eig.min()<=1e-12:
        Bmetric += np.eye(r)*(1e-6 - eig.min())

    # Weights eigenbasis
    rng=np.random.default_rng(0)
    coeffs=rng.normal(size=r)
    H0=np.zeros((27,27),dtype=np.complex128)
    for c,H in zip(coeffs,cart_ortho):
        H0 += c*H
    ew,Ueig=np.linalg.eigh(H0)
    W=np.zeros((27,r),dtype=np.float64)
    for k,H in enumerate(cart_ortho):
        D=np.diag(Ueig.conj().T @ H @ Ueig)
        W[:,k]=D.real

    # Exact clustering + counts
    clusters=[]; counts=[]
    def norm_sign(v):
        vv=v.copy()
        for t in vv:
            if abs(t)>eps_root:
                if t<0: vv=-vv
                break
        return vv

    def add_cluster(v):
        vv=norm_sign(v)
        for i,rep in enumerate(clusters):
            d=vv-rep
            dist=math.sqrt(float(d @ Bmetric @ d))
            if dist<eps_root:
                counts[i]+=1
                return i
        clusters.append(vv); counts.append(1)
        return len(clusters)-1

    # per-generator counts
    Nstab=min(250,len(stab))
    gen_cluster_counts=[Counter() for _ in range(Nstab)]
    for gi in range(Nstab):
        X0=stab[gi]
        Y=Ueig.conj().T @ X0.astype(np.complex128) @ Ueig
        flat=np.abs(Y.ravel())
        idxs=np.argsort(-flat)[:200]
        for idx in idxs:
            p0=idx//27; q0=idx%27
            if p0==q0 or flat[idx]<1e-7: continue
            v=W[p0]-W[q0]
            if np.linalg.norm(v)<eps_root: continue
            cid=add_cluster(v)
            gen_cluster_counts[gi][cid]+=1

    # Export clusters
    clusters_arr=np.array(clusters).tolist()
    clusters_json={
        "tol": tol, "eps_root": eps_root, "bsub": bsub,
        "clusters": clusters_arr,
        "counts": [int(x) for x in counts],
        "simple_root_cluster_ids": simple_idxs,
        "cartan_matrix": best_run["best"]["C_round"],
    }
    (OUT/"dynkin_clusters_exact.json").write_text(json.dumps(clusters_json, indent=2), encoding="utf-8")

    # Map each simple root cluster id
    mapping=[]
    for node,cid in enumerate(simple_idxs):
        item={"dynkin_node": node, "canonical_label": canonical.get(node,f"node{node}"), "cluster_id": int(cid)}
        if cid >= len(clusters):
            item["status"]="cluster_id_out_of_range"
            mapping.append(item); continue
        scored=[]
        for gi in range(Nstab):
            c=gen_cluster_counts[gi].get(cid,0)
            if c>0:
                scored.append((c,gi))
        scored.sort(reverse=True)
        top=[]
        for c,gi in scored[:12]:
            top.append({"count": int(c), "stabilizer_index": int(gi), "gen_meta": gen_meta[stab_idx[gi]]})
        item["top_generators"]=top
        mapping.append(item)

    map_json={
        "tol": tol, "eps_root": eps_root, "bsub": bsub,
        "dynkin_edges": edges,
        "canonical_labels": canonical,
        "mapping": mapping,
        "note":"Perfect-index mapping: cluster IDs are from dynkin_lock_best.json and the clusters are reproduced exactly here."
    }
    (OUT/"dynkin_node_generator_map_exact.json").write_text(json.dumps(map_json, indent=2), encoding="utf-8")

    # markdown + pdf
    md=[]
    md.append("# Dynkin node → stabilizer generator mapping (exact cluster IDs)\n\n")
    md.append(f"- tol: {tol}\n- eps_root: {eps_root}\n- bsub: {bsub}\n")
    md.append(f"- clusters: {len(clusters)}\n- stabilizer generators analyzed: {Nstab}/{len(stab)}\n\n")
    md.append("## Dynkin edges\n"+str(edges)+"\n\n")
    for item in mapping:
        md.append(f"## Node {item['dynkin_node']} ({item['canonical_label']})\n")
        md.append(f"- cluster id: {item['cluster_id']}\n")
        if "status" in item:
            md.append(f"- status: {item['status']}\n\n"); continue
        for g in item["top_generators"][:8]:
            md.append(f"- count={g['count']} gen={g['gen_meta']}\n")
        md.append("\n")
    md_text="".join(md)
    md_path=OUT/"dynkin_node_generator_map_exact.md"
    md_path.write_text(md_text, encoding="utf-8")

    pdf_path=OUT/"dynkin_node_generator_map_exact.pdf"
    c=canvas.Canvas(str(pdf_path), pagesize=letter)
    wpage,hpage=letter
    t=c.beginText(50,hpage-50); t.setFont("Times-Roman", 9)
    for line in md_text.splitlines():
        if t.getY()<40:
            c.drawText(t); c.showPage()
            t=c.beginText(50,hpage-50); t.setFont("Times-Roman", 9)
        t.textLine(line)
    c.drawText(t); c.save()

if __name__ == "__main__":
    main()