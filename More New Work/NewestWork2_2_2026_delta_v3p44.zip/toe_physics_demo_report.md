# TOE Physics Engine Demo v1

This demo constructs a **permissioned evolution operator** on the 27-state Schläfli sector using the kernel's phase clock and (if available) firewall blocks.

## Graph counts
- schlafli_edges: 216
- allowed_edges: 216
- blocked_edges_detected: 0
- triangles_in_allowed_graph: 720

## Charge conservation proxy
We test `||[Cartan_k, U]||` for k=1..6 (smaller suggests an approximately conserved charge under the step operator):
- Cartan 1: 9.6341e-01
- Cartan 2: 9.7041e-01
- Cartan 3: 9.7069e-01
- Cartan 4: 9.7764e-01
- Cartan 5: 9.6529e-01
- Cartan 6: 7.0156e-01

We also evolve a random state for 50 steps and record drift in ⟨Cartan_k⟩:
- mean |Δ⟨H_k⟩| per step: [0.007721488716753754, 0.026865459527828806, 0.014873016177239929, 0.02072621532025547, 0.01889956924037881, 0.005747194117474453]
- max  |Δ⟨H_k⟩| per step: [0.017454977664453416, 0.036573753950106674, 0.09856895852526205, 0.02693178096581192, 0.0278661388345577, 0.017183357975905422]

## Curvature proxy: triangle holonomy
We compute the product of directed phase weights around each triangle in the allowed graph and bucket by nearest Z12 and Z24 phase class.
- Z12 histogram: {10: 127, 4: 117, 8: 125, 0: 126, 6: 108, 2: 117}
- Z24 histogram: {20: 127, 8: 117, 16: 125, 0: 126, 12: 108, 4: 117}
