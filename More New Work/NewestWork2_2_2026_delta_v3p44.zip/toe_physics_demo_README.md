# TOE Physics Engine Demo v1

This demo builds a **permissioned evolution operator** on the 27-state Schläfli sector using:
- Schläfli adjacency (216 edges)
- phase weights from `toe_local_1form_clock.json` + `toe_discrete_gauge_field_holonomy.json`
- firewall blocks from `toe_contextual_firewall_spin_clock_solver.json` (if a bad-edge list is present)

It then reports:
1) Graph counts (allowed vs blocked)
2) Charge conservation proxy: commutator norms `||[Cartan, U]||` and drift in ⟨Cartan⟩ over time
3) Curvature proxy: triangle holonomy histograms mod 12 and mod 24

Files:
- `toe_physics_demo_summary.json`
- `toe_physics_demo_report.md`
- `toe_physics_demo_report.pdf`
