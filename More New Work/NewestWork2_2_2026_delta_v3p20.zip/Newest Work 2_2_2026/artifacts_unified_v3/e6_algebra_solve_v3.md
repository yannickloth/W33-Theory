# E6 algebra solve v3 (invariant weight clustering)

- basis_dim: 78
- closure_added_commutators: 0
- cartan_rank: 6
- zero_key: (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
- root_keys_mod_sign: 0
- root_mult_hist: {}

## Root multiplicity histogram

## Top roots by multiplicity

## Notes
- v3: invariant root weights computed by <X,[H,X]>/<X,X> on actual matrices, avoiding coordinate-dependent ad diagonals.
- Next: pick one vector from each root cluster as E_alpha, identify ± pairs, match simple roots to locked Dynkin, and normalize to Chevalley basis.
