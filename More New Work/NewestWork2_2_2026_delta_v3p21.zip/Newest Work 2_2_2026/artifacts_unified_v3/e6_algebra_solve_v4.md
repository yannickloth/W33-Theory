# E6 algebra solve v4 (Schur-based weight extraction)

- basis_dim: 78
- closure_added_commutators: 0
- cartan_rank: 6
- schur_imag_diag_max: 0.0
- root_keys_mod_sign: 0
- root_mult_hist: {}
- zero_key: (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)

## Root multiplicity histogram

## Top roots by multiplicity

## Notes
- v4: weights extracted in a Schur basis of a random Cartan combination; since ad(H_i) commute, they are simultaneously upper-triangularizable and share the Schur basis (approximately).
- Next: identify ± pairs among root keys, select simple roots matching locked Dynkin, and normalize Chevalley basis via commutators.
