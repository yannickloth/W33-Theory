# E6 algebra solve v2 probe (complex-weight extraction)

- basis_dim: 82
- closure_added_commutators: 0
- cartan_rank_found: 6
- ad_comm_max_norm: 0.0
- eig_weight_vectors: 82
- eig_weight_imag_bad_count: 0
- zero_weight_candidate_norms: [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
- root_keys_mod_sign: 0
- root_key_mult_hist: {}

## Root key multiplicity histogram

## Notes
- If root_keys_mod_sign is near 36 and multiplicities are mostly 1, we are essentially seeing the E6 root system in the adjoint.
- Next: refine by using a better joint diagonalization (since ad(H) commute), and build explicit E_alpha from eigenvectors; then enforce Chevalley normalization.
