# Chevalley simple-generator search (commutator graph heuristic)

- candidates: 74 edge generators (from selected_edge_indices)
- commutator threshold: 1e-06

## Best found (not yet E6)
- score: 4
- degree multiset: [1, 1, 2, 2, 2, 2] (target [1, 1, 1, 2, 2, 3])
- edges among chosen: 5

### Nodes
- idx 37: edge (8, 14)
- idx 16: edge (6, 22)
- idx 49: edge (16, 18)
- idx 3: edge (15, 16)
- idx 27: edge (8, 15)
- idx 29: edge (18, 22)

### Edges (commutator-nonzero)
- 37--27
- 16--29
- 49--3
- 49--29
- 3--27

## Next
- Run the same search on the **full phase-weighted stabilizer generator set** (not unit-phase subset), including Cartan seeds and any additional stabilizer directions.
- Use the Dynkin-locked Cartan export to define weights and constrain candidate selection.
