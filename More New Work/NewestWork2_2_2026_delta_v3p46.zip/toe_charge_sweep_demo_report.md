# TOE Charge Sweep Demo v3

This demo sweeps random linear combinations of the 6 exported Cartan generators to find a **most conserved charge** for the kernel evolution operator.

## Graph
- schlafli_edges: 216
- all_edges_used: 216
- firewall_edges_used: 216
- blocked_edges_detected: 0

## Sweep summary (all edges)
- comm norm min/med/max: {'min': 0.4994089751525317, 'median': 0.6768024108117021, 'max': 0.7369600901327169}
- drift   min/med/max:   {'min': 0.002990028530426328, 'median': 0.010514287869130653, 'max': 0.02879913447136527}
- best coeffs: [0.11086468675565742, 0.07549253294671551, 0.20291973937697325, 0.018869446408110696, -0.2236672706960641, 0.9436367808021607]
- best mean drift: 2.9900e-03, comm norm: 5.1368e-01

## Sweep summary (firewall)
- comm norm min/med/max: {'min': 0.5113551951105934, 'median': 0.6770421093004942, 'max': 0.7397629670108113}
- drift   min/med/max:   {'min': 0.0017871210167379715, 'median': 0.010306330245878613, 'max': 0.03095392016773729}
- best coeffs: [-0.01891782942971576, -0.28971512521300186, -0.315313011469342, -0.05722760233705945, 0.27893677790973953, 0.8574405181764515]
- best mean drift: 2.9550e-03, comm norm: 5.4919e-01

## Sector sizes for best charges
- all edges (plus/minus/zero): {'plus': 5, 'minus': 5, 'zero': 17}
- firewall (plus/minus/zero): {'plus': 5, 'minus': 5, 'zero': 17}

## Files
- sweep_all_scatter.png / sweep_firewall_scatter.png
- leak_all.png / leak_firewall.png
- toe_charge_sweep_demo_summary.json
