# TOE Coupling Strengths v3

For each pair (α_i, α_j) among the 6 simple roots, we compute [E_i,E_j] and identify the dominant output channel (best root match by overlap).

Columns:
- pair: (i,j)
- overlap: similarity([E_i,E_j], E_out)
- output_root: root key
- dominant_ij: strongest matrix entry support
- schlafli_edge / firewall_blocked / phase bins

## Top couplings (by overlap)
- pair (4, 5) → root (0.003863, -0.012732, 0.001036, -0.013994, 0.000696, -0.002787) overlap=0.829 schlafli=True blocked=False Z12/Z24=2/4 support=[5, 9]
- pair (5, 6) → root (0.00632, 0.086946, 0.026229, -0.001629, 0.023401, 0.018205) overlap=0.816 schlafli=True blocked=False Z12/Z24=10/20 support=[6, 9]
- pair (1, 4) → root (-0.0, 7.8e-05, -1.6e-05, -0.000234, 5.2e-05, 1.6e-05) overlap=0.656 schlafli=True blocked=False Z12/Z24=2/4 support=[6, 13]
- pair (1, 2) → root (0.00607, -0.151274, 0.00435, 0.013613, 0.000659, -0.067983) overlap=0.574 schlafli=True blocked=False Z12/Z24=2/4 support=[13, 12]
- pair (3, 5) → root (0.00632, 0.086946, 0.026229, -0.001629, 0.023401, 0.018205) overlap=0.529 schlafli=True blocked=False Z12/Z24=10/20 support=[6, 9]
- pair (2, 3) → root (-0.0, 0.011695, 0.002629, 0.036343, 0.00896, 0.002346) overlap=0.513 schlafli=False blocked=False Z12/Z24=8/16 support=[12, 6]
- pair (3, 6) → root (0.013124, -0.010666, -0.000551, -0.022322, -0.003188, -0.005731) overlap=0.494 schlafli=False blocked=False Z12/Z24=2/4 support=[7, 1]
- pair (2, 5) → root (0.00607, -0.151274, 0.00435, 0.013613, 0.000659, -0.067983) overlap=0.419 schlafli=True blocked=False Z12/Z24=2/4 support=[13, 12]
- pair (3, 4) → root (0.013533, -0.006935, -0.040627, -0.066682, -0.007957, 0.07232) overlap=0.399 schlafli=False blocked=False Z12/Z24=10/20 support=[24, 5]
- pair (2, 6) → root (-0.0, 0.011695, 0.002629, 0.036343, 0.00896, 0.002346) overlap=0.391 schlafli=False blocked=False Z12/Z24=8/16 support=[12, 6]
- pair (1, 3) → root (-0.008233, 0.119858, -0.006065, -0.074206, -0.001354, 0.077148) overlap=0.374 schlafli=True blocked=False Z12/Z24=2/4 support=[13, 12]
- pair (2, 4) → root (0.079091, 0.015819, 0.017931, 0.004267, -0.033232, -0.103962) overlap=0.362 schlafli=True blocked=False Z12/Z24=10/20 support=[13, 26]
- pair (4, 6) → root (0.017194, -0.063099, 0.020922, -0.073757, 0.059529, 0.043499) overlap=0.329 schlafli=True blocked=False Z12/Z24=10/20 support=[12, 11]
- pair (1, 6) → root (0.028891, 0.008735, 0.009937, 0.011916, 0.016828, -0.002983) overlap=0.317 schlafli=False blocked=False Z12/Z24=0/0 support=[6, 12]
- pair (1, 5) → root (-0.038522, -0.002421, -0.001259, 0.041467, 0.019607, 0.031693) overlap=0.282 schlafli=True blocked=False Z12/Z24=2/4 support=[26, 0]
