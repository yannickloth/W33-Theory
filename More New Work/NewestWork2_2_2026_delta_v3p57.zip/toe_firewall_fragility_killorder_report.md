# TOE Firewall Fragility v3: kill order + robustness

- kill threshold (survival): 0.85

## Counts
- backbone: 10
- coset: 3
- mixed: 2

## Kill strengths (from avg curves)
- backbone: 1.0
- mixed: 1.0
- coset: 1.0

## Robustness (AUC)
- backbone: 1.0
- mixed: 1.0
- coset: 1.0

## Files
- firewall_fragility_kill_threshold.png
- kill_threshold_bars.png
- auc_bars.png
