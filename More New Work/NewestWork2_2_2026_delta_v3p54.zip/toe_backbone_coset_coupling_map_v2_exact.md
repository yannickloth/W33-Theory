# TOE Backbone vs Coset Map v2 (exact)

- total_couplings: 15
- backbone_major: 10
- coset_major: 3
- mixed: 2
- unmatched_roots: 0

- use_imag_weights (for root clustering): False

## Top 20 couplings (by overlap) with backbone/coset fractions
- pair [4, 5] overlap=0.829 output_root=[0.003863, -0.012732, 0.001036, -0.013994, 0.000696, -0.002787] backbone=0.97 coset=0.03
- pair [5, 6] overlap=0.816 output_root=[0.00632, 0.086946, 0.026229, -0.001629, 0.023401, 0.018205] backbone=0.96 coset=0.04
- pair [1, 4] overlap=0.656 output_root=[-0.0, 7.8e-05, -1.6e-05, -0.000234, 5.2e-05, 1.6e-05] backbone=0.85 coset=0.15
- pair [1, 2] overlap=0.574 output_root=[0.00607, -0.151274, 0.00435, 0.013613, 0.000659, -0.067983] backbone=0.51 coset=0.49
- pair [3, 5] overlap=0.529 output_root=[0.00632, 0.086946, 0.026229, -0.001629, 0.023401, 0.018205] backbone=0.96 coset=0.04
- pair [2, 3] overlap=0.513 output_root=[-0.0, 0.011695, 0.002629, 0.036343, 0.00896, 0.002346] backbone=0.30 coset=0.70
- pair [3, 6] overlap=0.494 output_root=[0.013124, -0.010666, -0.000551, -0.022322, -0.003188, -0.005731] backbone=0.95 coset=0.05
- pair [2, 5] overlap=0.419 output_root=[0.00607, -0.151274, 0.00435, 0.013613, 0.000659, -0.067983] backbone=0.51 coset=0.49
- pair [3, 4] overlap=0.399 output_root=[0.013533, -0.006935, -0.040627, -0.066682, -0.007957, 0.07232] backbone=0.96 coset=0.04
- pair [2, 6] overlap=0.391 output_root=[-0.0, 0.011695, 0.002629, 0.036343, 0.00896, 0.002346] backbone=0.30 coset=0.70
- pair [1, 3] overlap=0.374 output_root=[-0.008233, 0.119858, -0.006065, -0.074206, -0.001354, 0.077148] backbone=0.69 coset=0.31
- pair [2, 4] overlap=0.362 output_root=[0.079091, 0.015819, 0.017931, 0.004267, -0.033232, -0.103962] backbone=0.80 coset=0.20
- pair [4, 6] overlap=0.329 output_root=[0.017194, -0.063099, 0.020922, -0.073757, 0.059529, 0.043499] backbone=0.85 coset=0.15
- pair [1, 6] overlap=0.317 output_root=[0.028891, 0.008735, 0.009937, 0.011916, 0.016828, -0.002983] backbone=0.31 coset=0.69
- pair [1, 5] overlap=0.282 output_root=[-0.038522, -0.002421, -0.001259, 0.041467, 0.019607, 0.031693] backbone=0.96 coset=0.04
