# e6_close_and_commutator_table.py

This script takes the exported **D6 basis (66)** and **coset basis (12)** and:

1. Closes under commutators to obtain a candidate E6 algebra inside u(27)
2. Removes the 1D center (if present)
3. Exports a **78-element basis** and a **sparse commutator table**.

## Inputs
Place these files in the same directory as the script (or pass `--in-dir`):

- `D6_basis_66.npy`
- `coset_basis_12.npy`
- (optional provenance) `extension_element.npy`

## Run
```bash
python e6_close_and_commutator_table.py --in-dir . --out-dir outputs_e6
```

## Outputs
- `outputs_e6/E6_basis_78.npy` (78×27×27 complex128)
- `outputs_e6/center_element.npy` (27×27 complex128)
- `outputs_e6/commutator_table_sparse.json`
- `outputs_e6/meta.json`

The commutator table stores for each `i<j` the top `K` coefficients of `[B_i,B_j]` expanded in the 78-basis.
Adjust `--topk` and `--coef-tol` for denser/sparser tables.

## Notes
- Closure uses real-span Gram–Schmidt on flattened (Re,Im) vectors.
- If you want a *true Chevalley basis*, use the exported basis and Cartan to extract root spaces and normalize.
