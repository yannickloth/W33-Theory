#!/usr/bin/env python3
"""
Close D6 + coset to E6 (78) and export a sparse commutator table.

Inputs (expected in the same directory as this script, or pass --in-dir):
  - D6_basis_66.npy           shape (66,27,27) complex128
  - coset_basis_12.npy        shape (12,27,27) complex128
  - extension_element.npy     shape (27,27) complex128  (optional; provenance)
Outputs (written to --out-dir, default ./outputs_e6):
  - E6_basis_78.npy           shape (78,27,27) complex128  (center removed)
  - center_element.npy        shape (27,27) complex128
  - commutator_table_sparse.json  sparse coefficients of [B_i,B_j] in basis coords

Notes:
  - This works purely at the matrix level (u(27)), using real-span Gram-Schmidt.
  - The commutator table is stored sparsely: for each (i<j), we keep the top K coefficients.
"""
from __future__ import annotations
import argparse, json, math
from pathlib import Path
import numpy as np

def vecC(M: np.ndarray) -> np.ndarray:
    return np.concatenate([M.real.ravel(), M.imag.ravel()]).astype(np.float64)

def gram_add(Q: list[np.ndarray], basis: list[np.ndarray], M: np.ndarray, tol: float) -> bool:
    v = vecC(M)
    w = v.copy()
    nv = np.linalg.norm(v)
    if nv < 1e-14:
        return False
    for q in Q:
        w -= np.dot(q, w) * q
    nw = np.linalg.norm(w)
    if nw < tol * nv:
        return False
    Q.append(w / nw)
    basis.append(M)
    return True

def closure_deterministic(seed: list[np.ndarray], tol: float, max_dim: int, max_passes: int) -> list[np.ndarray]:
    Q: list[np.ndarray] = []
    basis: list[np.ndarray] = []
    for M in seed:
        gram_add(Q, basis, M, tol)
    for _ in range(max_passes):
        added = 0
        L = len(basis)
        for i in range(L):
            for j in range(i+1, L):
                C = basis[i] @ basis[j] - basis[j] @ basis[i]
                if np.linalg.norm(C) < 1e-12:
                    continue
                if gram_add(Q, basis, C, tol):
                    added += 1
                    if len(basis) >= max_dim:
                        return basis
        if added == 0:
            break
    return basis

def orth_basis(mats: list[np.ndarray], tol: float, max_keep: int | None = None) -> tuple[np.ndarray, list[np.ndarray]]:
    Q: list[np.ndarray] = []
    basis: list[np.ndarray] = []
    for M in mats:
        v = vecC(M)
        w = v.copy()
        nv = np.linalg.norm(v)
        if nv < 1e-14:
            continue
        for q in Q:
            w -= np.dot(q, w) * q
        nw = np.linalg.norm(w)
        if nw < tol * nv:
            continue
        Q.append(w / nw)
        basis.append(M)
        if max_keep is not None and len(basis) >= max_keep:
            break
    Qmat = np.array(Q).T if Q else np.zeros((0,0), dtype=np.float64)
    return Qmat, basis

def residual(Q: np.ndarray, M: np.ndarray) -> float:
    v = vecC(M)
    proj = Q @ (Q.T @ v)
    return float(np.linalg.norm(v - proj) / max(1e-12, np.linalg.norm(v)))

def traceless(M: np.ndarray) -> np.ndarray:
    tr = np.trace(M) / M.shape[0]
    return M - tr * np.eye(M.shape[0], dtype=np.complex128)

def find_center(basis: list[np.ndarray]) -> int:
    N = len(basis)
    scores = []
    for i,M in enumerate(basis):
        s = 0.0
        for j in range(N):
            C = M @ basis[j] - basis[j] @ M
            s += float(np.linalg.norm(C))
        scores.append((s,i))
    scores.sort()
    return scores[0][1]

def coeffs_in_basis(Q: np.ndarray, M: np.ndarray) -> np.ndarray:
    return Q.T @ vecC(M)

def sparse_top(c: np.ndarray, top: int, tol: float) -> list[list[float]]:
    idx = np.argsort(-np.abs(c))[:top]
    out=[]
    for i in idx:
        if abs(c[i]) > tol:
            out.append([int(i), float(c[i])])
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in-dir", type=str, default=".", help="Directory containing the .npy inputs")
    ap.add_argument("--out-dir", type=str, default="outputs_e6", help="Output directory")
    ap.add_argument("--tol", type=float, default=1e-10, help="Gram-Schmidt tolerance")
    ap.add_argument("--max-passes", type=int, default=18, help="Closure passes")
    ap.add_argument("--max-dim", type=int, default=220, help="Temporary max dimension during closure")
    ap.add_argument("--topk", type=int, default=12, help="Top coefficients stored per commutator")
    ap.add_argument("--coef-tol", type=float, default=1e-6, help="Coefficient threshold for sparse storage")
    args = ap.parse_args()

    in_dir = Path(args.in_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    D6 = np.load(in_dir/"D6_basis_66.npy").astype(np.complex128)
    COS = np.load(in_dir/"coset_basis_12.npy").astype(np.complex128)

    seed = [traceless(M) for M in list(D6) + list(COS)]
    closed = closure_deterministic(seed, tol=args.tol, max_dim=args.max_dim, max_passes=args.max_passes)

    # Make traceless again, re-close for stability
    closed = closure_deterministic([traceless(M) for M in closed], tol=args.tol, max_dim=args.max_dim, max_passes=args.max_passes)

    # Remove center if present and compress to 78
    center_idx = find_center(closed)
    center = closed[center_idx]
    no_center = [closed[i] for i in range(len(closed)) if i != center_idx]

    # Orthonormalize and take first 78
    Q78, basis78 = orth_basis(no_center, tol=args.tol, max_keep=78)
    if len(basis78) != 78:
        raise RuntimeError(f"Expected 78 basis elements after center removal, got {len(basis78)}")

    np.save(out_dir/"E6_basis_78.npy", np.stack(basis78, axis=0))
    np.save(out_dir/"center_element.npy", center)

    # Build commutator table
    comm_table=[]
    for i in range(78):
        for j in range(i+1, 78):
            C = basis78[i]@basis78[j] - basis78[j]@basis78[i]
            c = coeffs_in_basis(Q78, C)
            comm_table.append({
                "i": i,
                "j": j,
                "top": sparse_top(c, top=args.topk, tol=args.coef_tol)
            })

    meta = {
        "tol": args.tol,
        "max_passes": args.max_passes,
        "max_dim": args.max_dim,
        "topk": args.topk,
        "coef_tol": args.coef_tol,
        "center_index_in_closed": int(center_idx),
        "closed_dim_before_center": int(len(closed)),
        "final_dim": 78,
        "pairs": len(comm_table),
    }
    (out_dir/"commutator_table_sparse.json").write_text(json.dumps({"meta": meta, "table": comm_table}, indent=2))
    (out_dir/"meta.json").write_text(json.dumps(meta, indent=2))

    print("Wrote:", out_dir/"E6_basis_78.npy")
    print("Wrote:", out_dir/"center_element.npy")
    print("Wrote:", out_dir/"commutator_table_sparse.json")

if __name__ == "__main__":
    main()
