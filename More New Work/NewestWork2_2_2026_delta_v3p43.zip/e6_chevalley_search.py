#!/usr/bin/env python3
"""
Deterministic Chevalley search for E6 from exported 78-basis + Cartan.

Inputs:
  - E6_basis_78.npy (78x27x27 complex128)
  - Cartan_mats.npy (6x27x27 complex128)

Goal:
  1) Compute ad(Cartan) on the 78 basis (in basis coordinates).
  2) Extract root-weight clusters (Schur diagonalization).
  3) Build root operators E_w and E_-w as linear combos of basis (using Schur basis vectors).
  4) Compute Cartan entries A(w_i,w_j) via sl2 normalization:
       H_i := [E_i,F_i], scaled so [H_i,E_i]=2E_i
       A_ij := eigenvalue of ad(H_i) on E_j  (projection scalar)
  5) Search for 6 roots whose A matrix is exactly E6 Cartan (diag=2, offdiag in {0,-1}, 5 edges, degree multiset 1,1,1,2,2,3).

This script is designed to be run offline with longer time limits.
"""
from __future__ import annotations
import argparse, json, math, itertools, time
from pathlib import Path
import numpy as np
import scipy.linalg as la

def vecC(M: np.ndarray) -> np.ndarray:
    return np.concatenate([M.real.ravel(), M.imag.ravel()]).astype(np.float64)

def comm(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    return A@B - B@A

def frob(A: np.ndarray, B: np.ndarray) -> float:
    return float(np.vdot(A,B).real)

def scalar_proj(E: np.ndarray, X: np.ndarray) -> float:
    # scalar a minimizing ||X - aE|| in Frobenius inner product
    return frob(E,X)/max(1e-12, frob(E,E))

def build_coeff_solver(basis: np.ndarray) -> tuple[np.ndarray,np.ndarray]:
    # Solve coefficients in basis via QR: V=QR => c = R^{-1} Q^T vec(M)
    V=np.stack([vecC(basis[i]) for i in range(basis.shape[0])], axis=1)
    Q,R=np.linalg.qr(V)
    Rinv=np.linalg.inv(R)
    return Q,Rinv

def coeff(Q: np.ndarray, Rinv: np.ndarray, M: np.ndarray) -> np.ndarray:
    return Rinv @ (Q.T @ vecC(M))

def ad_mats(Cartan: np.ndarray, basis: np.ndarray, Q: np.ndarray, Rinv: np.ndarray) -> list[np.ndarray]:
    ad=[]
    for k in range(Cartan.shape[0]):
        H=Cartan[k]
        Ad=np.zeros((basis.shape[0], basis.shape[0]), dtype=np.float64)
        for j in range(basis.shape[0]):
            Ad[:,j]=coeff(Q,Rinv, comm(H, basis[j])).real
        ad.append(Ad)
    return ad

def schur_weights(ad: list[np.ndarray], use_imag: bool | None = None, nd: int = 6):
    rng=np.random.default_rng(0)
    rvec=rng.normal(size=len(ad))
    Acombo=sum(rvec[i]*ad[i] for i in range(len(ad)))
    T,U = la.schur(Acombo.astype(np.complex128), output='complex')
    lam=[]
    for i in range(len(ad)):
        Ti = U.conj().T @ ad[i].astype(np.complex128) @ U
        lam.append(np.diag(Ti))
    lam=np.stack(lam, axis=1) # 78x6 complex

    if use_imag is None:
        imag_max=float(np.max(np.abs(lam.imag)))
        real_max=float(np.max(np.abs(lam.real)))
        use_imag = imag_max >= real_max*0.2

    wts = lam.imag if use_imag else lam.real
    wtsr=np.round(wts, nd)
    return wtsr, U, use_imag

def canon_sign(w: tuple[float,...], nd=6) -> tuple[float,...]:
    v=np.array(w, dtype=np.float64)
    for t in v:
        if abs(t)>10**(-nd):
            if t<0: v=-v
            break
    return tuple(np.round(v, nd).tolist())

def build_root_ops(basis: np.ndarray, U: np.ndarray, wtsr: np.ndarray, nd=6):
    # Each Schur basis vector U[:,j] gives an operator sum_k U_kj * basis_k
    # Cluster weights and keep representative operator per weight.
    wt_map={}
    for j in range(wtsr.shape[0]):
        key=tuple(wtsr[j].tolist())
        wt_map.setdefault(key, []).append(j)

    zero_key=min(wt_map.keys(), key=lambda t: sum(abs(x) for x in t))
    root_keys=[k for k in wt_map.keys() if k!=zero_key and sum(abs(x) for x in k)>1e-9]

    def op_from_col(j: int) -> np.ndarray:
        v=U[:,j]
        M=np.zeros_like(basis[0], dtype=np.complex128)
        for k,ck in enumerate(v):
            if abs(ck)>1e-12:
                M += ck*basis[k]
        return M

    E={}
    for k in root_keys:
        j=wt_map[k][0]
        E[k]=op_from_col(j)
    return zero_key, wt_map, E

def build_H_scaled(Ep: np.ndarray, Em: np.ndarray) -> tuple[np.ndarray, float]:
    H0=comm(Ep, Em)
    # scaling so [H,Ep]=2 Ep
    c = scalar_proj(Ep, comm(H0, Ep))
    if abs(c)<1e-12:
        return H0, 1.0
    s = 2.0/c
    return s*H0, s

def search_E6(E: dict, nd=6, time_limit_s=60):
    # Use canonical-sign positive roots
    roots=list(E.keys())
    pos=[]
    for w in roots:
        if w==canon_sign(w,nd):
            pos.append(w)
    # Filter: require existence of negative
    pos=[w for w in pos if tuple((-np.array(w)).tolist()) in E]

    # Precompute H_w and Cartan entries on other roots
    H={}
    for w in pos:
        wm=tuple((-np.array(w)).tolist())
        H[w],_ = build_H_scaled(E[w], E[wm])

    # Cartan entry function (rounded)
    def Aij(wi,wj):
        C=comm(H[wi], E[wj])
        return int(round(scalar_proj(E[wj], C)))

    # Adjacency where A=-1 both ways
    adj={w:set() for w in pos}
    for i,wi in enumerate(pos):
        for wj in pos[i+1:]:
            a=Aij(wi,wj); b=Aij(wj,wi)
            if a==-1 and b==-1:
                adj[wi].add(wj); adj[wj].add(wi)

    target_deg=sorted([1,1,1,2,2,3])
    start=time.time()

    # Enumerate “central node with degree 3” pattern
    for t in pos:
        if time.time()-start > time_limit_s:
            break
        neigh=list(adj[t])
        if len(neigh)<3:
            continue
        for n1,n2,n3 in itertools.combinations(neigh,3):
            # pick branch leaf as n1, and extend arms from n2,n3
            for leaf, a, b in [(n1,n2,n3),(n2,n1,n3),(n3,n1,n2)]:
                # a and b must have neighbors other than t
                for a2 in adj[a]:
                    if a2==t: continue
                    if a2 in (leaf,b): continue
                    for b2 in adj[b]:
                        if b2==t: continue
                        if b2 in (leaf,a,a2): continue
                        nodes=[t,leaf,a,a2,b,b2]
                        # check induced degrees
                        deg=[]
                        edges=[]
                        for i,u in enumerate(nodes):
                            d=0
                            for j,v in enumerate(nodes):
                                if j<=i: continue
                                if v in adj[u]:
                                    edges.append((i,j))
                                    d += 1
                            # count neighbors among nodes
                            d2=sum(1 for v in nodes if v!=u and v in adj[u])
                            deg.append(d2)
                        if len(edges)!=5:
                            continue
                        if sorted(deg)!=target_deg:
                            continue
                        # connectivity
                        seen={0}
                        changed=True
                        while changed:
                            changed=False
                            for i,j in edges:
                                if i in seen and j not in seen:
                                    seen.add(j); changed=True
                                if j in seen and i not in seen:
                                    seen.add(i); changed=True
                        if len(seen)!=6:
                            continue
                        # Build Cartan matrix for this ordering (t,leaf,a,a2,b,b2)
                        A=np.zeros((6,6),dtype=int)
                        for i,u in enumerate(nodes):
                            for j,v in enumerate(nodes):
                                if i==j:
                                    A[i,j]=2
                                else:
                                    A[i,j]=Aij(u,v)
                        # verify offdiag in {0,-1}
                        ok=True
                        for i in range(6):
                            for j in range(6):
                                if i==j: continue
                                if A[i,j] not in (0,-1):
                                    ok=False; break
                            if not ok: break
                        if not ok:
                            continue
                        return {"nodes": nodes, "edges": edges, "deg": deg, "A": A.tolist()}
    return None

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--in-dir", type=str, default=".", help="Directory containing E6_basis_78.npy and Cartan_mats.npy")
    ap.add_argument("--time-limit", type=int, default=120, help="Seconds for deterministic search")
    ap.add_argument("--out", type=str, default="E6_Chevalley_Certificate_v2.json", help="Output JSON")
    args=ap.parse_args()

    in_dir=Path(args.in_dir)
    basis=np.load(in_dir/"E6_basis_78.npy").astype(np.complex128)
    cart=np.load(in_dir/"Cartan_mats.npy").astype(np.complex128)

    Q,Rinv = build_coeff_solver(basis)
    ad = ad_mats(cart, basis, Q, Rinv)

    # Killing metric on Cartan
    B=np.zeros((6,6),dtype=np.float64)
    for i in range(6):
        for j in range(6):
            B[i,j]=float(np.trace(ad[i]@ad[j]))
    B=(B+B.T)/2
    eig=np.linalg.eigvalsh(B)
    Binv=np.linalg.inv(B + np.eye(6)*(1e-8 - min(eig)))

    wtsr, U, use_imag = schur_weights(ad, use_imag=None, nd=6)
    zero_key, wt_map, E = build_root_ops(basis, U, wtsr, nd=6)

    result = {
        "dims": {"basis": int(basis.shape[0]), "cartan": 6},
        "killing_eigs": eig.tolist(),
        "weights": {
            "clusters": int(len(wt_map)),
            "zero_key": list(zero_key),
            "use_imag": bool(use_imag),
            "root_ops": int(len(E))
        },
    }

    found = search_E6(E, nd=6, time_limit_s=args.time_limit)
    result["search_result"] = found

    Path(args.out).write_text(json.dumps(result, indent=2))
    print("Wrote", args.out)
    if found:
        print("FOUND E6 Cartan matrix:")
        print(np.array(found["A"]))
    else:
        print("Did not lock a simple-root set within time limit.")

if __name__=="__main__":
    main()
