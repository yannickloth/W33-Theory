# e6_chevalley_search.py

This script tries to **deterministically** recover a canonical E6 simple-root system from:

- `E6_basis_78.npy` (78×27×27 complex128)
- `Cartan_mats.npy` (6×27×27 complex128)

It:
1) builds `ad(H_i)` on the 78 basis,
2) extracts weight clusters via Schur diagonalization,
3) builds root operators E_w from Schur basis vectors,
4) computes Cartan entries via sl2 normalization,
5) searches for a 6-node E6 Dynkin pattern using the computed Cartan adjacency.

## Run
```bash
python e6_chevalley_search.py --in-dir . --time-limit 300 --out E6_Chevalley_Certificate_v2.json
```

If it finds a solution, the JSON will include:
- the 6 simple-root weights
- the exact 6×6 Cartan matrix (entries 2 on diag, 0/−1 offdiag)
- the Dynkin edges.

If it fails within the time limit, increase `--time-limit`.
