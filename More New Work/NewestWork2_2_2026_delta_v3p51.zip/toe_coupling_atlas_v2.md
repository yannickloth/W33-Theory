# TOE Coupling Atlas v2 (E6-root couplings + protocol annotations)

- root clusters: 77
- zero-weight multiplicity: 1
- simple roots (6): [(-0.0, 7.8e-05, -1.6e-05, -0.000234, 5.2e-05, 1.6e-05), (-0.0, 0.002943, 0.000267, 0.00241, 0.0004, 0.000495), (0.004305, 0.002423, -0.000876, -0.00594, -0.001701, 0.000143), (0.005835, 0.001762, 0.004994, -0.00988, 0.003374, -0.002364), (0.003863, -0.012732, 0.001036, -0.013994, 0.000696, -0.002787), (0.006603, 0.015637, 0.003288, 0.012936, 0.001036, -0.004626)]

## Simple-root channels (protocol features)
- α1: root=(-0.0, 7.8e-05, -1.6e-05, -0.000234, 5.2e-05, 1.6e-05)  dominant(i→j)=[6, 13]  schlafli=True  blocked=False  Z12/Z24=2/4
- α2: root=(-0.0, 0.002943, 0.000267, 0.00241, 0.0004, 0.000495)  dominant(i→j)=[12, 22]  schlafli=True  blocked=False  Z12/Z24=0/0
- α3: root=(0.004305, 0.002423, -0.000876, -0.00594, -0.001701, 0.000143)  dominant(i→j)=[7, 1]  schlafli=False  blocked=False  Z12/Z24=2/4
- α4: root=(0.005835, 0.001762, 0.004994, -0.00988, 0.003374, -0.002364)  dominant(i→j)=[0, 11]  schlafli=True  blocked=False  Z12/Z24=10/20
- α5: root=(0.003863, -0.012732, 0.001036, -0.013994, 0.000696, -0.002787)  dominant(i→j)=[5, 9]  schlafli=True  blocked=False  Z12/Z24=2/4
- α6: root=(0.006603, 0.015637, 0.003288, 0.012936, 0.001036, -0.004626)  dominant(i→j)=[1, 22]  schlafli=False  blocked=False  Z12/Z24=0/0

## Coupling atlas (top by overlap with E_{α+β})
