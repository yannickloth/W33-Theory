# Chevalley simple generator identification (E6 Dynkin subgraph)

- stabilizer generators: 82
- commutator threshold: 1e-06
- score: 0

## Simple nodes (one valid E6 labeling)
- a3: stab_index=19 global_gen=19 meta=('edge', 3, 8) degree=3
- a5: stab_index=50 global_gen=50 meta=('edge', 4, 19) degree=2
- a6: stab_index=61 global_gen=61 meta=('edge', 14, 19) degree=1
- a1: stab_index=76 global_gen=76 meta=('cartan_seed', 2) degree=1
- a4: stab_index=77 global_gen=77 meta=('cartan_seed', 3) degree=2
- a2: stab_index=81 global_gen=81 meta=('cartan_seed', 7) degree=1

## Dynkin edges (commutator-nonzero)
- a3 -- a1
- a3 -- a4
- a3 -- a2
- a5 -- a6
- a5 -- a4

## Next
- Use the imported Cartan basis and compute ad(H) eigen-decomposition on each simple generator to extract root-space components.
- Select E_{+alpha_i} from the +weight component and E_{-alpha_i} from the -weight component.
- Generate full root system by commutators and verify 78-d closure.
