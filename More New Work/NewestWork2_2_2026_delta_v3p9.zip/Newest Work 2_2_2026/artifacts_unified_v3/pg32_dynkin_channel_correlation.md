# PG(3,2) × Dynkin Channel Correlation

This report correlates **Dynkin node channel families** with the **PG(3,2)** incidence structure carried by the remaining15 sector.

## PG(3,2) recap
- points: 15 (remaining15)
- lines: 35 = 20 triangle + 15 matching
- each point on 7 lines: True

## Node-by-node summary
### a6 (node 0)
- remaining15 collinear edges: 0
- remaining15 touch edges: 0
- remaining15 noncollinear edges: 0
- line types (collinear): {}

### a2 (node 1)
- remaining15 collinear edges: 4
- remaining15 touch edges: 1
- remaining15 noncollinear edges: 0
- line types (collinear): {'triangle': 3, 'matching': 1}
  - ['edge', 0, 16] class=touch_L eps=0 -> touches point 16 duad=[1, 3]
  - ['edge', 14, 16] class=within_remaining15 eps=0 -> triangle line [23, 16, 14]
  - ['edge', 16, 18] class=within_remaining15 eps=0 -> triangle line [17, 18, 16]
  - ['edge', 16, 17] class=within_remaining15 eps=1 -> triangle line [17, 18, 16]

### a3 (node 2)
- remaining15 collinear edges: 1
- remaining15 touch edges: 0
- remaining15 noncollinear edges: 0
- line types (collinear): {'triangle': 1}
  - ['edge', 5, 9] class=within_remaining15 eps=0 -> triangle line [9, 5, 8]

### a5 (node 3)
- remaining15 collinear edges: 0
- remaining15 touch edges: 0
- remaining15 noncollinear edges: 0
- line types (collinear): {}

### a4 (node 4)
- remaining15 collinear edges: 0
- remaining15 touch edges: 1
- remaining15 noncollinear edges: 0
- line types (collinear): {}
  - ['edge', 1, 5] class=touch_L eps=0 -> touches point 5 duad=[4, 5]

### a1 (node 5)
- remaining15 collinear edges: 0
- remaining15 touch edges: 1
- remaining15 noncollinear edges: 0
- line types (collinear): {}
  - ['edge', 4, 17] class=touch_L eps=0 -> touches point 17 duad=[1, 2]

