# TOE Phase Diagram v5: critical boundary + symmetry reselection

This post-processes the v4 phase diagram to infer:
- an ordered/disordered boundary as a function of firewall strength
- a symmetry reselection index tracking changes in the optimized conserved charge direction

## Thresholds
- drift median threshold: 4.4726e-03
- holonomy entropy median threshold: 3.1552e+00

## Critical boundary (σ*)
- firewall 0.00: σ* ≈ 0.000
- firewall 0.17: σ* ≈ 0.000
- firewall 0.33: σ* ≈ 0.000
- firewall 0.50: σ* ≈ 0.067
- firewall 0.67: σ* ≈ 0.467
- firewall 0.83: σ* ≈ 0.467
- firewall 1.00: σ* ≈ 0.067

## Files
- phase_diagram_score_with_boundary.png
- phase_diagram_ordered_mask.png
- phase_diagram_symmetry_reselection.png
- critical_boundary_curve.png
- toe_phase_diagram_v5_summary.json
