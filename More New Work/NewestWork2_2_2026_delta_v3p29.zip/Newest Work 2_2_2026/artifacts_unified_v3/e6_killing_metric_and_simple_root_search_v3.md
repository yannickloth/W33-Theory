# Killing metric + simple root search v3

## Metrics
- ad-metric computed on stab-span: too restrictive for norm≈2 selection.
- trace-metric on 27 rep: produces E6 Dynkin graph (5 edges, degrees 1,1,1,2,2,3) but Cartan integrality still imperfect.

## Trace-metric result
- scale: 2.0000000930272126
- candidates: 28
- E6 graph score: 0 edges=5 degrees=[1, 1, 1, 2, 2, 3]
- chosen roots: [(-0.0, 1.0, -1.0, -0.0, -0.0, -0.0), (0.0, 0.0, 1.0, -1.0, 0.0, 0.0), (-0.0, -0.0, -0.0, 1.0, -0.0, 1.0), (1.0, -0.0, -0.0, -0.0, -0.0, -1.0), (-0.0, 1.0, -0.0, -0.0, -0.0, 1.0), (-0.0, 1.0, -0.0, -0.0, -0.0, -1.0)]
- best sign Cartan score: 40
- best sign Cartan:
[[2, -1, 0, 0, -1, -1], [-1, 2, -1, 0, 0, 0], [0, -1, 2, -1, -1, 1], [0, 0, -1, 2, 1, -1], [-1, 0, -1, 1, 2, 0], [-1, 0, 1, -1, 0, 2]]

## Next
- Compute ad-metric (Killing) on a **true 78-d closed basis** of the E6 algebra (not the stab-span). The current ad metric is under-resolved.
- Use that Killing metric to repeat the search; Cartan matrix should become integral with off-diagonals in {0,-1}.
