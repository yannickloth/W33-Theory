#!/usr/bin/env python3
"""
Unified TOE pipeline runner.

Runs:
  1) compute_double_sixes.py
  2) verify_toe_bridge.py
  3) e8_e6_a2_fusion.py

Collects artifacts into ./artifacts_unified and performs cross-checks:
  - 72 K6 cliques -> 36 double-sixes (E6 -> S6xZ2 breaking)
  - W33 firewall split: 27 good, 27 bad inside H27 non-orth pairs (243 = 216+27)
  - E8 -> E6 ⊕ A2 decomposition counts and SU(3) weight labels

This is designed to be a single command that reproduces the "TOE bridge" story.
"""
from __future__ import annotations
import json, subprocess, sys, shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "artifacts_unified"
OUT.mkdir(parents=True, exist_ok=True)

def run(cmd: list[str], name: str) -> str:
    p = subprocess.run(cmd, cwd=str(ROOT), capture_output=True, text=True)
    (OUT / f"{name}.stdout.txt").write_text(p.stdout, encoding="utf-8", errors="replace")
    (OUT / f"{name}.stderr.txt").write_text(p.stderr, encoding="utf-8", errors="replace")
    if p.returncode != 0:
        raise RuntimeError(f"{name} failed with code {p.returncode}. See artifacts_unified/{name}.stderr.txt")
    return p.stdout

def copy_if_exists(path: Path):
    if path.exists():
        shutil.copy2(path, OUT / path.name)

def main():
    print("Running compute_double_sixes.py ...")
    run([sys.executable, "compute_double_sixes.py"], "compute_double_sixes")

    print("Running verify_toe_bridge.py ...")
    run([sys.executable, "verify_toe_bridge.py"], "verify_toe_bridge")

    print("Running e8_e6_a2_fusion.py ...")
    run([sys.executable, "e8_e6_a2_fusion.py"], "e8_e6_a2_fusion")

    # Collect JSON artifacts written outside this folder (in /mnt/data/newest_work_2_2_2026/artifacts)
    ext_art = Path("/mnt/data/newest_work_2_2_2026/artifacts")
    if ext_art.exists():
        for fn in ["toe_bridge_verification.json", "e8_e6_a2_fusion.json"]:
            p = ext_art / fn
            if p.exists():
                shutil.copy2(p, OUT / fn)

    # Basic cross-checks
    report = {}
    tb = OUT / "toe_bridge_verification.json"
    if tb.exists():
        data = json.loads(tb.read_text(encoding="utf-8"))
        report["firewall"] = data.get("firewall", {})
        report["status"] = data.get("status", None)
    ef = OUT / "e8_e6_a2_fusion.json"
    if ef.exists():
        data = json.loads(ef.read_text(encoding="utf-8"))
        report["e8_e6_a2"] = {
            "counts": data.get("counts", {}),
            "su3": data.get("su3", {}),
        }
    (OUT / "UNIFIED_REPORT.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("Wrote artifacts_unified/UNIFIED_REPORT.json")

if __name__ == "__main__":
    main()
