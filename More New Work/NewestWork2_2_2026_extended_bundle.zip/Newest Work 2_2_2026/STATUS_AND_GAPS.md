# Status and gaps (what’s computed vs what’s still physics)

## What’s currently *computationally verified in this repo*

- `E8` root system is constructed explicitly (240 roots).
- A Coxeter element power partitions roots into `40` orbits of size `6` (the W33 vertex set model used here).
- Under `W(E6)`, the 240 roots decompose as `72 + 6×27 + 6×1`.
- Each `27`-orbit carries a Schläfli graph `SRG(27,16,10,8)` with:
  - `72` K6 cliques (“sixes” of mutually skew lines),
  - `36` double-sixes,
  - stabilizer order `1440 = |S6|×2`.
- The “firewall” split inside an `H27` neighborhood yields:
  - `243 = 216 + 27` (kernel edges + “bad edges”),
  - “bad edges” forming nine disjoint 3-cycles (universally over all 40 embeddings).
- The A2 (= SU(3)) factor orthogonal to E6 is recovered and validated at the **root-addition** level:
  - E6 and A2 subsystems are closed under root addition,
  - A2 roots act as ladders moving between the six 27-orbits in a clean, 27-to-27 pattern.

## What is *not* yet a physical theory (open work)

Even if the group-/graph-level identifications are correct, turning them into an honest “theory of everything” still requires:

- A Lagrangian / dynamics: a principled action (or Hamiltonian), field content, and equations of motion.
- Chirality: a mechanism for left/right asymmetry (representation choice, anomaly constraints).
- Masses and mixing: Yukawa textures, CKM/PMNS structure, hierarchy, and CP violation from a concrete coupling rule.
- Running couplings and scales: RG flow and a match to measured couplings and thresholds.
- Gravity/spacetime: how Lorentzian geometry and GR (or quantum gravity) emerges, with observationally testable signatures.
- Experimental falsifiability: specific, quantitative predictions (cross sections, decay rates, cosmology) with uncertainties.

The repo is currently strong on **rigid combinatorics + Lie/finite-geometry correspondences**.
Bridging to physics demands adding **dynamics, scales, and experimentally checkable numbers**.

