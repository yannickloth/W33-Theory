
#!/usr/bin/env python3
"""Parametric Dynkin lock attempt using a Killing-form proxy metric (v2).

Improvements:
- Cartan selection uses greedy + swap-search for better commuting margin and independence.
- Root clustering uses Killing-metric (Mahalanobis) distance rather than Euclidean.

Writes /mnt/data/newest_work_2_2_2026/artifacts/dynkin_lock_best.json
"""
from __future__ import annotations
import argparse, json, math, random
from pathlib import Path
from collections import defaultdict
import itertools
import numpy as np
import subprocess, sys, importlib.util

ROOT = Path(__file__).resolve().parent
EXT_ART = Path("/mnt/data/newest_work_2_2_2026/artifacts")
EXT_ART.mkdir(parents=True, exist_ok=True)
CHAT_ART = Path("/mnt/data/chat_artifacts")

def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tol", type=float, default=1e-8)
    ap.add_argument("--bsub", type=int, default=220)
    ap.add_argument("--eps_roots", type=str, default="1e-4,2e-4,3e-4")
    ap.add_argument("--trials", type=int, default=3000)
    ap.add_argument("--swap_iters", type=int, default=3000)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--topN", type=int, default=240)
    return ap.parse_args()

def load_json(p: Path):
    return json.loads(p.read_text(encoding="utf-8", errors="replace"))

def ensure_bridge_artifact():
    tb = EXT_ART/"toe_bridge_verification.json"
    if tb.exists():
        return tb
    p = subprocess.run([sys.executable, str(ROOT/"verify_toe_bridge.py")], cwd=str(ROOT), capture_output=True, text=True)
    if p.returncode != 0:
        raise RuntimeError("verify_toe_bridge failed; cannot build phase tables.")
    if not tb.exists():
        raise RuntimeError("verify_toe_bridge ran but toe_bridge_verification.json not found.")
    return tb

def build_generators():
    # Schläfli adjacency in chat artifacts
    S_path = CHAT_ART/"toe_E6_schlafli_restrictions/S_schlafli_27.npy"
    if not S_path.exists():
        raise RuntimeError("Missing S_schlafli_27.npy in chat_artifacts/toe_E6_schlafli_restrictions")
    S = np.load(S_path).astype(int)
    edge_list=[]
    for i in range(27):
        for j in range(i+1,27):
            if S[i,j]==1:
                edge_list.append((i,j))
    if len(edge_list)!=216:
        raise RuntimeError(f"Expected 216 Schläfli edges, got {len(edge_list)}")

    sel_file = CHAT_ART/"toe_step3_subalgebra_extraction_fast.json"
    if not sel_file.exists():
        raise RuntimeError("Missing toe_step3_subalgebra_extraction_fast.json in chat_artifacts")
    sel = load_json(sel_file)["selected_edge_indices"]

    sum_file = CHAT_ART/"toe_E6_schlafli_from_rank6_restriction_summary.json"
    if not sum_file.exists():
        raise RuntimeError("Missing toe_E6_schlafli_from_rank6_restriction_summary.json in chat_artifacts")
    H27 = [int(x) for x in load_json(sum_file)["H27_global_indices"]]

    # Phase tables from /mnt/data (chat-produced)
    hol = load_json(Path("/mnt/data/toe_discrete_gauge_field_holonomy.json"))
    clk = load_json(Path("/mnt/data/toe_local_1form_clock.json"))["local_table"]
    ctx = load_json(Path("/mnt/data/toe_contextual_firewall_spin_clock_solver.json"))
    p_transition = ctx["p_transition"]

    state_to_block={}
    for b,info in hol["blocks"].items():
        b=int(b)
        for s in info["states"]:
            state_to_block[int(s)] = b

    vertex_label={}
    for b,info in hol["blocks"].items():
        for vtx,lab in info["labels"].items():
            vertex_label[int(vtx)] = tuple(lab)

    def parse_xy(s): return (int(s[0]), int(s[1]))
    k6={}
    for key,val in clk.items():
        A,B = key.split("->"); A=int(A); B=int(B)
        for xk,info in val["edges"].items():
            x=parse_xy(xk)
            k6[(A,B,x)] = int(info["k6"])%6

    def pbit(A,B,x):
        return 1 if int(p_transition.get(str((A,B,x)),0))==2 else 0

    zeta = np.exp(2j*np.pi/6).astype(np.complex64)

    def weight_for_dir(i,j):
        u = H27[i]; v = H27[j]
        bu = state_to_block[u]; bv = state_to_block[v]
        xu = vertex_label[u]
        if bu==bv:
            return np.complex64(1.0+0j)
        kk = k6[(bu,bv,xu)]
        pp = pbit(bu,bv,xu)
        return (zeta**np.int32(kk))*np.complex64((-1)**pp)

    gens=[]
    for idx in sel:
        i,j = edge_list[int(idx)]
        w = weight_for_dir(i,j)
        th = float(np.angle(w))
        a = np.complex64(math.cos(th)+1j*math.sin(th))
        X = np.zeros((27,27), dtype=np.complex64)
        X[i,j]=a
        X[j,i]=-np.conjugate(a)
        gens.append(X)

    for k in range(8):
        D=np.zeros((27,27), dtype=np.complex64)
        D[k,k]=1; D[k+1,k+1]=-1
        gens.append(1j*D)
    return gens

def build_templates():
    coords_data = load_json(CHAT_ART/"toe_trinification_coords_27.json")
    coords = {int(k):(v["a"],v["b"],v["c"]) for k,v in coords_data["coords"].items()}
    inv_coords = {tuple(v): int(k) for k,v in coords.items()}

    perm_sign={}
    for perm in itertools.permutations([0,1,2]):
        inv=0
        for i in range(3):
            for j in range(i+1,3):
                if perm[i]>perm[j]:
                    inv+=1
        perm_sign[perm] = -1 if inv%2 else 1

    templates=[]
    def add_temp(triple_coef_list):
        d=defaultdict(int)
        for tri,coef in triple_coef_list:
            d[tuple(sorted(tri))]+=int(coef)
        templates.append(dict(d))

    # diag
    diag=[]
    for a in range(3):
        for b in range(3):
            for c in range(3):
                v0=inv_coords[(a,b,c)]
                v1=inv_coords[((a+1)%3,(b+1)%3,(c+1)%3)]
                v2=inv_coords[((a+2)%3,(b+2)%3,(c+2)%3)]
                diag.append(((v0,v1,v2),1))
    add_temp(diag)
    # det slices
    for c in range(3):
        det=[]
        for perm,sgn in perm_sign.items():
            verts=[inv_coords[(a,perm[a],c)] for a in range(3)]
            det.append((tuple(verts), sgn))
        add_temp(det)
    # shifts
    shiftA=[]; shiftB=[]
    for a in range(3):
        for b in range(3):
            for c in range(3):
                v0=inv_coords[(a,b,c)]
                v1=inv_coords[((a+1)%3,(b+2)%3,(c+1)%3)]
                v2=inv_coords[((a+2)%3,(b+1)%3,(c+2)%3)]
                shiftA.append(((v0,v1,v2),1))
                v1b=inv_coords[((a+1)%3,(b+1)%3,(c+2)%3)]
                v2b=inv_coords[((a+2)%3,(b+2)%3,(c+1)%3)]
                shiftB.append(((v0,v1b,v2b),1))
    add_temp(shiftA); add_temp(shiftB)
    # trace terms
    t1=[]; t2=[]; t3=[]
    for a in range(3):
        for b in range(3):
            for c in range(3):
                t1.append(((inv_coords[(a,b,0)], inv_coords[(b,c,1)], inv_coords[(c,a,2)]),1))
                t2.append(((inv_coords[(a,b,0)], inv_coords[(b,c,2)], inv_coords[(c,a,1)]),1))
                t3.append(((inv_coords[(a,b,1)], inv_coords[(b,c,2)], inv_coords[(c,a,0)]),1))
    add_temp(t1); add_temp(t2); add_temp(t3)
    return templates

def main():
    args = parse_args()
    gens = build_generators()
    G = len(gens)

    aud = load_json(CHAT_ART/"toe_step3_breakthrough_full_sym3_audit.json")
    alpha = np.array(aud["solve"]["alpha"],dtype=np.float64)

    templates = build_templates()
    S0=set()
    for t in templates:
        S0.update(t.keys())

    nz_list=[[(int(a),int(b), gens[gi][int(a),int(b)]) for a,b in np.argwhere(np.abs(gens[gi])>1e-8)] for gi in range(G)]

    # Expand U
    cap=3654
    U=set(S0)
    for _ in range(5):
        added=0
        cur=list(U)
        for tri in cur:
            i,j,k=tri
            for nz in nz_list:
                for a,b,_ in nz:
                    if b==i:
                        u=tuple(sorted((a,j,k)))
                        if u not in U: U.add(u); added+=1
                    if b==j:
                        u=tuple(sorted((i,a,k)))
                        if u not in U: U.add(u); added+=1
                    if b==k:
                        u=tuple(sorted((i,j,a)))
                        if u not in U: U.add(u); added+=1
            if len(U)>=cap: break
        if added==0: break
    U=sorted(U); p=len(U)
    tri_index={tri:i for i,tri in enumerate(U)}

    K=len(templates)
    template_vecs=np.zeros((p,K),dtype=np.float64)
    for k,t in enumerate(templates):
        for tri,coef in t.items():
            template_vecs[tri_index[tri],k]=coef
    c_comb=(template_vecs @ alpha).astype(np.complex64)
    nz_c=np.where(np.abs(c_comb)>1e-12)[0].tolist()

    def apply_AX(nzX):
        out=np.zeros(p,dtype=np.complex64)
        for t_idx in nz_c:
            c=c_comb[t_idx]
            if c==0: continue
            i,j,k=U[t_idx]
            for a,b,val in nzX:
                if b==i:
                    idx=tri_index.get(tuple(sorted((a,j,k))))
                    if idx is not None: out[idx]+=val*c
                if b==j:
                    idx=tri_index.get(tuple(sorted((i,a,k))))
                    if idx is not None: out[idx]+=val*c
                if b==k:
                    idx=tri_index.get(tuple(sorted((i,j,a))))
                    if idx is not None: out[idx]+=val*c
        return out

    residuals=np.array([float(np.vdot(apply_AX(nz_list[gi]), apply_AX(nz_list[gi])).real) for gi in range(G)], dtype=float)
    stab_idx=[i for i in range(G) if residuals[i]<=args.tol]
    stab=[gens[i] for i in stab_idx]
    stabH=[(-1j)*M.astype(np.complex128) for M in stab]

    # Cartan selection (greedy + swap-search)
    def comm_norm(A,B): return float(np.linalg.norm(A@B - B@A))
    eps_comm=1e-6
    deg=[]
    for i,A0 in enumerate(stabH):
        cnt=0
        for j,B0 in enumerate(stabH):
            if i!=j and comm_norm(A0,B0)<=eps_comm: cnt+=1
        deg.append((cnt,i))
    deg.sort(reverse=True)

    cart_idx=[]
    cart=[]
    for cnt,i in deg:
        A0=stabH[i]
        if all(comm_norm(A0,B0)<=eps_comm for B0 in cart):
            cart.append(A0); cart_idx.append(i)
        if len(cart)>=6:
            break

    def frob_inner(A,B): return float(np.vdot(A,B).real)
    def score_cart(indices):
        mats=[stabH[i] for i in indices]
        pen=0.0
        for a in range(len(mats)):
            for b in range(a+1,len(mats)):
                pen += comm_norm(mats[a], mats[b])
        gs=[]
        bonus=0.0
        for H in mats:
            W_=H.copy()
            for Q_ in gs:
                W_ = W_ - (frob_inner(Q_,W_)/max(1e-12,frob_inner(Q_,Q_)))*Q_
            nrm=float(np.linalg.norm(W_))
            if nrm>1e-6:
                gs.append(W_)
                bonus += math.log(1.0+nrm)
        return -pen + 0.2*bonus

    rng_local = random.Random(args.seed)
    pool = [i for _,i in deg[:min(250,len(deg))]]

    while len(cart_idx)<6 and pool:
        i=pool.pop(0)
        if i not in cart_idx:
            cart_idx.append(i)
    cart_idx = cart_idx[:6]

    best_idx = cart_idx[:]
    best_sc = score_cart(best_idx)
    for _ in range(500):
        pos = rng_local.randrange(6)
        cand = rng_local.choice(pool)
        if cand in best_idx: 
            continue
        trial = best_idx[:]; trial[pos]=cand
        sc = score_cart(trial)
        if sc > best_sc:
            best_sc=sc; best_idx=trial

    cart = [stabH[i] for i in best_idx]

    # Orthonormalize Cartan
    cart_ortho=[]
    for H in cart:
        W_=H.copy()
        for Q_ in cart_ortho:
            W_ = W_ - (frob_inner(Q_,W_)/max(1e-12,frob_inner(Q_,Q_)))*Q_
        if np.linalg.norm(W_)>1e-8: cart_ortho.append(W_)
    cart_ortho=cart_ortho[:6]
    r=len(cart_ortho)

    # Killing proxy metric
    def vecR(M):
        return np.concatenate([M.real.ravel(), M.imag.ravel()]).astype(np.float64)
    basis_mats=stab[:min(args.bsub, len(stab))]
    Bmat=np.stack([vecR(M) for M in basis_mats], axis=1)
    Q,_=np.linalg.qr(Bmat)
    def project(M): return Q.T @ vecR(M)
    def comm(A,B): return A@B - B@A
    ad=np.zeros((r,len(basis_mats),Q.shape[1]),dtype=np.float64)
    for i,H in enumerate(cart_ortho):
        for k,X in enumerate(basis_mats):
            ad[i,k,:]=project(comm(H, X.astype(np.complex128)))
    Bmetric=np.zeros((r,r),dtype=np.float64)
    for i in range(r):
        for j in range(r):
            Bmetric[i,j]=float(np.sum(ad[i,:,:]*ad[j,:,:]))
    Bmetric=(Bmetric+Bmetric.T)/2
    eig=np.linalg.eigvalsh(Bmetric)
    if eig.min()<=1e-12:
        Bmetric += np.eye(r)*(1e-6 - eig.min())

    # Weights
    rng=np.random.default_rng(args.seed)
    coeffs=rng.normal(size=r)
    H0=np.zeros((27,27),dtype=np.complex128)
    for c,H in zip(coeffs,cart_ortho):
        H0 += c*H
    ew,Ueig=np.linalg.eigh(H0)
    W=np.zeros((27,r),dtype=np.float64)
    for k,H in enumerate(cart_ortho):
        D=np.diag(Ueig.conj().T @ H @ Ueig)
        W[:,k]=D.real

    def ip(x,y): return float(x @ Bmetric @ y)
    def cartan_matrix(simples):
        C=np.zeros((6,6),dtype=np.float64)
        for i in range(6):
            for j in range(6):
                den=ip(simples[j],simples[j])
                C[i,j]=0 if den<1e-12 else 2*ip(simples[i],simples[j])/den
        return C

    def score(Cr):
        Crn=np.array(Cr,dtype=int)
        if Crn.shape!=(6,6): return 10**9
        if not np.all(np.diag(Crn)==2): return 10**6
        bad=0
        for i in range(6):
            for j in range(6):
                if i==j: continue
                if Crn[i,j] not in (0,-1): bad += 4
        edges=int(np.sum(Crn[np.triu_indices(6,1)]==-1))
        bad += abs(edges-5)*3
        degs=sorted([int(np.sum(Crn[i,:]==-1)) for i in range(6)])
        bad += sum(abs(a-b) for a,b in zip(degs,sorted([1,1,1,2,2,3])))
        return int(bad)

    def search_for_eps(eps_root):
        clusters=[]; counts=[]
        # metric-aware clustering distance
        def norm_sign(v):
            vv=v.copy()
            for t in vv:
                if abs(t)>eps_root:
                    if t<0: vv=-vv
                    break
            return vv
        def add(v):
            vv=norm_sign(v)
            for i,rep in enumerate(clusters):
                d = vv-rep
                dist = math.sqrt(float(d @ Bmetric @ d))
                if dist < eps_root:
                    counts[i]+=1; return
            clusters.append(vv); counts.append(1)
        for X0 in stab:
            Y=Ueig.conj().T @ X0.astype(np.complex128) @ Ueig
            flat=np.abs(Y.ravel())
            idxs=np.argsort(-flat)[:200]
            for idx in idxs:
                p0=idx//27; q0=idx%27
                if p0==q0 or flat[idx]<1e-7: continue
                v=W[p0]-W[q0]
                if np.linalg.norm(v)<eps_root: continue
                add(v)
        roots=np.array(clusters); rc=np.array(counts)
        topN=min(args.topN, len(roots))
        cand_idx=np.argsort(-rc)[:topN]
        rngr = random.Random(args.seed)
        best=None
        def eval_set(idxs):
            simples=roots[idxs].copy()
            if np.linalg.matrix_rank(simples, tol=1e-6)<6:
                return None,None,10**9
            # Try all 2^6 sign flips to minimize score (since root sign choice is arbitrary)
            best_local = None
            best_C = None
            best_Cr = None
            for mask in range(64):
                s = simples.copy()
                for i in range(6):
                    if (mask>>i) & 1:
                        s[i] = -s[i]
                C = cartan_matrix(s)
                Cr = np.rint(C).astype(int)
                sc = score(Cr)
                if best_local is None or sc < best_local:
                    best_local = sc
                    best_C = C
                    best_Cr = Cr
                    if sc == 0:
                        break
            return best_C, best_Cr, best_local
        for _ in range(args.trials):
            idxs=rngr.sample(list(map(int,cand_idx)),6)
            C,Cr,sc=eval_set(idxs)
            if sc<10**9 and (best is None or sc<best["score"]):
                best={"score":int(sc),"idxs":[int(i) for i in idxs],"C_round":Cr.tolist()}
                if sc==0: break
        if best and best["score"]>0:
            current=best["idxs"][:]; cur_sc=best["score"]
            for _ in range(args.swap_iters):
                pos=rngr.randrange(6)
                for cand in rngr.sample(list(map(int,cand_idx)), min(120,len(cand_idx))):
                    if cand in current: continue
                    trial=current[:]; trial[pos]=cand
                    C,Cr,sc=eval_set(trial)
                    if sc<cur_sc:
                        current=trial; cur_sc=int(sc)
                        best={"score":cur_sc,"idxs":current,"C_round":Cr.tolist()}
                        break
                if cur_sc==0: break
        return int(len(roots)), best

    results=[]
    for eps_root in [float(x) for x in args.eps_roots.split(",")]:
        rootN, best = search_for_eps(eps_root)
        results.append({"eps_root": eps_root, "root_clusters": rootN, "best": best})

    best_run=None
    for rec in results:
        sc = rec["best"]["score"] if rec["best"] else 10**9
        cand=(sc, -rec["root_clusters"], rec["eps_root"])
        if best_run is None or cand<best_run[0]:
            best_run=(cand, rec)

    out={
        "tol": args.tol,
        "bsub": args.bsub,
        "cartan_rank": r,
        "stabilizer_count": len(stab_idx),
        "killing_metric_eigs": [float(eig.min()), float(eig.max())],
        "results": results,
        "best_run": best_run[1] if best_run else None,
    }
    (EXT_ART/"dynkin_lock_best.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print("Wrote", EXT_ART/"dynkin_lock_best.json")

if __name__ == "__main__":
    main()
