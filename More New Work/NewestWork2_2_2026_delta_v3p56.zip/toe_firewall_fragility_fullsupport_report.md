# TOE Firewall Fragility v2 (full-support)

This refines v1 by using the **full operator support** (top-N matrix entries) for each output channel.

## Counts
- backbone: 10
- coset: 3
- mixed: 2

## Output
- firewall_fragility_fullsupport.png
- toe_firewall_fragility_fullsupport_summary.json
