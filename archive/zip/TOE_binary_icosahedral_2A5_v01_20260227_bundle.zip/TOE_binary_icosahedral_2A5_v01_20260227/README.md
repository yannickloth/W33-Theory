Binary icosahedral subgroup analysis bundle

Contains orbit decompositions for the canonical A5 stabilizer on W33 lines
and any vertex-based data when a lift exists (currently none).
