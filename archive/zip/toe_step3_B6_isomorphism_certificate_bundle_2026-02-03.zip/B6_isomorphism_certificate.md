B6 (so(13)) isomorphism certificate for extracted 78-dim Lie algebra root system.

1) Permute extracted Cartan matrix by p=(5,4,1,3,0,2) to match standard B6 Cartan.

2) Using permuted simple roots alpha1..alpha6, reconstruct orthonormal e-basis via e6=alpha6; e_i=alpha_i+e_{i+1}.

3) Predicted B6 root set {±e_i±e_j, ±e_i} matches extracted 72-root list exactly (to 1e-12 rounding).

4) Root-length spectrum splits into long/short with counts 60/12, consistent with B6.
