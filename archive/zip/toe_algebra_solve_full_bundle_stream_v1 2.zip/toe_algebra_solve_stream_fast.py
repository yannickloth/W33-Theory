#!/usr/bin/env python3
"""
Fast streamed verification for the 78 basis (66+12) 27x27 matrices.

Key speed trick:
  - flatten basis into V shape (n,729)
  - Fro inner product <Bi,X> = vdot(V[i], xvec)
  - projection coeffs c = G_inv @ (V @ xvec_conj?)  (careful with conjugation)

We output:
  - closure residual stats on random pairs
  - jacobi residual stats on random triples
  - approximate Killing form rank via sampled adjoint actions (optional)

This is designed to run in <=45s for moderate sample sizes.
"""
import argparse, os, json, time, numpy as np

def comm(A,B):
    return A@B - B@A

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--basis66", required=True)
    ap.add_argument("--basis12", required=True)
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--bundle_out", required=True)
    ap.add_argument("--pairs", type=int, default=1000)
    ap.add_argument("--triples", type=int, default=1000)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--killing_samples_per_i", type=int, default=0)
    args=ap.parse_args()

    rng=np.random.default_rng(args.seed)
    os.makedirs(args.outdir, exist_ok=True)

    B66=np.load(args.basis66)
    B12=np.load(args.basis12)
    B=np.concatenate([B66,B12],axis=0).astype(np.complex128)
    n=B.shape[0]
    d=B.shape[1]
    m=d*d

    V=B.reshape(n,m)
    # Gram
    t0=time.time()
    G = V @ V.conj().T  # <i,j> = sum_k V[i,k] conj(V[j,k])? Actually vdot does conj(first). Here we want vdot(Bi,Bj)=sum conj(Bi) Bj. That's V.conj() @ V.T
    # Correct:
    G = V.conj() @ V.T
    # Regularize
    lam=1e-12*np.trace(G).real/n
    G_reg=G + lam*np.eye(n)
    G_inv=np.linalg.inv(G_reg)
    tG=time.time()-t0

    def proj_coeffs(X):
        x=X.reshape(m)
        b = V.conj() @ x  # b_i = vdot(V[i], x) = conj(V[i]) dot x
        return G_inv @ b

    # closure
    closure=[]
    maxr=0.0
    for _ in range(args.pairs):
        i=int(rng.integers(0,n)); j=int(rng.integers(0,n))
        C=comm(B[i],B[j])
        c=proj_coeffs(C)
        Chat = (c[:,None]*V).sum(axis=0).reshape(d,d)
        r=np.linalg.norm(C-Chat)/ (np.linalg.norm(C)+1e-30)
        rr=float(r.real)
        closure.append(rr); 
        if rr>maxr: maxr=rr
    closure_mean=float(np.mean(closure))

    # jacobi
    jac=[]
    jacmax=0.0
    for _ in range(args.triples):
        a=int(rng.integers(0,n)); b=int(rng.integers(0,n)); c=int(rng.integers(0,n))
        A=B[a]; Bb=B[b]; Cc=B[c]
        J=comm(A,comm(Bb,Cc))+comm(Bb,comm(Cc,A))+comm(Cc,comm(A,Bb))
        denom=(np.linalg.norm(A)*np.linalg.norm(Bb)*np.linalg.norm(Cc)+1e-30)
        r=np.linalg.norm(J)/denom
        rr=float(r.real)
        jac.append(rr)
        if rr>jacmax: jacmax=rr
    jac_mean=float(np.mean(jac))

    # optional approximate Killing rank
    killing_summary=None
    if args.killing_samples_per_i>0:
        S=args.killing_samples_per_i
        # Build sampled adjoint matrices Ad_i approximately (n x n) via least squares on sampled commutators
        # For fixed i, we gather equations [B_i,B_j_s] ≈ sum_k f_{i j_s}^k B_k ; coefficients are proj_coeffs
        Ad=np.zeros((n,n),dtype=np.complex128)
        for i in range(n):
            for _ in range(S):
                j=int(rng.integers(0,n))
                C=comm(B[i],B[j])
                coeff=proj_coeffs(C)
                # store row j of ad_i (j -> coeff)
                Ad_row=coeff
                # accumulate average (since j repeats, we average)
                Ad[j,:]+=Ad_row
        Ad/=max(1,S)
        K=Ad@Ad.T  # crude proxy
        evals=np.linalg.eigvalsh((K+K.conj().T)/2.0)
        killing_summary={"proxy_rank_1e-8": int(np.sum(np.abs(evals)>1e-8)),
                         "min_eig": float(np.min(evals).real),
                         "max_eig": float(np.max(evals).real)}
        np.save(os.path.join(args.outdir,"killing_proxy.npy"),K)

    meta={"n_basis":int(n),"dim":int(d),"pairs":args.pairs,"triples":args.triples,
          "seed":args.seed,"gram_seconds":tG,
          "closure_mean":closure_mean,"closure_max":maxr,
          "jacobi_mean":jac_mean,"jacobi_max":jacmax,
          "killing_proxy":killing_summary}
    with open(os.path.join(args.outdir,"summary.json"),"w") as f: json.dump(meta,f,indent=2)

    with open(os.path.join(args.outdir,"SUMMARY.txt"),"w") as f:
        f.write("Fast 78-basis verification\n")
        f.write(f"Gram build: {tG:.3f}s\n")
        f.write(f"Closure mean {closure_mean:.3e} max {maxr:.3e} (pairs {args.pairs})\n")
        f.write(f"Jacobi  mean {jac_mean:.3e} max {jacmax:.3e} (triples {args.triples})\n")
        if killing_summary:
            f.write(f"Killing proxy rank {killing_summary['proxy_rank_1e-8']}\n")

    import zipfile
    with zipfile.ZipFile(args.bundle_out,'w',compression=zipfile.ZIP_DEFLATED) as z:
        z.write(__file__, arcname=os.path.basename(__file__))
        z.write(os.path.join(args.outdir,"summary.json"), arcname="outputs/summary.json")
        z.write(os.path.join(args.outdir,"SUMMARY.txt"), arcname="outputs/SUMMARY.txt")
        if killing_summary:
            z.write(os.path.join(args.outdir,"killing_proxy.npy"), arcname="outputs/killing_proxy.npy")
    print("Wrote", args.bundle_out)

if __name__=="__main__":
    main()
