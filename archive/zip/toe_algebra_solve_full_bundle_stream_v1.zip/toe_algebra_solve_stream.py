#!/usr/bin/env python3
"""Streamed 'Jacobi-or-die' solver for a 78-dim candidate Lie algebra.

Inputs:
  - D6_basis_66.npy      shape (66,27,27) complex
  - coset_basis_12.npy   shape (12,27,27) complex

Method:
  1) Stack 66+12 -> X[0..77] basis matrices.
  2) Build an orthonormal basis Q for span{vec_reim(X_i)} in R^{1458}.
     Q has shape (1458,78) with orthonormal columns.
  3) For each i, build adjoint matrix Ad_i by batched commutators:
       C_ij = [X_i, X_j]
       coeffs(j,k) = <Q_k, vec(C_ij)>  (projection)
       Ad_i(k,j) = coeffs(j,k)
  4) Diagnostics:
       - closure residual: ||C_ij - proj(C_ij)|| / ||C_ij||
       - Jacobi residual: ||[X_i,[X_j,X_k]] + cyc|| / (||[X_i,[X_j,X_k]]||+...)
       - Killing form: K_ij = tr(Ad_i Ad_j)

Outputs:
  - Ad_all.npy (78,78,78) float64
  - killing_matrix.npy (78,78) float64
  - json summaries and a SUMMARY.txt

This script is built to run inside the ChatGPT sandbox and finish quickly.
"""

import argparse
import json
import os
import time
import numpy as np


def utc_iso():
    import datetime
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + 'Z'


def vec_reim(M: np.ndarray) -> np.ndarray:
    """Vectorize complex matrix into real vector by stacking Re then Im."""
    v = M.reshape(-1)
    return np.concatenate([v.real, v.imag]).astype(np.float64, copy=False)


def stack_vec_reim(X: np.ndarray) -> np.ndarray:
    """X: (n,27,27) complex -> V: (1458,n) float64 with columns vec_reim."""
    n = X.shape[0]
    V = np.empty((2 * 27 * 27, n), dtype=np.float64)
    for i in range(n):
        V[:, i] = vec_reim(X[i])
    return V


def project_coeffs(Q: np.ndarray, V: np.ndarray) -> np.ndarray:
    """Return coefficients for projecting vectors V onto span(Q).

    Q: (m,78) orthonormal cols, V: (m,N) -> coeffs: (78,N)
    """
    return Q.T @ V


def commutator_batch(A: np.ndarray, Bs: np.ndarray) -> np.ndarray:
    """Compute [A,B] for each B in Bs.

    A: (27,27), Bs: (n,27,27) -> Cs: (n,27,27)
    """
    AB = np.einsum('ab,nbc->nac', A, Bs, optimize=True)
    BA = np.einsum('nab,bc->nac', Bs, A, optimize=True)
    return AB - BA


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--d6', default='/mnt/data/e6_basis_export_full_extracted/Newest Work 2_2_2026/artifacts_unified_v3/e6_basis_export_full/D6_basis_66.npy')
    ap.add_argument('--coset', default='/mnt/data/e6_basis_export_full_extracted/Newest Work 2_2_2026/artifacts_unified_v3/e6_basis_export_full/coset_basis_12.npy')
    ap.add_argument('--out', default='/mnt/data/toe_algebra_solve_stream_outputs')
    ap.add_argument('--closure_pairs', type=int, default=800)
    ap.add_argument('--jacobi_triples', type=int, default=800)
    ap.add_argument('--seed', type=int, default=7)
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    t0 = time.time()

    # Load bases
    D6 = np.load(args.d6)
    C12 = np.load(args.coset)
    X = np.concatenate([D6, C12], axis=0)
    assert X.shape[0] == 78 and X.shape[1:] == (27, 27)

    # Build orthonormal basis for span
    V = stack_vec_reim(X)  # (1458,78)
    # QR on tall matrix to get orthonormal columns Q spanning same space
    Q, R = np.linalg.qr(V)  # Q: (1458,78)

    # Pre-stack X for batched operations
    Xs = X

    rng = np.random.default_rng(args.seed)

    # Closure residuals
    closure = []
    for _ in range(args.closure_pairs):
        i = int(rng.integers(0, 78))
        j = int(rng.integers(0, 78))
        if i == j:
            continue
        Cij = Xs[i] @ Xs[j] - Xs[j] @ Xs[i]
        v = vec_reim(Cij)[:, None]
        coeff = project_coeffs(Q, v)  # (78,1)
        vproj = Q @ coeff
        num = np.linalg.norm(v[:, 0] - vproj[:, 0])
        den = np.linalg.norm(v[:, 0])
        rel = float(num / den) if den > 0 else 0.0
        closure.append({'i': i, 'j': j, 'rel_resid': rel})

    # Build all Ad_i and store
    Ad_all = np.memmap(os.path.join(args.out, 'Ad_all.npy'), mode='w+', dtype=np.float64, shape=(78, 78, 78))

    # For vectorization: we'll build comm vectors (78,1458) as float64
    for i in range(78):
        Cs = commutator_batch(Xs[i], Xs)  # (78,27,27)
        Vc = np.empty((2 * 27 * 27, 78), dtype=np.float64)
        # Fill columns with vec_reim(Cs[j])
        for j in range(78):
            Vc[:, j] = vec_reim(Cs[j])
        coeffs = project_coeffs(Q, Vc)  # (78,78) columns correspond to j
        # Ad_i(k,j) = coeffs(k,j)
        Ad_all[i, :, :] = coeffs

    # Killing form K_ij = tr(Ad_i Ad_j)
    # trace(Ad_i Ad_j) = sum_{a,b} Ad_i[a,b] Ad_j[b,a]
    K = np.einsum('iab,jba->ij', Ad_all, Ad_all, optimize=True)
    np.save(os.path.join(args.out, 'killing_matrix.npy'), K)

    # Jacobi residuals: sample triples
    jacobi = []
    for _ in range(args.jacobi_triples):
        i = int(rng.integers(0, 78))
        j = int(rng.integers(0, 78))
        k = int(rng.integers(0, 78))
        if len({i, j, k}) < 3:
            continue
        # nested commutators
        Cjk = Xs[j] @ Xs[k] - Xs[k] @ Xs[j]
        Cki = Xs[k] @ Xs[i] - Xs[i] @ Xs[k]
        Cij = Xs[i] @ Xs[j] - Xs[j] @ Xs[i]
        J = (Xs[i] @ Cjk - Cjk @ Xs[i]) + (Xs[j] @ Cki - Cki @ Xs[j]) + (Xs[k] @ Cij - Cij @ Xs[k])
        vJ = vec_reim(J)
        den = np.linalg.norm(vJ)
        # compare to projected jacobi (should be 0 if Lie)
        coeff = Q.T @ vJ
        vproj = Q @ coeff
        num = np.linalg.norm(vJ - vproj)
        rel = float(num / den) if den > 0 else 0.0
        jacobi.append({'i': i, 'j': j, 'k': k, 'rel_resid': rel, 'norm': float(den)})

    # Killing eigen diagnostics
    evals = np.linalg.eigvalsh((K + K.T) / 2.0)
    abs_e = np.abs(evals)
    tol = 1e-8 * np.max(abs_e) if np.max(abs_e) > 0 else 1e-12
    rank_est = int(np.sum(abs_e > tol))

    # Summaries
    closure_resids = np.array([d['rel_resid'] for d in closure], dtype=float)
    jacobi_resids = np.array([d['rel_resid'] for d in jacobi], dtype=float)

    meta = {
        'timestamp_utc': utc_iso(),
        'basis_paths': {'d6': args.d6, 'coset': args.coset},
        'out_dir': args.out,
        'seed': args.seed,
        'closure_pairs_requested': args.closure_pairs,
        'jacobi_triples_requested': args.jacobi_triples,
    }

    closure_summary = {
        'n': int(len(closure_resids)),
        'max': float(np.max(closure_resids)) if len(closure_resids) else None,
        'p99': float(np.quantile(closure_resids, 0.99)) if len(closure_resids) else None,
        'p95': float(np.quantile(closure_resids, 0.95)) if len(closure_resids) else None,
        'median': float(np.median(closure_resids)) if len(closure_resids) else None,
        'mean': float(np.mean(closure_resids)) if len(closure_resids) else None,
    }

    jacobi_summary = {
        'n': int(len(jacobi_resids)),
        'max': float(np.max(jacobi_resids)) if len(jacobi_resids) else None,
        'p99': float(np.quantile(jacobi_resids, 0.99)) if len(jacobi_resids) else None,
        'p95': float(np.quantile(jacobi_resids, 0.95)) if len(jacobi_resids) else None,
        'median': float(np.median(jacobi_resids)) if len(jacobi_resids) else None,
        'mean': float(np.mean(jacobi_resids)) if len(jacobi_resids) else None,
    }

    killing_summary = {
        'eig_min': float(np.min(evals)),
        'eig_max': float(np.max(evals)),
        'eig_abs_max': float(np.max(abs_e)),
        'rank_est_tol': tol,
        'rank_est': rank_est,
        'eigvals': [float(x) for x in evals],
    }

    with open(os.path.join(args.out, 'meta.json'), 'w') as f:
        json.dump(meta, f, indent=2)
    with open(os.path.join(args.out, 'closure.json'), 'w') as f:
        json.dump({'summary': closure_summary, 'samples': closure[:200]}, f, indent=2)
    with open(os.path.join(args.out, 'jacobi.json'), 'w') as f:
        json.dump({'summary': jacobi_summary, 'samples': jacobi[:200]}, f, indent=2)
    with open(os.path.join(args.out, 'killing.json'), 'w') as f:
        json.dump(killing_summary, f, indent=2)

    # human summary
    summary_txt = os.path.join(args.out, 'SUMMARY.txt')
    with open(summary_txt, 'w') as f:
        f.write('TOE Algebra Solve (streamed)\n')
        f.write(f'Timestamp UTC: {meta["timestamp_utc"]}\n')
        f.write(f'Closure residuals: n={closure_summary["n"]} mean={closure_summary["mean"]} p95={closure_summary["p95"]} max={closure_summary["max"]}\n')
        f.write(f'Jacobi residuals:  n={jacobi_summary["n"]} mean={jacobi_summary["mean"]} p95={jacobi_summary["p95"]} max={jacobi_summary["max"]}\n')
        f.write(f'Killing rank_est={killing_summary["rank_est"]} (tol={killing_summary["rank_est_tol"]})\n')
        f.write(f'Eig min={killing_summary["eig_min"]} max={killing_summary["eig_max"]}\n')
        f.write(f'Elapsed seconds: {time.time()-t0:.2f}\n')

    # flush memmap
    Ad_all.flush()

    # Bundle
    bundle_path = '/mnt/data/toe_algebra_solve_stream_full_bundle.zip'
    import zipfile
    with zipfile.ZipFile(bundle_path, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        z.write('/mnt/data/toe_algebra_solve_stream.py', arcname='toe_algebra_solve_stream.py')
        for fn in os.listdir(args.out):
            z.write(os.path.join(args.out, fn), arcname=os.path.join('outputs', fn))

    print('Wrote bundle:', bundle_path)


if __name__ == '__main__':
    main()
