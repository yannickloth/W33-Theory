import os, json, time, zipfile
import numpy as np

ROOT = "/mnt/data/e6_basis_export_full_extracted/Newest Work 2_2_2026/artifacts_unified_v3/e6_basis_export_full"
OUTDIR = "/mnt/data/toe_algebra_solve_outputs"
os.makedirs(OUTDIR, exist_ok=True)

D6_path = os.path.join(ROOT, "D6_basis_66.npy")
C_path  = os.path.join(ROOT, "coset_basis_12.npy")


def load_array(path: str):
    # try direct load
    try:
        return np.load(path, allow_pickle=False)
    except Exception as e1:
        # fallback: memory-map header
        try:
            return np.load(path, mmap_mode='r', allow_pickle=False)
        except Exception:
            raise RuntimeError(f"Failed to load {path}: {e1}")


def vec_ri(mats: np.ndarray) -> np.ndarray:
    # mats: (n, d, d) complex -> (n, 2*d*d) float
    re = mats.real.reshape(mats.shape[0], -1)
    im = mats.imag.reshape(mats.shape[0], -1)
    return np.concatenate([re, im], axis=1)


def frob_norm_ri(v: np.ndarray) -> float:
    return float(np.linalg.norm(v))


def main():
    t0 = time.time()
    D6 = load_array(D6_path)
    C  = load_array(C_path)
    X = np.concatenate([D6, C], axis=0)  # (78,27,27)
    n, d, _ = X.shape
    meta = {
        "basis_root": ROOT,
        "D6_path": D6_path,
        "C_path": C_path,
        "shape": [int(n), int(d), int(d)],
        "dtype": str(X.dtype),
        "loaded_seconds": time.time() - t0,
    }

    # Build real-imag stacked vectors
    V = vec_ri(X)  # (78, 1458)

    # Orthonormalize basis via QR on transpose (stable for short-fat)
    # We want Q (1458x78) columns orthonormal spanning V^T
    t1 = time.time()
    Q, R = np.linalg.qr(V.T)  # Q: (1458,78)
    meta["orthonorm_seconds"] = time.time() - t1

    # Convert Q to row form for fast projection: B = Q^T (78x1458)
    B = Q.T

    # Helper: project a batch of commutators (m,27,27) into coefficients (78,m)
    def project_coeffs(comm_batch: np.ndarray) -> np.ndarray:
        W = vec_ri(comm_batch)  # (m,1458)
        # coeffs = B @ W^T -> (78,m)
        return (B @ W.T)

    # Closure residual scan
    rng = np.random.default_rng(0)
    pair_count = 400
    pairs = rng.integers(0, n, size=(pair_count, 2))
    residuals = []
    t2 = time.time()
    for i, j in pairs:
        Ci = X[i] @ X[j] - X[j] @ X[i]
        c = (B @ vec_ri(Ci[None, ...]).T).reshape(-1)  # (78,)
        recon = (c @ Q.T).reshape(-1)  # (1458,)
        resid = float(np.linalg.norm(vec_ri(Ci[None, ...]).reshape(-1) - recon))
        residuals.append(resid)
    meta["closure_scan_seconds"] = time.time() - t2

    closure = {
        "pairs_tested": int(pair_count),
        "residual_min": float(np.min(residuals)),
        "residual_median": float(np.median(residuals)),
        "residual_max": float(np.max(residuals)),
        "residual_mean": float(np.mean(residuals)),
        "residuals": residuals[:50],
    }

    # Build adjoint representation (ad_i matrices) using batch matmul
    t3 = time.time()
    # Pre-allocate ad matrices (n, n, n) maybe huge; we'll build Killing directly to save memory.
    # We'll compute Ad_i = coefficients for commutators with all j: Ad_i[:, j] = c_{i j}^k
    # Store in float64
    Ad = np.zeros((n, n, n), dtype=np.float64)

    # batch compute per i
    for i in range(n):
        Xi = X[i]
        left = Xi @ X  # (78,27,27)
        right = X @ Xi
        comm = left - right
        coeffs = project_coeffs(comm)  # (78,78)
        # coeffs[k,j] = c_{i j}^k
        Ad[i] = coeffs

    meta["adjoint_build_seconds"] = time.time() - t3

    # Jacobi test: sample triples
    t4 = time.time()
    triple_count = 500
    triples = rng.integers(0, n, size=(triple_count, 3))
    jac_res = []
    for a,b,c in triples:
        # Use structure constants via Ad to compute Jacobi in coefficient space:
        # J = ad_a(ad_b e_c) + ad_b(ad_c e_a) + ad_c(ad_a e_b) expressed on basis
        # but simpler: compute matrices directly for accuracy
        Xa, Xb, Xc = X[a], X[b], X[c]
        J = Xa @ (Xb@Xc - Xc@Xb) - (Xb@Xc - Xc@Xb) @ Xa \
            + Xb @ (Xc@Xa - Xa@Xc) - (Xc@Xa - Xa@Xc) @ Xb \
            + Xc @ (Xa@Xb - Xb@Xa) - (Xa@Xb - Xb@Xa) @ Xc
        # project and compute residual norm
        vJ = vec_ri(J[None,...]).reshape(-1)
        cJ = (B @ vJ.reshape(1,-1).T).reshape(-1)
        reconJ = (cJ @ Q.T).reshape(-1)
        jac_res.append(float(np.linalg.norm(vJ - reconJ)))

    meta["jacobi_scan_seconds"] = time.time() - t4

    jacobi = {
        "triples_tested": int(triple_count),
        "residual_min": float(np.min(jac_res)),
        "residual_median": float(np.median(jac_res)),
        "residual_max": float(np.max(jac_res)),
        "residual_mean": float(np.mean(jac_res)),
        "residuals": jac_res[:50],
    }

    # Killing form from ad matrices: K_ij = tr(Ad_i @ Ad_j)
    t5 = time.time()
    K = np.zeros((n,n), dtype=np.float64)
    for i in range(n):
        Ai = Ad[i]
        for j in range(i, n):
            val = float(np.trace(Ai @ Ad[j]))
            K[i,j]=K[j,i]=val
    eigvals = np.linalg.eigvalsh(K)
    meta["killing_seconds"] = time.time() - t5

    killing = {
        "eig_min": float(np.min(eigvals)),
        "eig_max": float(np.max(eigvals)),
        "eigvals": [float(x) for x in eigvals],
        "rank_estimate_tol1e-8": int(np.sum(np.abs(eigvals) > 1e-8)),
        "rank_estimate_tol1e-6": int(np.sum(np.abs(eigvals) > 1e-6)),
    }

    # Save outputs
    with open(os.path.join(OUTDIR, "meta.json"), "w") as f:
        json.dump(meta, f, indent=2)
    with open(os.path.join(OUTDIR, "closure.json"), "w") as f:
        json.dump(closure, f, indent=2)
    with open(os.path.join(OUTDIR, "jacobi.json"), "w") as f:
        json.dump(jacobi, f, indent=2)
    with open(os.path.join(OUTDIR, "killing.json"), "w") as f:
        json.dump(killing, f, indent=2)
    np.save(os.path.join(OUTDIR, "killing_matrix.npy"), K)

    # Minimal human-readable summary
    summary = []
    summary.append("TOE algebra solve (matrix commutator closure)")
    summary.append(f"Basis: {n} matrices of size {d}x{d}, dtype={X.dtype}")
    summary.append(f"Closure residual (400 random pairs): min={closure['residual_min']:.3e}, median={closure['residual_median']:.3e}, max={closure['residual_max']:.3e}")
    summary.append(f"Jacobi residual (500 random triples): min={jacobi['residual_min']:.3e}, median={jacobi['residual_median']:.3e}, max={jacobi['residual_max']:.3e}")
    summary.append(f"Killing eigenvalue range: [{killing['eig_min']:.3e}, {killing['eig_max']:.3e}]")
    summary.append(f"Killing rank est: tol1e-8={killing['rank_estimate_tol1e-8']}, tol1e-6={killing['rank_estimate_tol1e-6']}")
    with open(os.path.join(OUTDIR, "SUMMARY.txt"), "w") as f:
        f.write("\n".join(summary) + "\n")

    # Zip: all code + all generated files
    bundle_path = "/mnt/data/toe_algebra_solve_full_bundle.zip"
    with zipfile.ZipFile(bundle_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        z.write(__file__, arcname="toe_algebra_solve.py")
        for fn in sorted(os.listdir(OUTDIR)):
            z.write(os.path.join(OUTDIR, fn), arcname=f"outputs/{fn}")

    print("\n".join(summary))
    print(f"\nWrote bundle: {bundle_path}")


if __name__ == "__main__":
    main()
