This bundle contains the streamed Lie-algebra solver scripts used in the Step-3 'extract the algebra' push.

Files:
  - toe_algebra_solve_stream.py  (fast streamed build: Ad_i, Killing form, closure + Jacobi diagnostics)
  - toe_algebra_solve.py         (non-stream / exploratory variant)

Typical usage (inside this sandbox):
  python toe_algebra_solve_stream.py \
    --d6   /mnt/data/e6_basis_export_full_extracted/Newest\ Work\ 2_2_2026/artifacts_unified_v3/e6_basis_export_full/D6_basis_66.npy \
    --coset /mnt/data/e6_basis_export_full_extracted/Newest\ Work\ 2_2_2026/artifacts_unified_v3/e6_basis_export_full/coset_basis_12.npy \
    --out  /mnt/data/toe_algebra_solve_stream_outputs

Outputs go into the --out directory (Ad_all.npy, killing_matrix.npy, and JSON summaries).
