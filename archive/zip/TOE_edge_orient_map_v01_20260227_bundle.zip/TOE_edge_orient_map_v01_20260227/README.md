Edge orientation mapping bundle

Contains real orientation mapping produced on 2026-02-27.
