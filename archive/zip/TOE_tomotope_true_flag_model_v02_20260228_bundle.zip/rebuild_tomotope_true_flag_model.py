#!/usr/bin/env python3
"""
Rebuild the Tomotope's true 192-flag maniplex model from the published edge generators p0..p3.

This script:
- builds P = <p0,p1,p2,p3> (order 96) on 12 edges,
- reconstructs a canonical 16-face Reye orbit from P acting on 3-subsets,
- identifies a canonical "parallel-pair" matching (one of the three 6-pair orbits on 2-subsets),
- proves the 16 faces are exactly K4 triangles with an odd-parity sheet rule,
- finds a canonical 8-cell decomposition (4 tetrahedra + 4 hemioctahedra),
- builds all 192 flags (v,e,f,c) and involutions r0..r3,
- verifies counts (4,12,16,8), {3,12,4} orders, automorphism order 96, 2 flag orbits,
  and intersection-condition failure (not a C-group).
- writes all deliverables into an output folder.

No web. No external data. Pure computation.
"""

import os, json, math
from itertools import combinations, permutations
from collections import defaultdict, Counter, deque

import networkx as nx

# -----------------------------------------------------------------------------
# Basic permutation utilities
# -----------------------------------------------------------------------------

def perm_from_transpositions_1based(n, transpositions):
    # transpositions: list of (a,b) with 1<=a,b<=n
    p = list(range(n))
    for a,b in transpositions:
        a -= 1; b -= 1
        p[a], p[b] = p[b], p[a]
    return tuple(p)

def perm_comp(p, q):
    # p after q
    return tuple(p[q[i]] for i in range(len(p)))

def gen_group(gens):
    idp = tuple(range(len(gens[0])))
    G = set([idp])
    frontier = [idp]
    while frontier:
        g = frontier.pop()
        for h in gens:
            gh = perm_comp(h, g)
            if gh not in G:
                G.add(gh); frontier.append(gh)
    return sorted(G)

def act_on_subset(p, subset):
    return tuple(sorted(p[i] for i in subset))

def orbit_decomposition(subsets, group):
    unseen = set(subsets)
    orbits = []
    while unseen:
        s = next(iter(unseen))
        orb = set(act_on_subset(g, s) for g in group)
        for t in orb: unseen.discard(t)
        orbits.append(sorted(orb))
    return orbits

# -----------------------------------------------------------------------------
# K4 model helpers
# -----------------------------------------------------------------------------

V4 = [0,1,2,3]
K4_EDGES = [(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)]
EDGE_INDEX = {tuple(sorted(e)): i for i,e in enumerate(K4_EDGES)}
TRIANGLES = set()
for tri in combinations(V4,3):
    tri = tuple(sorted(tri))
    es = [
        EDGE_INDEX[tuple(sorted((tri[0],tri[1])))],
        EDGE_INDEX[tuple(sorted((tri[0],tri[2])))],
        EDGE_INDEX[tuple(sorted((tri[1],tri[2])))]
    ]
    TRIANGLES.add(tuple(sorted(es)))

def blocks_from_matching(matching_pairs):
    pairs = sorted(tuple(sorted(p)) for p in matching_pairs)
    block_of = {}
    for bi,(a,b) in enumerate(pairs):
        block_of[a] = bi
        block_of[b] = bi
    return pairs, block_of

def face_block_triples(faces, block_of_edge):
    return [tuple(sorted(block_of_edge[e] for e in f)) for f in faces]

def test_block_to_k4_mapping(triples, block_to_edgeidx):
    mapped = [tuple(sorted(block_to_edgeidx[b] for b in tri)) for tri in triples]
    if not all(m in TRIANGLES for m in mapped):
        return None
    c = Counter(mapped)
    if set(c.keys()) != TRIANGLES:
        return None
    if not all(c[t]==4 for t in TRIANGLES):
        return None
    return c

def find_k4_models_for_faces(faces, matching_pairs):
    pairs, block_of = blocks_from_matching(matching_pairs)
    triples = face_block_triples(faces, block_of)
    models = []
    for perm in permutations(range(6),6):
        if test_block_to_k4_mapping(triples, perm) is not None:
            models.append(perm)
    return pairs, models

# -----------------------------------------------------------------------------
# Cell search
# -----------------------------------------------------------------------------

def build_face_action(faces, group):
    face_index = {faces[i]: i for i in range(len(faces))}
    face_action = []
    for g in group:
        perm = [None]*len(faces)
        for i,fs in enumerate(faces):
            img = act_on_subset(g, fs)
            perm[i] = face_index[img]
        face_action.append(tuple(perm))
    return face_action

def subset_apply(perm, subset_indices):
    return tuple(sorted(perm[i] for i in subset_indices))

def orbit_of_subset(subset, perms):
    return sorted(set(subset_apply(perm, subset) for perm in perms))

def canonical_orbit(orb):
    return tuple(sorted(tuple(c) for c in orb))

def compute_cell_candidates(faces):
    cells = []
    for cell in combinations(range(len(faces)),4):
        cnt = [0]*12
        for fi in cell:
            for e in faces[fi]:
                cnt[e] += 1
        used = [i for i,c in enumerate(cnt) if c>0]
        if len(used) != 6:
            continue
        if any(c not in (0,2) for c in cnt):
            continue
        cells.append(tuple(cell))
    return cells

def find_canonical_cell_decomposition(faces, group):
    face_action = build_face_action(faces, group)
    cells_candidates = compute_cell_candidates(faces)
    # orbits of cells under P
    orbits_cells = {}
    for cell in cells_candidates:
        orb = orbit_of_subset(cell, face_action)
        orbits_cells[canonical_orbit(orb)] = orb
    cell_orbits = list(orbits_cells.keys())  # each is 4 cells
    decomps = []
    for i in range(len(cell_orbits)):
        for j in range(i+1, len(cell_orbits)):
            union = list(cell_orbits[i]) + list(cell_orbits[j])
            freq = [0]*16
            for cell in union:
                for f in cell:
                    freq[f] += 1
            if all(c==2 for c in freq):
                decomps.append(sorted(tuple(cell) for cell in union))
    decomps = sorted(decomps)
    return decomps[0]  # lexicographically canonical

# -----------------------------------------------------------------------------
# Build ranked incidence and r0..r3
# -----------------------------------------------------------------------------

def build_structure(faces, edge_to_vpair, cells_facesets):
    V = list(range(4))
    E = list(range(12))
    F = list(range(16))
    C = list(range(8))
    VE = set()
    for e in E:
        u,v = edge_to_vpair[e]
        VE.add((u,e)); VE.add((v,e))
    EF = set()
    for fi,face in enumerate(faces):
        for e in face:
            EF.add((e,fi))
    FC = set()
    for ci,faceset in enumerate(cells_facesets):
        for fi in faceset:
            FC.add((fi,ci))
    return V,E,F,C,VE,EF,FC

def flags_from_structure(V,E,F,C,VE,EF,FC):
    E_of_f = defaultdict(set)
    V_of_e = defaultdict(set)
    F_of_c = defaultdict(set)
    for v,e in VE:
        V_of_e[e].add(v)
    for e,f in EF:
        E_of_f[f].add(e)
    for f,c in FC:
        F_of_c[c].add(f)

    flags = []
    for c in C:
        for f in F_of_c[c]:
            for e in E_of_f[f]:
                for v in V_of_e[e]:
                    flags.append((v,e,f,c))
    return flags

def build_r_perms(flags, V,E,F,C,VE,EF,FC):
    idx = {fl:i for i,fl in enumerate(flags)}
    V_of_e = defaultdict(list)
    E_of_f = defaultdict(list)
    C_of_f = defaultdict(list)
    F_of_c = defaultdict(list)
    for v,e in VE:
        V_of_e[e].append(v)
    for e,f in EF:
        E_of_f[f].append(e)
    for f,c in FC:
        C_of_f[f].append(c)
        F_of_c[c].append(f)

    edges_at_vertex_in_face = defaultdict(list)  # (f,v)->edges
    for f in range(16):
        for e in E_of_f[f]:
            for v in V_of_e[e]:
                edges_at_vertex_in_face[(f,v)].append(e)

    faces_at_edge_in_cell = defaultdict(list)   # (c,e)->faces
    for c in range(8):
        for f in F_of_c[c]:
            for e in E_of_f[f]:
                faces_at_edge_in_cell[(c,e)].append(f)

    n = len(flags)
    r0=[None]*n; r1=[None]*n; r2=[None]*n; r3=[None]*n
    for i,(v,e,f,c) in enumerate(flags):
        vs = V_of_e[e]
        v2 = vs[0] if vs[1]==v else vs[1]
        r0[i] = idx[(v2,e,f,c)]

        cs = C_of_f[f]
        c2 = cs[0] if cs[1]==c else cs[1]
        r3[i] = idx[(v,e,f,c2)]

        es = edges_at_vertex_in_face[(f,v)]
        if len(es)!=2:
            raise RuntimeError("bad face/vertex degree", (f,v,es))
        e2 = es[0] if es[1]==e else es[1]
        r1[i] = idx[(v,e2,f,c)]

        fs = faces_at_edge_in_cell[(c,e)]
        if len(fs)!=2:
            raise RuntimeError("bad cell/edge degree", (c,e,fs))
        f2 = fs[0] if fs[1]==f else fs[1]
        r2[i] = idx[(v,e,f2,c)]
    return r0,r1,r2,r3

def verify_involution(p):
    n=len(p)
    for i in range(n):
        j=p[i]
        if j==i or p[j]!=i:
            return False
    return True

def perm_order(p):
    n=len(p)
    seen=[False]*n
    l=1
    for i in range(n):
        if seen[i]: continue
        cur=i; k=0
        while not seen[cur]:
            seen[cur]=True
            cur=p[cur]
            k+=1
        l=l*k//math.gcd(l,k)
    return l

def component_count(n, generators):
    parent=list(range(n))
    def find(x):
        while parent[x]!=x:
            parent[x]=parent[parent[x]]
            x=parent[x]
        return x
    def union(a,b):
        ra,rb=find(a),find(b)
        if ra!=rb: parent[rb]=ra
    for g in generators:
        for i,j in enumerate(g):
            union(i,j)
    return len(set(find(i) for i in range(n)))

def gen_group_on_flags(gens):
    idp=tuple(range(len(gens[0])))
    G=set([idp])
    frontier=[idp]
    while frontier:
        g=frontier.pop()
        for h in gens:
            gh=perm_comp(h,g)
            if gh not in G:
                G.add(gh); frontier.append(gh)
    return G

def build_rank_incidence_graph(V,E,F,C,VE,EF,FC):
    G=nx.Graph()
    for v in V: G.add_node(("V",v), rank="V")
    for e in E: G.add_node(("E",e), rank="E")
    for f in F: G.add_node(("F",f), rank="F")
    for c in C: G.add_node(("C",c), rank="C")
    for v,e in VE: G.add_edge(("V",v),("E",e))
    for e,f in EF: G.add_edge(("E",e),("F",f))
    for f,c in FC: G.add_edge(("F",f),("C",c))
    return G

# -----------------------------------------------------------------------------
# Main reconstruction
# -----------------------------------------------------------------------------

def main(out_dir="OUT_TOMOTOPE_TRUE_FLAG_MODEL"):
    os.makedirs(out_dir, exist_ok=True)

    # Tomotope edge generators from Tomotope.txt (1-based)
    p0 = perm_from_transpositions_1based(12, [(5,10),(6,9),(7,12),(8,11)])
    p1 = perm_from_transpositions_1based(12, [(1,6),(2,5),(3,8),(4,7)])
    p2 = perm_from_transpositions_1based(12, [(5,9),(6,10),(7,11),(8,12)])
    p3 = perm_from_transpositions_1based(12, [(5,8),(6,7),(9,12),(10,11)])
    gens=[p0,p1,p2,p3]
    P = gen_group(gens)
    assert len(P)==96, f"Expected |P|=96, got {len(P)}"

    # Faces: canonical 16-orbit on 3-subsets under P
    subs3=[tuple(s) for s in combinations(range(12),3)]
    orbits = orbit_decomposition(subs3, P)
    faces_orbits = [o for o in orbits if len(o)==16]
    faces_orbits = sorted([sorted(orb) for orb in faces_orbits])
    faces = faces_orbits[0]  # canonical

    # Parallel-pair matching: the lexicographically smallest perfect matching orbit on 2-subsets
    pairs2=[tuple(s) for s in combinations(range(12),2)]
    pair_orbits = orbit_decomposition(pairs2, P)
    matchings=[]
    for orb in pair_orbits:
        if len(orb)==6:
            used=set()
            ok=True
            for a,b in orb:
                if a in used or b in used:
                    ok=False; break
                used.add(a); used.add(b)
            if ok and len(used)==12:
                matchings.append(sorted(orb))
    matchings = sorted(matchings)
    matching_pairs = matchings[0]  # canonical

    # K4 model + sheet parity (odd parity)
    pairs_sorted, models = find_k4_models_for_faces(faces, matching_pairs)
    model = min(models)
    block_to_edgeidx = model
    block_to_vpair = [K4_EDGES[i] for i in block_to_edgeidx]

    # edge metadata
    _, block_of = blocks_from_matching(matching_pairs)
    edge_to_block={e:block_of[e] for e in range(12)}
    edge_to_sheet={}
    for bi,(a,b) in enumerate(pairs_sorted):
        edge_to_sheet[a]=0; edge_to_sheet[b]=1
    edge_to_vpair={e:block_to_vpair[edge_to_block[e]] for e in range(12)}

    # Canonical 8-cell decomposition
    cells_facesets = find_canonical_cell_decomposition(faces, P)

    # Build ranked incidence + flags + r0..r3
    V,E,F,C,VE,EF,FC = build_structure(faces, edge_to_vpair, cells_facesets)
    flags = flags_from_structure(V,E,F,C,VE,EF,FC)
    assert len(flags)==192
    r0,r1,r2,r3 = build_r_perms(flags,V,E,F,C,VE,EF,FC)
    assert all(verify_involution(r) for r in [r0,r1,r2,r3])

    # Counts by components (maniplex definition)
    counts = {
        "vertices": component_count(192, [r1,r2,r3]),
        "edges": component_count(192, [r0,r2,r3]),
        "faces": component_count(192, [r0,r1,r3]),
        "cells": component_count(192, [r0,r1,r2]),
        "flags": 192
    }

    # Coxeter-type product orders
    def comp(p,q): return [p[q[i]] for i in range(len(p))]
    cox_orders = {
        "|r0r1|": perm_order(comp(r0,r1)),
        "|r1r2|": perm_order(comp(r1,r2)),
        "|r2r3|": perm_order(comp(r2,r3)),
        "|r0r2|": perm_order(comp(r0,r2)),
        "|r1r3|": perm_order(comp(r1,r3)),
    }

    # Monodromy group size and intersection condition failure
    r0_t=tuple(r0); r1_t=tuple(r1); r2_t=tuple(r2); r3_t=tuple(r3)
    mono = gen_group_on_flags([r0_t,r1_t,r2_t,r3_t])
    A = gen_group_on_flags([r0_t,r1_t,r2_t])
    B = gen_group_on_flags([r1_t,r2_t,r3_t])
    Csub = gen_group_on_flags([r1_t,r2_t])
    inter = len(set(A).intersection(B))

    # Automorphism group of ranked incidence graph
    G = build_rank_incidence_graph(V,E,F,C,VE,EF,FC)
    nm = nx.algorithms.isomorphism.categorical_node_match("rank", None)
    GM = nx.algorithms.isomorphism.GraphMatcher(G,G,node_match=nm)
    aut_mappings = list(GM.isomorphisms_iter())
    aut_order = len(aut_mappings)

    # Induced edge permutation set
    def induced_edge_perm(mapping):
        perm=[None]*12
        for i in range(12):
            img=mapping[("E",i)]
            perm[i]=img[1]
        return tuple(perm)

    edge_autos = set(induced_edge_perm(m) for m in aut_mappings)

    # Flag orbits under automorphisms
    flag_index={fl:i for i,fl in enumerate(flags)}
    def induced_flag_perm(mapping):
        perm=[None]*len(flags)
        for i,(v,e,f,c) in enumerate(flags):
            v2=mapping[("V",v)][1]
            e2=mapping[("E",e)][1]
            f2=mapping[("F",f)][1]
            c2=mapping[("C",c)][1]
            perm[i]=flag_index[(v2,e2,f2,c2)]
        return tuple(perm)
    flag_autos=[induced_flag_perm(m) for m in aut_mappings]
    unseen=set(range(192)); orbs=[]
    while unseen:
        x=next(iter(unseen))
        orb=set([x]); changed=True
        while changed:
            changed=False
            new=set()
            for y in orb:
                for p in flag_autos:
                    new.add(p[y])
            if not new.issubset(orb):
                orb |= new; changed=True
        for y in orb: unseen.discard(y)
        orbs.append(len(orb))
    orbs=sorted(orbs)

    # -------------------------------------------------------------------------
    # Write outputs
    # -------------------------------------------------------------------------

    with open(os.path.join(out_dir,"tomotope_r_generators_192.json"),"w") as f:
        json.dump({"r0":r0,"r1":r1,"r2":r2,"r3":r3}, f)

    with open(os.path.join(out_dir,"tomotope_edge_group_P_elements.json"),"w") as f:
        json.dump([list(p) for p in P], f)

    with open(os.path.join(out_dir,"REPORT.json"),"w") as f:
        json.dump({
            "counts": counts,
            "coxeter_orders": cox_orders,
            "automorphism_order": aut_order,
            "flag_orbits_under_automorphisms": orbs,
            "monodromy_group_order": len(mono),
            "intersection_condition": {
                "|<r0,r1,r2>|": len(A),
                "|<r1,r2,r3>|": len(B),
                "|<r1,r2>|": len(Csub),
                "|intersection|": inter,
                "satisfies_C_group_intersection_condition": (inter==len(Csub))
            },
            "edge_automorphism_group_matches_P_exactly": (edge_autos==set(P)),
        }, f, indent=2)

    with open(os.path.join(out_dir,"README.txt"),"w") as f:
        f.write(
            "Tomotope true flag model rebuilt.\n"
            f"Counts V,E,F,C,Flags = {counts}\n"
            f"Coxeter-type orders: {cox_orders}\n"
            f"Aut order (rank incidence): {aut_order}\n"
            f"Flag orbits under aut: {orbs}\n"
            f"Monodromy order: {len(mono)}\n"
            f"Intersection sizes: |A|={len(A)} |B|={len(B)} |C|={len(Csub)} |A∩B|={inter}\n"
        )

    print("OK")
    print("Counts:", counts)
    print("Orders:", cox_orders)
    print("Aut order:", aut_order)
    print("Flag orbits:", orbs)
    print("Monodromy order:", len(mono))
    print("Intersection condition satisfied?", inter==len(Csub))

if __name__=="__main__":
    main()
