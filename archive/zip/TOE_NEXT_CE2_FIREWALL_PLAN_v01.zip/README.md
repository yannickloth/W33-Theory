# TOE Next Crack: CE2 / Metaplectic Closure + Edge↔Root Unification

This bundle is a *low-compute* execution plan to replace l9 bucket enumeration with:
1) canonical SU(3) gauge + E6 cubic (already solved in repo),
2) explicit W(E6) signed action on 27 (already exported),
3) firewall Jacobiator audit (quantify anomaly),
4) CE2 global cocycle predictor (table-free) to produce the missing coboundary d(α),
5) re-run Jacobi after CE2 lift (or interpret as L∞ with l3 supported on bad9).

It is written to align with the existing repo scripts.

## The core claim
- Your Z/3 cycling (86,81,81) matches the Z3-grading of E8 under E6×SU(3).
- The remaining “hard part” is *phase coherence* (metaplectic/Weil lift), not enumeration.
- `scripts/ce2_global_cocycle.py` is the table-free law that replaces the bucket stage.

## Run order (minimal)
A. Canonical gauge + cubic:
    python tools/solve_canonical_su3_gauge_and_cubic.py
    python tools/verify_canonical_su3_gauge_and_cubic.py

B. Signed W(E6) on 27:
    python tools/export_we6_signed_action_on_27.py

C. Firewall anomaly:
    python tools/verify_e8_firewall_filtered_bracket_jacobi.py --samples 200000 --seed 1
    python tools/compute_firewall_jacobiator_tensor.py

D. CE2 predictor smoke test:
    python scripts/ce2_global_cocycle.py   (module import should work)
    (Then call explain_predict_ce2_uv(a,b,c) for a few known bad triples)

E. The “closure” test:
    Patch the Z3 bracket builder to add the CE2 correction for the mixed-sector kernels
    (see patch_notes.md), then re-run Jacobi on random triples.

## What success looks like
- Jacobi residuals that were concentrated on mixed-sector triples collapse to ~0 (or become exact),
  while the firewall-filtered deletion remains non-Lie but is explainable as an L∞ selection rule.
