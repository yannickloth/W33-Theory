# Patch Notes: where CE2 fits

## 0) Terminology
- g0 = e6 ⊕ sl3 (dim 86)
- g1 = 27 ⊗ 3 (dim 81)
- g2 = 27bar ⊗ 3bar (dim 81)

Your solver `tools/solve_canonical_su3_gauge_and_cubic.py` produces:
- phase_bits[orbit][e6id]         : fixes basis signs across the 6 mixed 27-orbits
- su3_eps_bits[oa+ob]             : the antisymmetry carrier for the SU(3) epsilon tensor
- d_triples (45 triads)           : symmetric E6 cubic tensor signs (the 27 determinant structure)
- singleton_sign_bits + ladder_const_bits : fixes A2 ladder normalization

These are exactly the ingredients of the canonical Z3-graded E8 bracket:
- g1×g1→g2 uses (phase_bits ⊕ d_triple ⊕ su3_eps ⊕ epsilon_E8 lattice cocycle)
- g2×g2→g1 similarly
- g1×g2→g0 yields e6+sl3 components

## 1) Firewall
The repo’s firewall scripts treat 9 cubic triads as forbidden ("bad9") and zero the corresponding
g1×g1 and g2×g2 couplings. This *must* violate Jacobi; measure it with:

- tools/verify_e8_firewall_filtered_bracket_jacobi.py
- tools/compute_firewall_jacobiator_tensor.py

Interpretation:
- either (a) selection rule ⇒ L∞: add l3 supported on bad9 to satisfy homotopy Jacobi,
- or (b) lift to a larger algebra with additional degrees of freedom so Jacobi holds strictly.

## 2) CE2 global cocycle (the non-enumerative closure)
`scripts/ce2_global_cocycle.py` provides a table-free predictor:

    uv = predict_ce2_uv(a=(e6id, sl3idx), b=(e6id, sl3idx), c=(e6id, sl3idx))

It returns sparse U/V corrections (matrix-unit indices + rational coefficients) in two families:
- simple family: magnitude 1/54, support determined by Heisenberg addition law
- fiber family: magnitude 1/108, supported exactly on the bad9 fibers

This is *exactly* what you need to replace bucketed l8→l9 enumeration:
- l9 is “phase-complete closure”; the phase is the metaplectic/Weil cocycle.
- The predictor computes that cocycle directly.

## 3) Where to apply it
Find the place where the mixed-sector kernel is assembled:
- any script that builds "Weil kernel" or "CE2 lift" terms, or
- the Z3 bracket builder that composes the coupling signs.

Then:
- For each mixed triple (a,b,c) in the bracket’s coupling table, compute uv = predict_ce2_uv(a,b,c).
- Add the sparse correction terms to the corresponding kernel entries BEFORE extracting signs,
  or equivalently, incorporate the implied phase shift into the bracket coefficient.

Minimal approach:
- incorporate CE2 only on the subset of triples that show up in the Jacobiator witness.
- expand coverage once it kills the dominant anomaly.

## 4) Proof obligations (the "crack")
1) show that the CE2 correction cancels the mixed-sector Jacobiator (either exactly or to machine eps)
2) show that the remaining firewall deletion anomaly is supported on bad9 and is cohomologically exact
   in the L∞ sense (so l3 exists and is canonical)

This is finite-dimensional and does NOT require bucket mapping.
