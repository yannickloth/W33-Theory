TOE voltage functor: K-weld Z3 → tomotope triality t4=(r1*r2)^4

This bundle is fully computed from the uploaded repo bundles:
- TOE_tomotope_triality_weld_v01_20260228_bundle.zip (K Schreier voltage on 54-pocket orbit)
- TOE_tomotope_axis_block_twist_v02_20260228_bundle.zip (tomotope monodromy generators in axis coords + 48 incidence blocks)
- TOE_TRIALITY_BRIDGE_v01_20260228_bundle.zip (tomotope t4 block-triple structure)

Main statements:
1) Tomotope:
   t=r1*r2 has order 12, and t4=t^4 has order 3.
   On 192 flags, t4 has 96 fixed points and 32 3-cycles.
   On each r0r3 4-flag block, t4 sends the 4 flags into exactly 3 blocks with
   multiplicity pattern (self:2, other1:1, other2:1), yielding a 48-triangle decomposition.

2) K-weld:
   The Schreier voltage cocycle takes values exp∈Z3.
   A short directed 5-cycle 0→3→13→32→5→0 has voltage sum exp=1.
   The corresponding word [g5,g5,g3,g5,g2] is an order-3 element in the stabilizer of the base pocket
   and generates the C3 “voltage group”.

Functor:
   exp=0 ↦ identity
   exp=1 ↦ apply tomotope t4 once
   exp=2 ↦ apply tomotope t4 twice

Files:
- tomotope_triality_t4_perm_192.json : explicit permutation of the 192 flags
- tomotope_t4_block_split_details.csv : exact block→(3 blocks) split at flag level
- K54_state_transition_table.csv : deterministic automaton (qid,twin) with exp labels
- K_stabilizer_C3_generator_from_cycle.json : explicit C3 generator word from a short cycle
