#!/usr/bin/env python3
import json
from collections import Counter
def compose(p,q): return [p[i] for i in q]
def order(p):
    n=len(p); seen=[False]*n
    import math
    lcm=1
    for i in range(n):
        if not seen[i]:
            j=i; cyc=0
            while not seen[j]:
                seen[j]=True; j=p[j]; cyc+=1
            if cyc:
                lcm=lcm*cyc//math.gcd(lcm,cyc)
    return lcm

t4=json.load(open("tomotope_triality_t4_perm_192.json"))["perm_192"]
print("t4 order:", order(t4))
print("t4 cycle structure:", Counter())

k=json.load(open("K_stabilizer_C3_generator_from_cycle.json"))
print("K stabilizer generator word:", k["stabilizer_word"])
print("cycle voltage:", k["cycle_voltage_sum_mod3"])
