# Dynkin metric sweep fast; see JSON/MD.
