# Dynkin metric sweep (fast) with Killing proxy

- tol=1e-08, stabilizer_count=82
- cartan_rank=6
- eps_root=0.0002, Bsub=150, root_clusters=19
- best_score=10

## Best rounded Cartan matrix
- [2, -1, 0, 0, 0, 0]
- [-1, 2, 0, -1, 1, 0]
- [-1, 0, 2, -1, -1, 0]
- [0, -1, -1, 2, -1, 0]
- [0, 1, 0, -1, 2, 0]
- [0, 0, 0, 0, 0, 2]

- simple_root_indices: [16, 10, 7, 17, 15, 12]

## Next
- If score==0: output Dynkin edges and verify root count 72 by improved clustering.
- If score>0: run eps_root sweep with 1e-4/3e-4 and pick best.
- If still >0: improve Cartan commuting basis by swap-search.
