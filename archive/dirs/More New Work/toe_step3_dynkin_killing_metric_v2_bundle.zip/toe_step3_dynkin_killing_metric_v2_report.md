# Dynkin lock with Killing-form proxy metric v2

- tol=1e-08, stabilizer_count=82, cartan_rank=6
- root_clusters=19, eps_root=0.0002
- best_score=10

## Best rounded Cartan matrix
- [2, -1, 0, 0, 0, 0]
- [-1, 2, 0, -1, 1, 0]
- [-1, 0, 2, -1, -1, 0]
- [0, -1, -1, 2, -1, 0]
- [0, 1, 0, -1, 2, 0]
- [0, 0, 0, 0, 0, 2]

- simple_root_indices: [16, 10, 7, 17, 15, 12]

## Interpretation
- This pass uses an empirical Killing-form proxy metric to compute Cartan entries, which should fix Euclidean distortions.
- If best.score==0 now, that's the Dynkin-level E6 confirmation.
- If still >0, remaining issue is root clustering resolution; next is multi-eps sweep and clustering by k-means in Cartan metric.
