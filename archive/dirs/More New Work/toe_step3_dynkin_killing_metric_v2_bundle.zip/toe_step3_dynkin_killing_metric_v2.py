# Dynkin killing metric v2; see JSON/MD.
