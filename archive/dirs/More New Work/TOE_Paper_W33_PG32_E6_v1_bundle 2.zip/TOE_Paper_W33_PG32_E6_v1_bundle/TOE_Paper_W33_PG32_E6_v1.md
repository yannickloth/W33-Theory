# A Computable TOE Kernel from W(3,3): Double-Six, Firewall, PG(3,2), and an E6 Algebra (v1)

**Date:** 2026-02-03  
**Status:** Working paper; computationally verified invariants with reproducible pipeline artifacts.

---

## Abstract

We present a compact, **computable kernel** that links a concrete combinatorial geometry to an exceptional symmetry algebra. Starting from the **Schläfli graph** on 27 vertices, we establish a chain of verified invariants: (i) 72 maximal K6 cliques pairing into 36 **double-sixes**, with stabilizer **S₆×ℤ₂**; (ii) an interaction constraint (“firewall”) that splits H27 non-orthogonality pairs as **243 = 216 allowed + 27 forbidden**; (iii) identification of the “remaining 15” (outside a reference double-six) with **PG(3,2)** via the canonical K₆-edge/duad model; and (iv) an **E6 Dynkin diagram** locked by a rank-6 Cartan extracted from the cubic stabilizer, producing a Cartan matrix score 0 under a Killing-metric proxy.

We further show that ℤ₃ actions of type (abc)(def) on the K₆ letters induce **PG(3,2) spreads** (five disjoint lines covering all 15 points), providing an explicit A₂/SU(3) control mechanism inside the kernel. All key claims are backed by runnable scripts and exported artifacts.

---

## 1. Executive summary (what is *proved* by computation)

### 1.1 Schläfli graph / E6 combinatorics
Verified on the 27-vertex Schläfli graph:
- **72** K6 cliques
- **36** double-sixes (pairing of K6 cliques)
- stabilizer of a double-six: **S₆×ℤ₂** (order 1440; observed as (720, swap_ok=True))

### 1.2 Firewall constraint (interaction law)
Inside the H27 sector, the non-orthogonality pairs split exactly:
- total non-orth pairs in H27: **243**
- kernel edges: **216**
- forbidden (“bad”) edges: **27**

### 1.3 The “remaining 15” is PG(3,2)
For a reference double-six, the remaining vertices form:
- |remaining15| = **15 = C(6,2)**
- Identified with points of **PG(3,2)** via the K₆-edge/duad model:
  - points = 15 duads {i,j}
  - lines = 35 triples = 20 triangle-lines + 15 matching-lines
  - incidence check: every point lies on 7 lines

### 1.4 E6 Dynkin lock (Cartan rank 6 + score 0)
From the cubic stabilizer derived in the pipeline:
- A rank-6 commuting Cartan exists (tol=1e-8 regime)
- Dynkin diagram locks with **Cartan score 0** (E6 graph isomorphic)

### 1.5 A₂/SU(3) as ℤ₃ spreads on PG(3,2)
Every ℤ₃ of type (abc)(def) on K₆ letters partitions the 15 points into:
- 5 orbits of size 3, each orbit a PG(3,2) line
- hence a **5-line spread** covering all 15 points
We identify “best” ℤ₃ generators maximizing tri-colored line behavior and correlate Dynkin node channels to these spreads across **all 36** double-sixes.

---

## 2. Objects and definitions

### 2.1 Schläfli graph (27 vertices)
Let S be the Schläfli graph on 27 vertices with strongly regular parameters (27,16,10,8).

### 2.2 Double-six
A **double-six** is a pair of 6-cliques (L,M) with the Schläfli incidence pattern matching the classical double-six configuration. We treat L and M as two disjoint 6-sets and keep the canonical L→M matching.

### 2.3 Firewall split
Given the H27 sector and the non-orthogonality relation, define:
- **kernel edges:** allowed interactions
- **bad edges:** forbidden interactions

Empirically and in the verification script, the split is exact: 243 = 216 + 27.

### 2.4 Remaining15 and duad labeling
Given a reference double-six (L,M), the remaining vertices R = V \ (L ∪ M) have |R|=15. A canonical S₆ action labels R as **duads** {i,j} (edges of K₆), i.e. elements of C(6,2).

### 2.5 PG(3,2) (projective 3-space over F₂)
We realize PG(3,2) as:
- points = 15 edges of K₆
- lines = 35 triples, partitioned into:
  - triangle-lines: edges of a triangle (i,j),(j,k),(k,i)
  - matching-lines: a perfect matching (ab,cd,ef)

---

## 3. Axioms of the kernel (minimal set)

**A1 (Geometry):** The state space includes the Schläfli graph S on 27 vertices.

**A2 (Clique structure):** S contains 72 K6 cliques pairing into 36 double-sixes.

**A3 (Firewall):** In H27, the non-orthogonality pairs split as 243 = 216 kernel + 27 bad.

**A4 (Duad kernel):** For any double-six, the remaining15 vertices carry a canonical S₆ action and admit labeling as C(6,2).

**A5 (Cubic stabilizer):** A structured cubic form on 27 variables exists whose stabilizer yields a rank-6 Cartan and an E6 Dynkin lock.

**A6 (A2 seed):** ℤ₃ actions of type (abc)(def) act on the duad kernel and induce PG(3,2) spreads.

These axioms are not assumed abstractly—they are **verified computationally** by the pipeline and artifacts.

---

## 4. Theorems (kernel-level consequences)

**T1 (Double-six count and stabilizer).**  
S has 36 double-sixes; the stabilizer of a reference double-six is S₆×ℤ₂.

**T2 (Firewall theorem, exact count).**  
Within H27: total non-orth pairs = 243 split as 216 allowed + 27 forbidden.

**T3 (Remaining15 = PG(3,2)).**  
Remaining15 is canonically C(6,2), hence isomorphic to PG(3,2) points, with 35 lines realized as triangle + matching triples.

**T4 (E6 Dynkin lock).**  
The cubic stabilizer admits a rank-6 Cartan; the recovered Cartan matrix has score 0 against E6 invariants, yielding an E6 Dynkin graph.

**T5 (A2/SU(3) spreads).**  
Each ℤ₃ of type (abc)(def) yields a 5-line spread of PG(3,2) (partition of 15 points into five disjoint lines).

**T6 (Stable correlation across 36 double-sixes).**  
Dynkin node channel families exhibit stable correlations with matching-line vs triangle-line motions and with ℤ₃ spreads, measured across all 36 double-sixes.

---

## 5. Computational verification and reproducibility

### 5.1 One-command pipeline
Run:
- `python toe_unified_pipeline_v3.py`

to regenerate:
- Schläfli counts, double-sixes, stabilizer
- firewall split 216/27/243
- E6 Dynkin lock artifacts

### 5.2 Core artifacts (generated)
Key output families (under `artifacts_unified_v3/`):
- `UNIFIED_REPORT_V3.json`, `summary.md`
- `dynkin_edges.json`
- `dynkin_node_generator_map_exact.*`
- `dynkin_channel_dictionary.*`
- `pg32_points_from_remaining15.*`, `pg32_lines_from_remaining15.*`
- `pg32_dynkin_all36_atlas_exact.*`
- `pg32_su3_a2_z3_actions.*`
- `dynkin_vs_su3_spread_all36.*`

---

## 6. Interpretation: “life is a protocol”
This kernel suggests an interpretation in which:
- **interaction is permissioned** by a firewall constraint (selection rules),
- **symmetry is emergent** as the stabilizer of a computable cubic (E6),
- **information routing** on PG(3,2) is controlled by spreads (A2/SU(3)),
- and the double-six structure supplies a canonical symmetry-breaking backbone (S₆×ℤ₂).

---

## 7. Next steps (paper v2 roadmap)
1) Present a canonical identification of SU(3)×SU(3)×SU(3) inside the channel dictionary.
2) Upgrade the Dynkin generator mapping to a basis presentation with commutator relations.
3) Tighten the “physics dictionary”: map ε/firewall/bad edges to recognizable selection rules.

---

## Appendix A: Reference file map

This working repo’s recent deltas include:
- Dynkin lock: `dynkin_lock_killing_parametric_v2.py`, `dynkin_lock_best.json`
- Exact Dynkin→generator map: `dynkin_node_generator_map_exact.*`
- PG(3,2) build: `pg32_points_from_remaining15.*`, `pg32_lines_from_remaining15.*`
- ℤ₃ spreads: `pg32_su3_a2_z3_actions.*`
- All-36 atlas: `pg32_dynkin_all36_atlas_exact.*`, `dynkin_vs_su3_spread_all36.*`
