This bundle certifies a minimal extension operator that couples the 14 Lie-singlet coordinates to the active sector
WITHOUT activating any Schläfli edges with Δw=0 (the firewall edges).

Inputs:
- toe_candidate_cubic_tensor_sym3_robust.npy (27×27×27 cubic Sym^3 tensor candidate)
- schlafli_edges_216_in_joint_eigenbasis.csv + Cartan weights (to define Δw=0)
- Lie-allowed Schläfli edges = in_root_support (45) ∪ special two-step edges (4) = 49 total.

Construction:
- Build a mask on Schläfli edges excluding Δw=0 edges (151 undirected edges).
- Choose slice k=7, form Hermitian part: M_sym = (T[:,:,k] + T[:,:,k]^†)/2
- Extension generator: M_ext = mask ⊙ M_sym

Certified properties (tol=1e-09):
- Support(M_ext) on Schläfli edges = ALL 151 nonblocked edges.
- Leakage onto blocked Δw=0 Schläfli edges = 0 exactly.
- New Schläfli edges activated beyond Lie-allowed set = 102 (see new_edges_activated_102.csv).

Files:
- extension_generator_Mext.npy : the masked Hermitian extension generator (27×27)
- schlafli_nonblocked_mask.npy : the 27×27 Schläfli mask (1 on nonblocked edges, else 0)
- new_edges_activated_102.csv  : the 102 previously-unsupported nonblocked Schläfli edges and amplitudes
- summary.json : counts and parameters
