This folder provides an explicit labeling of your extracted kernel Lie algebra generators in a standard B6 (so(13)) root system.

Key files:
- B6_root_label_to_kernel_generator_map.json: maps each standard root label (±e_i, ±e_i±e_j) to:
    eig_index in roots_72.csv, generator_index in root_generators_72.npy, Cartan coordinates, and short/long.
- B6_standard_simple_roots_map.json / B6_standard_simple_roots.csv: the 6 standard simple roots (alpha1..alpha6) as roots in your Cartan basis, with matching generator indices.
- B6_perm_to_standard.json: permutation mapping between your extracted simple-root ordering and standard B6 ordering.

To fetch the actual generator matrix for a labeled root:
    X = root_generators_72.npy[ generator_index ]
