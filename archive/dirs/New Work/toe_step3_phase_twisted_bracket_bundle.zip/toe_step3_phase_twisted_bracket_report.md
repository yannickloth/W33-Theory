# Step 3: phase-twisted sl9 bracket (clock-parity structure constants)

Z2 twist on sl9 structure constants using measured k6 triangle parity: sign = (-1)^{k6_sum mod 2} on the closing bracket [E_ij, E_jk] -> E_ik.

## Results
- twisted_full_dim_support: 80
- twisted_restricted_dim_support: 80
- full_expected: 80
- restricted_generators_removed: 18
- negative_signed_commutator_events: 504

## Interpretation
- If the twisted bracket closure in the restricted generator set yields dimension 78, that strongly suggests an E6-like algebra emerging from phase-twisted structure constants.
- If it remains far from 78, we likely need the full Q8/Z6 phase (not just parity) as the twist, or must restrict by the exact firewall witness rule instead of only epsilon translation pairs.
- The negative commutator event count measures how much nontrivial twisting is present in the structure constants.

## Next
- Upgrade twist from Z2 parity to full Z6 phase class (keep coefficients in cyclotomic field) and compute rank of span numerically.
- Apply exact firewall restriction (bad witness) to generator set in addition to epsilon restriction and re-run closure.
- Compute automorphism group of the resulting signed commutator graph and compare to E6 Weyl group generators.
