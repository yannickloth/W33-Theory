# Generated in-chat; see JSON/MD for results.
