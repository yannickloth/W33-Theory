# Field dictionary atlas: state projections and edge shared-pattern statistics

## Edge-level shared-pattern stats
- attempted_nonorth: n=540, shared_abs_mean=0.4117, sec_overlap_mean=0.2075
- authenticated_N180: n=180, shared_abs_mean=0.4117, sec_overlap_mean=0.2075
- firewalled_bad: n=27, shared_abs_mean=0.4117, sec_overlap_mean=0.2075
- schlafli_edges: n=216, shared_abs_mean=0.4117, sec_overlap_mean=0.2075

See JSON for top example pairs and per-state field vectors.
