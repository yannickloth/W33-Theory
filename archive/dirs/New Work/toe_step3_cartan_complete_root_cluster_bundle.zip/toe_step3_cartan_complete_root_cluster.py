# Cartan completion and root clustering; see JSON/MD.
