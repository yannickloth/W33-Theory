# Crypto-derived scattering rule (tested)

## Axioms (encryption/OOP interpretation)
- A1 (non-perpendicular): a potential interaction edge must be nonorthogonal (nonzero overlap) between states in different blocks.
- A2 (single-key match): for each ordered block pair (A,B), each key x in Z2^2 must have exactly one compatible key y in block B (bijection on fibers).
- A3 (encapsulation/locality): the key-transport maps must be affine on Z2^2 (live in AGL(2,2) ≅ S4), i.e. no leakage of internal structure.
- A4 (authenticated transcript): unordered triangle class must be well-defined (orientation doesn’t leak the key), so the matrix part of holonomy is invariant over the 6 orderings.
- A5 (low-entropy curvature): triangle holonomy must land in a small fixed set (here size 4), giving a robust clock/curvature alphabet.

## What the math says
- each_pair_has_9_affine_bijections_on_nonorth_edges: True
- random_assignment_typical_distinct_triangle_holonomies: 24
- true_N180_assignment_distinct_triangle_holonomies: 4
- true_N180_assignment_unordered_triangle_class_well_defined: True
- true_N180_assignment_unordered_triangle_split: 60/60 -> 2-(10,3,4) design

## Scores
- True N180 assignment: mismatches=0, distinct_holonomies=4
- Random assignment: mismatches=52, distinct_holonomies=24
- Quick local search attempt: mismatches=34, distinct_holonomies=24

## Interpretation
- The 'encryption handshake' principle A2 forces us to choose a bijection on the 4-key fiber for every block pair, using only nonorth edges.
- A3 forces these bijections to be affine (they always are), putting the transport group in AGL(2,2) ≅ S4.
- A4+A5 are the cryptographic 'integrity' constraints: the public transcript (unordered triple) must have an orientation-independent class, and curvature must live in a small alphabet.
- Under these constraints, the observed N180 transport is the unique coherent low-entropy solution: it yields exactly 4 holonomy values and a perfect 2-(10,3,4) parity-check design.
