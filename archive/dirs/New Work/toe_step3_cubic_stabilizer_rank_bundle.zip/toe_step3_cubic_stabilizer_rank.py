# Compute stabilizer rank from cubic residual filter; see JSON.
