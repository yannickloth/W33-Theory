# Cubic stabilizer → Lie algebra rank estimate

- stabilizer_count: 82/82
- estimated rank: 139
- gap to 78: 61

## Top offenders
- {'index': 80, 'name': 'cartan', 'residual': 6.387730341916376e-31}
- {'index': 74, 'name': 'cartan', 'residual': 4.227392718042966e-31}
- {'index': 77, 'name': 'cartan', 'residual': 4.2032452428906345e-31}
- {'index': 75, 'name': 'cartan', 'residual': 4.199395263792821e-31}
- {'index': 81, 'name': 'cartan', 'residual': 4.16905857578454e-31}
- {'index': 76, 'name': 'cartan', 'residual': 4.1654610928732835e-31}
- {'index': 46, 'name': 'edge', 'residual': 4.1561775086882294e-31}
- {'index': 79, 'name': 'cartan', 'residual': 2.230797225459438e-31}
- {'index': 78, 'name': 'cartan', 'residual': 4.9909726894388094e-33}
- {'index': 44, 'name': 'edge', 'residual': 0.0}
- {'index': 45, 'name': 'edge', 'residual': 0.0}
- {'index': 42, 'name': 'edge', 'residual': 0.0}
- {'index': 47, 'name': 'edge', 'residual': 0.0}
- {'index': 56, 'name': 'edge', 'residual': 0.0}
- {'index': 49, 'name': 'edge', 'residual': 0.0}

## Interpretation
- If rank_estimate is near 78, we've pinned the E6 Lie algebra as the stabilizer of the SU(3)^3-structured cubic on the 27 representation.
- If rank_estimate is higher, the threshold is too loose or the extracted generator set includes non-stabilizer directions; tighten threshold and repeat.
- If rank_estimate is lower, we may be missing stabilizer generators (need include additional Cartan directions or recompute alpha with full generator constraints).

## Next
- Tighten threshold (e.g. 1e-10) and recompute stabilizer rank.
- Compute rank estimate on offenders-only set to understand which extra directions are being excluded.
- Map stabilizer generators back to block pairs to interpret symmetry breaking / sector structure.
