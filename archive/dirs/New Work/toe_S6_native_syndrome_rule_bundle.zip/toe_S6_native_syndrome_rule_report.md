# S6-native syndrome rule for odd triples (2-(10,3,4))

## Rule
The triangle syndrome is odd (swap holonomy class) iff (i12+i13+i23) mod 2 = 0. Equivalently, the multiset of pairwise intersections is either (2,2,2) or (1,1,2), and the membership-pattern count multiset is (2,1,1,1,1).

Odd triple intersection multisets: [(1, 1, 2), (2, 2, 2)]
Odd triple pattern counts sorted: [(1, 1, 1, 1, 2)]

## Caveat (transport labels)
- All pairs of distinct 3+3 bipartitions have the same unordered intersection signature (1,1,2,2).
- Therefore the directed Pauli translation labels t_AB are not determined by bipartitions alone; they constitute an additional chosen connection (routing table) on the S6 object model.
