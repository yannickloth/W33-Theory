# Minimal effective field theory on sectors (low-rank field extraction)

We fit the *selection-rule deltas* as sums of rank-1 field couplings.

## Fit quality
- Authenticated delta (rank-2): fro=5.6e-17, max|err|=2.475e-17, mean|err|=7.774e-18
- Firewall delta (rank-1):     fro=3.904e-16, max|err|=1.698e-16, mean|err|=4.731e-17

## Extracted fields
- **G_auth_mode1**: lambda=-1.20851e-15
- **M_auth_mode2**: lambda=4.33352e-16
- **C_block_mode**: lambda=-9.52274e-16

## Sector charge vectors (normalized to max abs = 1 per field)
Columns: [G_auth_mode1, M_auth_mode2, C_block_mode]
- E0: [0.07677755248763925, -0.3810888675528752, 0.08404086387521188]
- E1: [0.36968156257987445, 0.06662110140865012, 0.40454224302768604]
- E2: [-1.0, 1.0, -1.0]
- E3: [0.8287866886470768, 0.6304639697886409, 0.7062688551308531]
- E4: [0.7515318478766775, 0.5168314619947193, 0.6603460193226623]
- E5: [0.40828563299804943, 0.22948401947757843, 0.40491217839685456]

## How to read this
- The first two modes span the authenticated selection structure (who gets amplified by N180 relative to raw contact).
- The third mode is the dominant firewall pressure (who gets preferentially blocked by E6 bad relative to raw contact).
- A sector with large |G| behaves router/gauge-like; large |M| behaves endpoint/matter-like; large |C| behaves firewalled/constraint-like.
