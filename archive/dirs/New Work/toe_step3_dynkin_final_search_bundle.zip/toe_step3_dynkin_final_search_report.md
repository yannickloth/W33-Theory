# Dynkin final search (E6 Cartan matrix match)

- tol=1e-08, stabilizer_count=82
- cartan_rank=6, root_clusters=19, eps_root=0.0002
- trials=2500, best_score=13

## Best rounded Cartan matrix
- [2, 0, -1, 0, -1, -1]
- [0, 2, 0, 0, 0, 0]
- [-1, 0, 2, -1, -1, 0]
- [0, 0, -1, 2, 1, -1]
- [0, 0, -1, 1, 2, 0]
- [0, 0, 0, -1, 0, 2]

- simple_root_indices: [7, 12, 17, 10, 15, 16]

## Interpretation
- If best.score==0 and C_round matches an E6 Cartan matrix pattern (diag 2, -1 links), then we have a Dynkin-level confirmation of E6.
- If score>0 but small, increase trials/topN or tune eps_root; the structure is present but simple root selection needs refinement.
- If cartan_rank<6, adjust stabilizer tolerance or improve commuting search.

## Next
- If best.score==0: output Dynkin edges, then verify root count approaches 36 mod sign (72 total).
- If score>0: run a local search (swap one root at a time) to improve score.
- Map simple roots back to stabilizer generators via which commutator entries produce those root differences.
