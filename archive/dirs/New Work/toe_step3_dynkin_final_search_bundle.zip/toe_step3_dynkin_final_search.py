# Dynkin final search; see JSON/MD.
