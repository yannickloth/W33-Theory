# Closure residual test for stabilizer basis; see JSON/MD.
