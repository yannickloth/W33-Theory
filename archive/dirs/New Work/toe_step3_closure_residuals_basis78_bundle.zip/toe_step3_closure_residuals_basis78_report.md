# Closure residual test on stabilizer basis (up to 78)

- chosen_tol: 1e-12
- stabilizer_count: 82
- basis_size: 78

## Residual stats (||[Xi,Xj] - proj||)
- mean: 0.163409
- std: 0.448977
- min: 0
- max: 1.41421
- p90: 1.41421
- p99: 1.41421

## Top residual pairs
- resid=1.414e+00 pair=[('edge', 4, 12), ('cartan', 3)] top=[]
- resid=1.414e+00 pair=[('cartan', 0), ('edge', 0, 11)] top=[]
- resid=1.414e+00 pair=[('edge', 7, 20), ('edge', 7, 18)] top=[]
- resid=1.414e+00 pair=[('cartan', 2), ('edge', 2, 24)] top=[]
- resid=1.414e+00 pair=[('cartan', 3), ('edge', 4, 12)] top=[]
- resid=1.414e+00 pair=[('edge', 2, 14), ('edge', 2, 4)] top=[]
- resid=1.414e+00 pair=[('edge', 8, 12), ('edge', 4, 12)] top=[]
- resid=1.414e+00 pair=[('edge', 2, 20), ('cartan', 2)] top=[]
- resid=1.414e+00 pair=[('edge', 5, 9), ('edge', 1, 5)] top=[]
- resid=1.414e+00 pair=[('edge', 4, 17), ('edge', 4, 12)] top=[]

## Interpretation
- Closure residuals measure how well commutators of stabilizer basis elements remain inside the stabilizer span (numerically).
- If residuals are near 0 (especially p99), the basis is close to a Lie subalgebra: we can trust the presentation and proceed to Dynkin extraction.
- If residuals are large, we need either a larger basis, a tighter tolerance, or to include missing stabilizer directions (e.g., more Cartan).

## Next
- If closure residuals are small, compute an approximate Cartan by greedy commuting set search and then recover root decomposition by eigenvalue differences.
- If not, increase basis size to full stabilizer and repeat closure residual test.
- Map top residual pairs back to generator types (edge vs cartan) to see where closure fails.
