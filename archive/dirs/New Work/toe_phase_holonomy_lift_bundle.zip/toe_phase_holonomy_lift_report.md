# Phase holonomy lift: from Z2 curvature to Z6/Z3 Bargmann phases

## Transport connections
- N180 defines a unique transport between blocks (connection).
- Each transport is affine in AGL(2,2).

## Triangle holonomy (connection curvature)
- M=[[1, 0], [0, 1]], t=[1, 0]: count 180
- M=[[0, 1], [1, 0]], t=[0, 0]: count 180
- M=[[0, 1], [1, 0]], t=[1, 1]: count 180
- M=[[1, 0], [0, 1]], t=[0, 1]: count 180

## Bargmann phase holonomy on canonical N180 triangles
Phase values (quantized to nearest multiple of pi/3):
- (1+0j): 160
- (0.5+0.8660254038j): 137
- (0.5-0.8660254038j): 137
- (-0.5+0.8660254038j): 53
- (-0.5-0.8660254038j): 53

Phase by Z2 class (0=matrix I, 1=matrix swap):
- class 0: {(1+0j): 160, (0.5+0.8660254038j): 100, (0.5-0.8660254038j): 100}
- class 1: {(-0.5+0.8660254038j): 53, (0.5-0.8660254038j): 37, (-0.5-0.8660254038j): 53, (0.5+0.8660254038j): 37}

Z3 reduction by class:
defaultdict(<class 'collections.Counter'>, {0: Counter({0: 160, 1: 100, 2: 100}), 1: Counter({2: 90, 1: 90})})

## Key insight
- The N180 relation defines a unique affine transport map between any ordered block pair, giving a connection valued in AGL(2,2).
- Triangle holonomy takes 4 affine values uniformly (180 each), yielding the same Z2 topological charge (matrix=I vs swap) as before.
- Using the N180 transport to pick a canonical triple of nonorth states across blocks, the Bargmann 3-cycle phase takes values in 6th roots of unity (subset).
- The Z2 holonomy class controls the phase distribution: class-1 triangles never yield phase 1 (Z3 class 0), while class-0 triangles do.
- Therefore the Z2 design curvature is a reduction/selection rule of a richer Z6 (and Z3) phase holonomy.
