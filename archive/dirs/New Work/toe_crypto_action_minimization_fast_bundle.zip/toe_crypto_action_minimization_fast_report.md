# Fast crypto-action minimization (incremental annealing)

Energy: E = 10*parity_mismatch + |distinct_hol-4| + 0.2*|distinct_t-2|

Best found: {'E': 258.4, 'parity_mismatch': 24, 'distinct_hol': 22, 'distinct_t': 4}
True assignment: {'E': 0.4, 'parity_mismatch': 0, 'distinct_hol': 4, 'distinct_t': 4}
Pair matches vs true: 3/45

- This is a crypto-style action minimization over the 9^45 handshake space, optimized incrementally (only 48 ordered triples and 8 unordered triples affected per edge flip).
- If best_found reaches parity_mismatch=0 and distinct_hol=4, we have reconstructed the global integrity structure from encryption axioms.
- Pairwise agreement with the true assignment is a stronger check; multiple global minima may exist up to gauge/renaming.
