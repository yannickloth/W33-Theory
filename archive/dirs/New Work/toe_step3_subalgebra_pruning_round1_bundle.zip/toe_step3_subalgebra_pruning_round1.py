# Subalgebra pruning round 1; see JSON/MD for details.
