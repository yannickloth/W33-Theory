# Step 3: subalgebra pruning round 1 (energy-based)

- pruned edges: 7/74
- gens total after prune (incl cartan): 75
- holdout ratio (hold/train): 1.141

## Holdout means
- train_mean: 1.88801
- hold_mean: 2.15458

## Interpretation
- If ratio_hold_train moves toward 1 compared to the unpruned subalgebra holdout test, pruning is isolating a truer invariant subalgebra.
- If ratio worsens, the pruned generators were essential and we should instead prune by commutator-rank contribution or ε-grading violations.

## Next
- Iterate pruning for 2–3 rounds (small prune each time) while monitoring ratio trend.
- Switch pruning criterion from single-generator energy to 'marginal effect on holdout energy' (leave-one-out).
- Once ratio stabilizes near 1, attempt sparsification/basis change to approach a 45-term cubic.
