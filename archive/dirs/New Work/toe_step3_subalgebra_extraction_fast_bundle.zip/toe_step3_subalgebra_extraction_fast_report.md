# Step 3: fast subalgebra extraction toward E6 (projected-rank + one-shot commutator rank)

- selected edges: 74
- eps edge counts: {0: 55, 1: 19}
- one-shot commutator rank estimate: 120

## Notes
- The projected-rank selection is a fast proxy; the commutator-rank estimate is the real check.
- Next: run the Sym^3 cubic invariant hunt on this extracted generator subset.
