# Fast subalgebra extraction; see JSON/MD for results.
