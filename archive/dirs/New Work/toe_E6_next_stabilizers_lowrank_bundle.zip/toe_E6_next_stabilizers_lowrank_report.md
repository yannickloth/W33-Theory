# E6 follow-through: stabilizers and low-rank structure of the Schläfli cut

## Ranks and spectra
- rank(nonedge_sub) = 19
- rank(bad) = 27
- rank(S_schlafli) = 27

Spectra (eigenvalue -> multiplicity):
- bad: {'-1.0': 18, '2.0': 9}
- S: {'-2.0': 20, '4.0': 6, '16.0': 1}
- nonedge_sub: {'-3.0': 12, '-0.0': 8, '3.0': 6, '18.0': 1}

## bad decomposition in rank-6 span on H27
- basis: ['I', 'J', 'E20', 'E40', 'E180', 'N180', 'N360']
- coeff (LS): [0.0, 0.037037, -0.037037, -0.037037, -0.037037, 0.074074, 0.074074]
- residual Fro norm: 6.9282

## Commutator norms
- ||[bad,S]||: 0
- ||[bad,nonedge]||: 0
- ||[bad,N180]||: 20.7846
- ||[bad,N360]||: 20.7846

## Stabilizers inside H (720)
- H_order: 720
- H_fix_v: 18
- H_preserve_H27_set: 18
- H_preserve_Schlafli_graph: 18
- H_preserve_bad_predicate: 18

## Notes
- The Schläfli cut uses an extra predicate 'bad' (ch12=4) not expressible exactly as a linear combination of the restricted rank-6 relations (nonzero residual).
- Within H (720), the subgroup fixing v has size 18; it preserves the embedded Schläfli graph and the bad predicate.
