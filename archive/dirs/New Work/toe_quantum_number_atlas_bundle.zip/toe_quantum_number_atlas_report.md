# Quantum-number atlas: tetrad orbits and state-sector signatures

- H order: 720
- Tetrad orbits under H: 2 orbits, sizes [10, 30]
- Signature-pure tetrad orbits: 2/2

## Tetrad weight signatures (top)
- count 40: [0.1, 0.5, 0.9, 1.0, 1.0, 0.5]

## State weight signatures (top)
- count 40: [0.025, 0.125, 0.225, 0.25, 0.25, 0.125]

## Notes
- If tetrad orbits are signature-pure, then sector weights classify contexts into superselection types under the symmetry-broken group H.
- State signatures show how each idempotent sector weights individual rays; correlating with 10 blocks tests whether blocks are sector-homogeneous.
