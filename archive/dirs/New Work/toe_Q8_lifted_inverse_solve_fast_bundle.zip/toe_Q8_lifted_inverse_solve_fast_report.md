# Q8-lifted inverse solve (fast)

- fixed edges: 9, free edges: 36
- best_cost: 27 / 120 triangles
- perfect: False
- triangle p distribution: {2: 63, 0: 57}
- p=2 edges (total/free): 13/13

- This solve keeps (h,t) fixed to observed transport and solves only the Q8 sign bit p∈{0,2} on unordered edges.
- Constraint enforced: for canonical orientation a<b<c, triangle holonomy p should be 2 on odd triples and 0 on even triples (strong gauge choice).
- If best_cost>0, we should switch to the weaker but correct constraint: even triples have |p_values|=1 across orientations, odd triples have |p_values|=2.
