# Novel identification: W33/Witting SRG as an S6 (3,3)-class Cayley-type graph

## Statement
Let X be the conjugacy class in S6 consisting of elements of cycle type (3)(3); |X|=40.
Define a graph on X by connecting g~h iff the relative element g^{-1}h has cycle type (3) or (3,3).

This graph is SRG(40,12,2,4) and is isomorphic to the Witting/W33 orthogonality SRG.

## Consequences
- The 10×4 block structure becomes canonical: each (3,3) element determines a 3+3 partition of {1..6}, and each partition supports exactly 4 oriented (3,3) elements.
- Our 10 blocks of 4 are literally the 10 partitions of 6 letters into two 3-sets, with 4 orientation choices.

## Sanity checks
- degree = 12, edges = 240
- partition multiplicities: Counter({4: 10})

## Files
- JSON includes an explicit isomorphism: Witting vertex -> S6 permutation in one-line notation.
