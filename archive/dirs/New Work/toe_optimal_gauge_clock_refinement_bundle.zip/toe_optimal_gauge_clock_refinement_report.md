# Optimal gauge fixing for the local 1-form clock (spectral synchronization)

## Edge phase classes (k6)
- before: {'4': 74, '1': 59, '2': 74, '3': 50, '0': 44, '5': 59}
- after:  {'1': 65, '0': 156, '4': 31, '5': 65, '3': 12, '2': 31}
- unique edge phases before/after: 6/360

## 4-cycle phase scan (Z12 grid)
- k support before: ['10', '2', '4', '0', '8', '6']
- k support after:  ['10', '5', '0', '7', '1', '6', '3', '2', '11', '8', '9', '4']

## 6-cycle phase scan (Z24 grid)
- k support before: [0, 4, 8, 12, 16, 20]
- k support after:  [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]

## Notes
- This chooses vertex phases alpha_i to maximize consistency of edge phases on the N180 interaction graph (spectral phase synchronization).
- If additional Z12/Z24 ticks were hidden by gauge, they would appear after gauge optimization. We compare k-support before/after.
- Edge phase distribution should concentrate after optimization if the gauge field is near-flat.
