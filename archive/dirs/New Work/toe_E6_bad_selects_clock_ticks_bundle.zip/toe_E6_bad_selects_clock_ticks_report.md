# Does the E6 'bad' predicate select specific clock ticks?

Totals: {'nonorth_pairs': 243, 'S_edges': 216, 'bad_edges': 27}
Support sizes (distinct ticks): {'nonorth': 18, 'S': 12, 'bad': 10}

## L1 distances between distributions
- L1(S vs nonorth): 0.150206
- L1(bad vs nonorth): 1.20165
- L1(S vs bad): 1.35185

## Top ticks
### nonorth
- {'t': [0, 1], 'k6': 1}: 30
- {'t': [0, 0], 'k6': 1}: 25
- {'t': [1, 1], 'k6': 5}: 20
- {'t': [1, 0], 'k6': 0}: 18
- {'t': [1, 0], 'k6': 1}: 18
- {'t': [1, 1], 'k6': 1}: 17
- {'t': [1, 1], 'k6': 0}: 17
- {'t': [0, 1], 'k6': 0}: 17
- {'t': [0, 1], 'k6': 5}: 16
- {'t': [0, 0], 'k6': 0}: 16
- {'t': [0, 0], 'k6': 5}: 16
- {'t': [1, 0], 'k6': 5}: 15

### S
- {'t': [0, 1], 'k6': 1}: 27
- {'t': [0, 0], 'k6': 1}: 22
- {'t': [1, 1], 'k6': 5}: 20
- {'t': [1, 0], 'k6': 0}: 18
- {'t': [1, 1], 'k6': 1}: 17
- {'t': [1, 1], 'k6': 0}: 17
- {'t': [0, 1], 'k6': 0}: 17
- {'t': [0, 1], 'k6': 5}: 16
- {'t': [0, 0], 'k6': 0}: 16
- {'t': [0, 0], 'k6': 5}: 16
- {'t': [1, 0], 'k6': 1}: 16
- {'t': [1, 0], 'k6': 5}: 14

### bad
- {'t': [0, 1], 'k6': 4}: 4
- {'t': [0, 0], 'k6': 2}: 3
- {'t': [0, 0], 'k6': 4}: 3
- {'t': [0, 0], 'k6': 1}: 3
- {'t': [0, 1], 'k6': 2}: 3
- {'t': [1, 0], 'k6': 2}: 3
- {'t': [0, 1], 'k6': 1}: 3
- {'t': [1, 0], 'k6': 1}: 2
- {'t': [1, 0], 'k6': 4}: 2
- {'t': [1, 0], 'k6': 5}: 1

## Notes
- We assign each cross-block pair (u,w) a clock tick (t_AB, k6) where t_AB is the translation part of the N180 connection between their blocks and k6 is the local phase class from the gauge-fixed inner product.
- We compare the tick distributions for all nonorth pairs in H27(v), Schläfli edges, and the removed bad edges.
- Large L1 distance indicates the E6 cut is selecting specific clock ticks (a phase/topology selection rule).
