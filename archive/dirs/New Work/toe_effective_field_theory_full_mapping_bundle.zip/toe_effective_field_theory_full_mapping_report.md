# Effective field theory: full mapping + E6 alignment

## Field identification
- **G_auth_mode1**: nonabelian-ish transport mediator (router/gauge-like): aligns with authenticated selection (N180) structure
- **M_auth_mode2**: matter/endpoint mode: aligns with narrower authenticated couplings
- **C_block_mode**: constraint/mass-selection mode: aligns with E6 bad firewall pressure and Schläfli kernel carving

## Field lambdas (eigen-couplings)
{'G': -1.2085074770706688e-15, 'M': 4.3335235760449276e-16, 'C': -9.522737991820634e-16}

## Correlations with E6 involvement
- corr(|C|, schlafli_incidence): 0.8875
- corr(|C|, bad_incidence): 0.8875
- corr(|C|, schlafli_minus_bad): 0.8875
- corr(|G|, schlafli_minus_bad): 0.9419
- corr(|M|, schlafli_minus_bad): 0.5915

## E6 involvement vectors (per sector)
- Schläfli incidence: [10.8, 54.0, 97.2, 108.0, 108.0, 54.0]
- Bad incidence: [1.35, 6.75, 12.15, 13.5, 13.5, 6.75]
- Schläfli - bad: [9.45, 47.25, 85.05, 94.5, 94.5, 47.25]

## How to read charges
Sector charge vectors (normalized) columns = [G_mode, M_mode, C_mode]. Large |C| indicates strong constraint/firewall coupling.

- E0: [0.07677755248763925, -0.3810888675528752, 0.08404086387521188]
- E1: [0.36968156257987445, 0.06662110140865012, 0.40454224302768604]
- E2: [-1.0, 1.0, -1.0]
- E3: [0.8287866886470768, 0.6304639697886409, 0.7062688551308531]
- E4: [0.7515318478766775, 0.5168314619947193, 0.6603460193226623]
- E5: [0.40828563299804943, 0.22948401947757843, 0.40491217839685456]

## Notes
- L_auth and L_block are low-rank coupling matrices induced by the extracted field modes; they reproduce the selection-rule deltas by construction.
- Correlations quantify whether the constraint field C aligns with E6 structure (Schläfli vs bad).
- Interpretation maps the three extracted modes to big-name field categories: transport/gauge, matter, constraint/mass-selection.
