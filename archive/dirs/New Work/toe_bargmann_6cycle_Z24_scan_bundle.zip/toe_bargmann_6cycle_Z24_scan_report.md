# Bargmann 6-loop phase scan (attempted Z24 clock)

- total ordered 6-loops: 151200
- valid loops (nonzero overlaps along edges): 151200
- quantization grid: 2π/24
- observed k values: [0, 4, 8, 12, 16, 20] (only Z6 subset)
- counts by k: {'20': 25560, '0': 25560, '4': 25560, '8': 27180, '16': 27180, '12': 20160}

## Closure and shifts
- closure counts: {'False': 108000, 'True': 43200}
- shift counts: {'(0, 1)': 36000, '(1, 1)': 36000, '(0, 0)': 43200, '(1, 0)': 36000}

k distribution by shift:
- (0, 1): {20: 6000, 0: 6000, 4: 6000, 16: 6000, 8: 6000, 12: 6000}
- (1, 1): {4: 6000, 16: 6000, 20: 6000, 0: 6000, 12: 6000, 8: 6000}
- (0, 0): {8: 9180, 16: 9180, 0: 7560, 20: 7560, 4: 7560, 12: 2160}
- (1, 0): {16: 6000, 20: 6000, 12: 6000, 8: 6000, 4: 6000, 0: 6000}

## Key insights
- On 6-loops, Bargmann phase holonomy is still confined to a Z6 subgroup of Z24 (k multiples of 4).
- Non-closed loops (fiber shift != 0) yield a perfectly uniform distribution across the 6 phase classes.
- Closed loops (fiber returns) yield a biased distribution, indicating a strong coupling between closure/holonomy and phase class.
- All four fiber start points x0 yield the same set of phase classes; Z24 does not appear at this level for the seed-paper embedding.
- To obtain Z12/Z24, we likely need to enrich phases via additional gauge (±1 / complex conjugation / other ray representatives) or move to higher-dimensional/BKS constructions where overlaps carry 4th/8th roots.
