# Fast holdout refinement; see JSON for parameters.
