# Sym^3(27) refinement with hold-out (fast)

- init: toe_candidate_cubic_tensor_sym3_lanczos_stochastic.npy
- steps=30, batch=10, eta0=0.02, decay=0.985
- E_train_first12: 2.19973
- E_hold_first12: 2.81633
- tensor saved: toe_candidate_cubic_tensor_sym3_refined_holdout_fast.npy

Compare E_train vs E_hold; if both are low and comparable, we are generalizing (not overfitting).

## Next
- Increase eval_generators_each to 60 and rerun just the evaluation (no training) if runtime allows.
- Repeat with different train/hold splits to test robustness.
- Use this tensor as warm start for longer scaled SGD run on a larger generator set.
