# Rank‑6 relations as S6 relative-permutation types on the (3,3) conjugacy class

Each of the 40 states is identified with a permutation g∈S6 of type (3)(3). For a pair (g,h), consider r=g^{-1}h.

We record features: cycle type of r, parity of r, whether g and h share the same 3+3 partition, and max overlap size between their partitions.

## E20
- cycle types (counts): {'(3, 3)': 20}
- same partition? (counts): {'False': 18, 'True': 2}
- max partition intersection (counts): {'2': 18, '3': 2}
- parity (counts): {'0': 20}
- distinct feature classes: 2
- examples: [{'pair': [0, 39], 'ct': (3, 3), 'par': 0, 'same_part': False, 'max_inter': 2}, {'pair': [1, 34], 'ct': (3, 3), 'par': 0, 'same_part': True, 'max_inter': 3}, {'pair': [2, 37], 'ct': (3, 3), 'par': 0, 'same_part': False, 'max_inter': 2}, {'pair': [3, 33], 'ct': (3, 3), 'par': 0, 'same_part': False, 'max_inter': 2}, {'pair': [4, 29], 'ct': (3, 3), 'par': 0, 'same_part': False, 'max_inter': 2}]

## E40
- cycle types (counts): {'(3, 3)': 36, '(3,)': 4}
- same partition? (counts): {'False': 36, 'True': 4}
- max partition intersection (counts): {'2': 36, '3': 4}
- parity (counts): {'0': 40}
- distinct feature classes: 2
- examples: [{'pair': [0, 12], 'ct': (3, 3), 'par': 0, 'same_part': False, 'max_inter': 2}, {'pair': [0, 19], 'ct': (3, 3), 'par': 0, 'same_part': False, 'max_inter': 2}, {'pair': [1, 15], 'ct': (3,), 'par': 0, 'same_part': True, 'max_inter': 3}, {'pair': [1, 22], 'ct': (3,), 'par': 0, 'same_part': True, 'max_inter': 3}, {'pair': [2, 27], 'ct': (3, 3), 'par': 0, 'same_part': False, 'max_inter': 2}]

## E180
- cycle types (counts): {'(3, 3)': 144, '(3,)': 36}
- same partition? (counts): {'False': 126, 'True': 54}
- max partition intersection (counts): {'2': 126, '3': 54}
- parity (counts): {'0': 180}
- distinct feature classes: 3
- examples: [{'pair': [0, 25], 'ct': (3, 3), 'par': 0, 'same_part': False, 'max_inter': 2}, {'pair': [0, 26], 'ct': (3, 3), 'par': 0, 'same_part': False, 'max_inter': 2}, {'pair': [0, 28], 'ct': (3, 3), 'par': 0, 'same_part': False, 'max_inter': 2}, {'pair': [0, 29], 'ct': (3, 3), 'par': 0, 'same_part': False, 'max_inter': 2}, {'pair': [0, 32], 'ct': (3,), 'par': 0, 'same_part': True, 'max_inter': 3}]

## N180
- cycle types (counts): {'(2, 2)': 72, '(5,)': 108}
- same partition? (counts): {'False': 180}
- max partition intersection (counts): {'2': 180}
- parity (counts): {'0': 180}
- distinct feature classes: 2
- examples: [{'pair': [0, 1], 'ct': (2, 2), 'par': 0, 'same_part': False, 'max_inter': 2}, {'pair': [0, 2], 'ct': (2, 2), 'par': 0, 'same_part': False, 'max_inter': 2}, {'pair': [0, 3], 'ct': (2, 2), 'par': 0, 'same_part': False, 'max_inter': 2}, {'pair': [0, 4], 'ct': (5,), 'par': 0, 'same_part': False, 'max_inter': 2}, {'pair': [0, 5], 'ct': (5,), 'par': 0, 'same_part': False, 'max_inter': 2}]

## N360
- cycle types (counts): {'(5,)': 252, '(2, 2)': 108}
- same partition? (counts): {'False': 360}
- max partition intersection (counts): {'2': 360}
- parity (counts): {'0': 360}
- distinct feature classes: 2
- examples: [{'pair': [0, 10], 'ct': (5,), 'par': 0, 'same_part': False, 'max_inter': 2}, {'pair': [0, 11], 'ct': (5,), 'par': 0, 'same_part': False, 'max_inter': 2}, {'pair': [0, 13], 'ct': (5,), 'par': 0, 'same_part': False, 'max_inter': 2}, {'pair': [0, 14], 'ct': (5,), 'par': 0, 'same_part': False, 'max_inter': 2}, {'pair': [0, 15], 'ct': (5,), 'par': 0, 'same_part': False, 'max_inter': 2}]

## Notes
- We identify each Witting/W33 vertex with an S6 element of cycle type (3)(3).
- Each edge relation (E20,E40,E180,N180,N360) is classified by the relative permutation type g^{-1}h (cycle type, parity) and partition overlap features.
- The distributions below reveal a nearly rule-based characterization of each rank-6 relation in pure S6 language.
