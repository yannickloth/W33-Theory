# Dynkin prep tol=1e-8; see JSON/MD.
