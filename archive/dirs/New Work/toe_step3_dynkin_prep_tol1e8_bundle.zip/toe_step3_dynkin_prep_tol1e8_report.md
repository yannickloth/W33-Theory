# Dynkin prep at tol=1e-8 (Cartan rank 6)

- stabilizer_count: 82
- cartan_rank: 6
- roots_mod_sign: 19

## Top roots
- {'root': [-0.0, -0.0, -1.0, -0.0, -0.0, -0.0], 'count': 24}
- {'root': [-0.0, -0.0, -0.0, -0.0, -0.0, -1.0], 'count': 20}
- {'root': [-0.0, -1.0, -0.0, -0.0, -0.0, -0.0], 'count': 20}
- {'root': [-1.0, 0.0, 0.0, 0.0, 0.0, 0.0], 'count': 16}
- {'root': [-0.0, -0.0, -0.0, -1.0, -0.0, -0.0], 'count': 10}
- {'root': [0.0, 0.0, 0.0, 0.0, -1.0, 0.0], 'count': 8}
- {'root': [0.0, -1.0, 0.0, 0.0, 0.0, -1.0], 'count': 4}
- {'root': [0.0, -1.0, 0.0, 0.0, 0.0, 1.0], 'count': 4}
- {'root': [-0.0, -0.0, -1.0, -0.0, -0.0, 1.0], 'count': 4}
- {'root': [0.0, 0.0, -1.0, 0.0, 0.0, -1.0], 'count': 4}
- {'root': [-0.0, -1.0, -0.0, 1.0, -0.0, -0.0], 'count': 2}
- {'root': [0.0, -1.0, 0.0, -1.0, 0.0, 0.0], 'count': 2}
- {'root': [0.0, 0.0, 0.0, -1.0, 1.0, 0.0], 'count': 2}
- {'root': [-1.0, 0.0, 0.0, 0.0, -1.0, 0.0], 'count': 2}
- {'root': [-1.0, 0.0, 0.0, 0.0, 1.0, 0.0], 'count': 2}

## Next
- Increase precision (less rounding) and cluster roots with tolerance instead of rounding.
- Orthonormalize Cartan set (linear independence check) and ensure it is truly rank 6.
- Attempt Dynkin recovery: select simple roots via minimal norm set and compute Cartan matrix.
