# Cartan + root extraction from cubic stabilizer

- chosen_tol: 1e-12
- stabilizer_count: 82
- Cartan found: 6 (eps_comm=1e-06)
- rank_r: 6
- unique root vectors (sampled): 48

## Cartan generator labels
- ('edge', 9, 16)
- ('edge', 3, 21)
- ('edge', 4, 17)
- ('edge', 6, 15)
- ('edge', 20, 24)
- ('edge', 1, 5)

## Top root vectors
- {'root': [0.0, 0.0, 0.0, 0.0, -1.0, 0.0], 'count': 18}
- {'root': [0.0, 0.0, 0.0, 0.0, 1.0, 0.0], 'count': 18}
- {'root': [0.0, 0.0, 1.0, 0.0, 0.0, 0.0], 'count': 16}
- {'root': [0.0, 0.0, -1.0, 0.0, 0.0, 0.0], 'count': 16}
- {'root': [0.0, 0.0, 0.0, 1.0, 0.0, 0.0], 'count': 12}
- {'root': [0.0, 0.0, 0.0, -1.0, 0.0, 0.0], 'count': 12}
- {'root': [0.0, 1.0, 0.0, 0.0, 0.0, 0.0], 'count': 10}
- {'root': [0.0, -1.0, 0.0, 0.0, 0.0, 0.0], 'count': 10}
- {'root': [1.0, 0.0, 0.0, 0.0, 0.0, 0.0], 'count': 10}
- {'root': [-1.0, 0.0, 0.0, 0.0, 0.0, 0.0], 'count': 10}

## Interpretation
- We greedily found a commuting Cartan candidate set inside the cubic stabilizer, aiming for rank 6 (E6).
- We diagonalized a generic Cartan combination, extracted approximate weight vectors for the 27-dimensional representation, and sampled root differences induced by stabilizer generators.
- If rank_r=6 and the root system exhibits ~72 nonzero roots (up to sign), that is strong confirmation of E6.

## Next
- Increase Cartan search to ensure we can reach 6 commuting independent generators (if not already).
- Cluster root vectors more carefully and count positive roots vs total roots; compare to E6 root count 72.
- Use root inner products to reconstruct the Dynkin diagram adjacency.
