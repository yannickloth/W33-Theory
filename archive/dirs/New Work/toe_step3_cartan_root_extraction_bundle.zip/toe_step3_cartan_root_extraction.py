# Cartan and root extraction; see JSON/MD.
