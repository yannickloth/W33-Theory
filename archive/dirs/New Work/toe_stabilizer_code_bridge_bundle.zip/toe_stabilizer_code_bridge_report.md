# Stabilizer / symplectic-code bridge for the 10-block key-transport network

- qubits: 20 (2 bits per block)
- HZ shape=[18, 20], rank=18
- HX shape=[2, 20] (nullspace), CSS commutation ok=True

## Triangle syndrome design
- triangle class counts: {'0': 60, '1': 60}
- odd triples: 60, lambda set: [4]
- H_parity rank: 10 of shape [60, 20]

## Interpretation
- Tree transport constraints are homogeneous in shifted variables (one-time-pad gauge): x'_i = M_{0i} x'_0.
- HX comes from nullspace of HZ, so commutation is automatic (CSS-style).
- Triangle holonomy matrix class gives an orientation-independent Z2 syndrome on unordered triples.
- Odd triples form a 2-(10,3,4) design: every pair appears in exactly 4 odd triples (parity-check structure).
- H_parity measures per-node parity (x0⊕x1) over odd triples; this is the syndrome layer induced by swap holonomy.
