#!/usr/bin/env python3
"""Trinification-style E8 build scaffold (E6 × SU(3) with 27⊗3).

Goal:
  Provide a *concrete* algebra object whose brackets can be evaluated and
  whose Jacobi identity can be tested numerically / exactly (symbolically)
  once the missing invariant tensors are supplied.

Mathematical target decomposition:
  g = (e6,1) ⊕ (1,su3) ⊕ (27,3) ⊕ (27bar,3bar)

Standard (Tits/Freudenthal) style brackets require:
  - e6 action on 27 and 27bar
  - su3 action on 3 and 3bar
  - an E6-invariant symmetric cubic form d_{abc} on 27
  - the SU(3) epsilon tensor ε_{ijk}
  - a pairing < , > between 27 and 27bar and between 3 and 3bar
  - a projection map Π: (27,3) ⊗ (27bar,3bar) → (e6,1) ⊕ (1,su3)

This file implements the bookkeeping and Jacobi test harness.
It is intentionally *data-driven* so you can plug in the tensors/matrices
we've already been extracting in other bundles (Chevalley basis, etc.).

Citations (background):
  - The decomposition 248 = (78,1)+(1,8)+(27,3)+(\bar{27},\bar{3})
    is standard in E8 branching rules. See Slansky table. 
  - E6 can be defined as stabilizer of a nondegenerate symmetric 3-form on 27.
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import Dict, Tuple, Optional

Array = np.ndarray

def kron(a: Array, b: Array) -> Array:
    return np.kron(a, b)

@dataclass
class RepData:
    # e6 generators in 27 and 27bar (optional: infer 27bar as -transpose wrt pairing)
    e6_gen_27: Dict[str, Array]           # keys: basis labels, values: 27x27
    su3_gen_3: Dict[str, Array]           # 3x3 traceless antihermitian (or any basis)
    pairing_27: Array                     # 27x27 (bilinear form mapping 27 -> 27bar)
    pairing_3: Array                      # 3x3 (usually identity)
    d_cubic: Optional[Array] = None       # shape (27,27,27) symmetric
    eps3: Optional[Array] = None          # shape (3,3,3) totally antisymmetric

@dataclass
class Element:
    # One of: e6 part, su3 part, v in 27x3, vbar in 27x3 (using pairing conventions)
    kind: str
    data: Array

class TrinificationAlgebra:
    def __init__(self, rep: RepData):
        self.rep = rep
        if self.rep.eps3 is None:
            self.rep.eps3 = self._default_eps3()
        if self.rep.d_cubic is None:
            # left None; bracket pieces requiring it will raise
            pass

        # pre-pack generator matrices for fast action on 27⊗3
        self.e6_basis = list(self.rep.e6_gen_27.keys())
        self.su3_basis = list(self.rep.su3_gen_3.keys())

    @staticmethod
    def _default_eps3() -> Array:
        eps = np.zeros((3,3,3), dtype=int)
        # ε_{012}=+1 in 0-based
        eps[0,1,2] = eps[1,2,0] = eps[2,0,1] = 1
        eps[0,2,1] = eps[2,1,0] = eps[1,0,2] = -1
        return eps

    # ---- constructors ----
    def e6(self, coeffs: Dict[str,float]) -> Element:
        v = np.zeros((len(self.e6_basis),), dtype=float)
        for i,k in enumerate(self.e6_basis):
            v[i] = coeffs.get(k, 0.0)
        return Element("e6", v)

    def su3(self, coeffs: Dict[str,float]) -> Element:
        v = np.zeros((len(self.su3_basis),), dtype=float)
        for i,k in enumerate(self.su3_basis):
            v[i] = coeffs.get(k, 0.0)
        return Element("su3", v)

    def v(self, mat27x3: Array) -> Element:
        assert mat27x3.shape == (27,3)
        return Element("v", mat27x3.astype(float))

    def vbar(self, mat27x3: Array) -> Element:
        assert mat27x3.shape == (27,3)
        return Element("vbar", mat27x3.astype(float))

    # ---- internal helpers ----
    def _e6_matrix(self, coeff_vec: Array) -> Array:
        # returns 27x27
        M = np.zeros((27,27), dtype=float)
        for c,k in zip(coeff_vec, self.e6_basis):
            if c != 0.0:
                M += c * self.rep.e6_gen_27[k]
        return M

    def _su3_matrix(self, coeff_vec: Array) -> Array:
        M = np.zeros((3,3), dtype=float)
        for c,k in zip(coeff_vec, self.su3_basis):
            if c != 0.0:
                M += c * self.rep.su3_gen_3[k]
        return M

    # ---- bracket ----
    def bracket(self, a: Element, b: Element) -> Element:
        ka, kb = a.kind, b.kind
        # antisymmetry: handle ordering
        if (ka, kb) not in {
            ("e6","e6"), ("su3","su3"), ("e6","su3"),
            ("e6","v"), ("e6","vbar"),
            ("su3","v"), ("su3","vbar"),
            ("v","v"), ("vbar","vbar"), ("v","vbar")
        }:
            # swap with sign
            out = self.bracket(b,a)
            return Element(out.kind, -out.data)

        if ka=="e6" and kb=="e6":
            # commutator in e6 *in coefficient space* requires structure constants.
            # If you don't have them, you can lift to 27x27 and re-project via least squares.
            return self._bracket_lift_project_e6(a.data, b.data)

        if ka=="su3" and kb=="su3":
            return self._bracket_lift_project_su3(a.data, b.data)

        if ka=="e6" and kb=="su3":
            return Element("e6", np.zeros_like(a.data))  # commute in direct sum

        if ka=="e6" and kb=="v":
            M = self._e6_matrix(a.data)
            return Element("v", M @ b.data)

        if ka=="e6" and kb=="vbar":
            M = self._e6_matrix(a.data)
            # contragredient action on vbar: -(P^{-1} M^T P) acting on rows
            P = self.rep.pairing_27
            Minv = -np.linalg.solve(P, (M.T @ P))
            return Element("vbar", Minv @ b.data)

        if ka=="su3" and kb=="v":
            N = self._su3_matrix(a.data)
            return Element("v", b.data @ N.T)

        if ka=="su3" and kb=="vbar":
            N = self._su3_matrix(a.data)
            return Element("vbar", b.data @ N.T)

        if ka=="v" and kb=="v":
            return self._bracket_v_v(a.data, b.data)

        if ka=="vbar" and kb=="vbar":
            return self._bracket_vbar_vbar(a.data, b.data)

        if ka=="v" and kb=="vbar":
            return self._bracket_v_vbar(a.data, b.data)

        raise ValueError(f"Unhandled bracket {ka},{kb}")

    # ---- projection-based commutators (no explicit structure constants needed) ----
    def _project_to_basis(self, basis_mats: Dict[str,Array], X: Array) -> Array:
        # least squares on Frobenius inner product
        keys = list(basis_mats.keys())
        B = np.stack([basis_mats[k].reshape(-1) for k in keys], axis=1)  # (n^2, nb)
        x = X.reshape(-1)
        coeffs, *_ = np.linalg.lstsq(B, x, rcond=None)
        return coeffs

    def _bracket_lift_project_e6(self, ca: Array, cb: Array) -> Element:
        A = self._e6_matrix(ca)
        B = self._e6_matrix(cb)
        C = A @ B - B @ A
        coeffs = self._project_to_basis(self.rep.e6_gen_27, C)
        return Element("e6", coeffs)

    def _bracket_lift_project_su3(self, ca: Array, cb: Array) -> Element:
        A = self._su3_matrix(ca)
        B = self._su3_matrix(cb)
        C = A @ B - B @ A
        coeffs = self._project_to_basis(self.rep.su3_gen_3, C)
        return Element("su3", coeffs)

    # ---- mixed brackets needing invariant tensors ----
    def _bracket_v_v(self, X: Array, Y: Array) -> Element:
        if self.rep.d_cubic is None:
            raise RuntimeError("Need rep.d_cubic (27,27,27) to compute [v,v].")
        d = self.rep.d_cubic
        eps = self.rep.eps3
        # compute Z in vbar space: Z_{a,i} = sum_{b,c,j,k} d_{a b c} * eps_{i j k} * X_{b,j} * Y_{c,k}
        Z = np.einsum('abc,ijk,bj,ck->ai', d, eps, X, Y)
        return Element("vbar", Z)

    def _bracket_vbar_vbar(self, X: Array, Y: Array) -> Element:
        if self.rep.d_cubic is None:
            raise RuntimeError("Need rep.d_cubic to compute [vbar,vbar].")
        # use same tensor; depending on conventions might need d^ (dual). we assume pairing identifies dual.
        d = self.rep.d_cubic
        eps = self.rep.eps3
        Z = np.einsum('abc,ijk,bj,ck->ai', d, eps, X, Y)
        return Element("v", Z)

    def _bracket_v_vbar(self, X: Array, Y: Array) -> Element:
        # produce (e6, su3) components from contractions
        P27 = self.rep.pairing_27
        P3  = self.rep.pairing_3
        # Contract 27 indices to 27x27 matrix
        # M_ab = sum_i X_{a,i} * (P3)_{ij} * Y_{b,j}
        M = X @ P3 @ Y.T  # 27x27
        # Project trace-free part onto e6 basis (note: e6 sits in sl(27) preserving cubic; we just project)
        M0 = M - np.trace(M)/27.0 * np.eye(27)
        e6_coeffs = self._project_to_basis(self.rep.e6_gen_27, M0)

        # Contract 3 indices to 3x3 matrix
        N = X.T @ P27 @ Y  # 3x3
        N0 = N - np.trace(N)/3.0 * np.eye(3)
        su3_coeffs = self._project_to_basis(self.rep.su3_gen_3, N0)

        # Return as a packed direct-sum element: store concatenated coeffs with tag
        return Element("g0", np.concatenate([e6_coeffs, su3_coeffs]))

    # ---- Jacobi tests ----
    def jacobi_residual(self, a: Element, b: Element, c: Element) -> Tuple[str, float]:
        # returns (kind, norm) of J(a,b,c) = [a,[b,c]] + ...
        bc = self.bracket(b,c)
        ca = self.bracket(c,a)
        ab = self.bracket(a,b)
        term1 = self.bracket(a, bc)
        term2 = self.bracket(b, ca)
        term3 = self.bracket(c, ab)
        # must align kinds; for g0 vs e6/su3, just compare raw vectors with padding.
        kind = term1.kind
        if term2.kind != kind or term3.kind != kind:
            # naive reconciliation: if any is g0, upcast all to g0
            if {term1.kind, term2.kind, term3.kind} <= {"e6","su3"}:
                # should not happen unless inputs mismatched
                pass
            # else, just report mismatch
            return ("kind_mismatch", np.inf)
        J = term1.data + term2.data + term3.data
        return (kind, float(np.linalg.norm(J)))

def demo_load_minimal() -> RepData:
    # Minimal demo basis (NOT physical): random sl(27) and su(3) basis; for plumbing only.
    rng = np.random.default_rng(0)
    e6 = {f"g{i}": rng.standard_normal((27,27)) for i in range(78)}
    su3 = {f"h{i}": rng.standard_normal((3,3)) for i in range(8)}
    P27 = np.eye(27)
    P3 = np.eye(3)
    return RepData(e6, su3, P27, P3)

if __name__ == "__main__":
    rep = demo_load_minimal()
    alg = TrinificationAlgebra(rep)
    # jacobi on e6 part (works because we lift/project using matrices)
    a = alg.e6({"g0":1.0, "g1":-0.7})
    b = alg.e6({"g2":0.2})
    c = alg.e6({"g3":-1.5})
    print("Jacobi(e6,e6,e6):", alg.jacobi_residual(a,b,c))
