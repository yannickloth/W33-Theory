Pocket20 K5 edgepair cover bundle

Contains analysis of W33 orbit10 lines as K5 edges and 20-centered pocket
deck structure.
